# OG Landmark — Hostinger package

This ZIP contains both deployable applications:

- `website/` — the public Node.js website and rollback-compatible legacy API
- `backend/` — the Laravel shared API for the website and Expo mobile app

No credentials, `.env` files, local databases, Replit metadata, or production
media files are included.

## Recommended Hostinger layout

Run the two applications separately:

1. **Website:** Hostinger Node.js application with its root at `website/`
   and startup file `server.js` / start command `npm start`.
2. **API:** Hostinger PHP application or subdomain such as
   `api.oglandmark.com`, with document root `backend/public/`, PHP 8.2+.

The website can continue serving traffic on its existing Node API until the
Laravel API has passed the checks below.

## Website setup

```sh
cd website
npm install --omit=dev
npm start
```

Set these values in Hostinger's environment settings, based on
`website/.env.example`:

- `NODE_ENV=production`
- `DATABASE_URL=mysql://...` for the existing Hostinger MySQL database
- `APP_URL=https://oglandmark.com`
- SMTP mailbox values (`SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS`,
  `SMTP_SECURE=true`)
- `MEDIA_STORAGE_DIR` to the persistent media directory
- Keep `LARAVEL_API_URL` empty until the Laravel API is verified

Do not set a fixed `PORT`; Hostinger assigns it. If the target database is
empty, run `npm run migrate` and then import only a verified export with
`npm run import-data`. Never import the included sample data over an existing
production database.

## Laravel API setup

Copy `backend/.env.example` to the server environment settings and set:

- A generated `APP_KEY`, `APP_DEBUG=false`, and the API `APP_URL`
- `DB_CONNECTION=mysql` and the existing Hostinger `DATABASE_URL`
- Hostinger SMTP mailbox values
- A persistent, readable/writable `MEDIA_STORAGE_DIR`
- `MEDIA_STORAGE_PERSISTENT=true`
- `MEDIA_PUBLIC_BASE_URL` only when a CDN or API subdomain serves the same files

The ZIP includes `backend/vendor`. If Hostinger Composer is available, you can
refresh it with:

```sh
cd backend
composer install --no-dev --optimize-autoloader --no-interaction
```

Then run:

```sh
php artisan migrate --force
php artisan optimize:clear
php artisan config:cache
```

The compatibility migration creates `app_data`, `auth_sessions`, and
`auth_challenges` only when they do not already exist. It does not seed or
overwrite production data. Take a verified MySQL backup before migration.

## Verification before switching traffic

```sh
curl -fsS https://api.oglandmark.com/api/healthz
curl -fsS https://api.oglandmark.com/api/health
curl -fsS https://api.oglandmark.com/api/properties
```

The API health response must show Laravel, MySQL connected, SMTP configured,
and persistent media ready. Test a real login, `/api/auth/me`, one listing
read/write flow, password-reset delivery, and one authenticated image upload.

After the API is healthy, set this on the website and restart it:

```text
LARAVEL_API_URL=https://api.oglandmark.com
```

This makes the Node website proxy its existing `/api/*` calls to Laravel while
continuing to serve the website assets. Rollback is immediate: remove
`LARAVEL_API_URL` and restart the website.

## Media backup warning

Listing metadata and uploaded media are separate parts of the same recovery
unit. Keep `MEDIA_STORAGE_DIR` outside the release directory, back up it
alongside the MySQL `app_data` snapshot, and run the Laravel media restore
smoke test before deleting the previous backup.

Never upload a populated `.env` file or put database, SMTP, or API credentials
in this ZIP, Git, browser code, or chat.
