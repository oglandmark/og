# OG Landmark Laravel API — Hostinger PHP upload

This archive is the **backend-only** package. It is not meant for the Node.js
framework upload screen. Deploy it as a separate Hostinger PHP application or
subdomain such as `api.oglandmark.com`.

- PHP: 8.2 or newer
- Document root: `public/`
- `artisan` and `composer.json` stay one level above `public/`
- `vendor/` is included; run Composer only if Hostinger asks for it

Copy `.env.example` into Hostinger's server environment settings and configure
APP_KEY, the existing MySQL DATABASE_URL, SMTP mailbox values, and a persistent
MEDIA_STORAGE_DIR. Never commit or upload a populated `.env` file.

Run once after configuring the database:

```sh
php artisan migrate --force
php artisan optimize:clear
php artisan config:cache
```

Verify `/api/healthz` and `/api/health` before setting the website's
`LARAVEL_API_URL` to this API origin.
