# OG Landmark Website — Hostinger Node.js upload

This archive is the **website-only** package. Upload/extract it so that
`package.json` and `server.js` are directly in the application root.

- Framework preset: Node.js / Express (or Other Node.js)
- Start command: `npm start`
- Node: 18 or newer
- Do not set a fixed `PORT`; Hostinger provides it
- Run `npm install --omit=dev` if the panel does not install automatically

Set the values from `.env.example` in Hostinger environment settings. Keep
`LARAVEL_API_URL` empty until the separate Laravel API is verified. Then set it
to the API origin, for example `https://api.oglandmark.com`, and restart.

Never upload a populated `.env` file, database credentials, SMTP passwords, or
production media inside the ZIP.
