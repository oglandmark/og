/**
 * Sign Up — buyer-only registration.
 * Agent / Developer accounts are created by admin.
 * Design mirrors the Sign In screen exactly.
 */
import React, { useState } from 'react';
import {
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  View,
} from 'react-native';
import { LocalizedText as Text, LocalizedTextInput as TextInput } from '@/components/LocalizedText';
import { Feather, FontAwesome5 } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as Haptics from 'expo-haptics';
import { useAuth } from '@/context/AuthContext';
import { useLanguage } from '@/context/LanguageContext';
import { OGLandmarkLogo } from '@/components/OGLandmarkLogo';

const ACTION = '#102a43';
const GOLD   = '#c8a45a';
const MUTED  = '#8a8f98';
const BORDER = '#e4e6ea';

export default function SignUpScreen() {
  const insets = useSafeAreaInsets();
  const { registerAPI } = useAuth();
  const { tr, isRTL } = useLanguage();

  const [name,     setName]     = useState('');
  const [email,    setEmail]    = useState('');
  const [phone,    setPhone]    = useState('');
  const [password, setPassword] = useState('');
  const [showPwd,  setShowPwd]  = useState(false);
  const [loading,  setLoading]  = useState(false);
  const [error,    setError]    = useState('');

  const rtl = isRTL ? 'right' as const : 'left' as const;

  async function handleRegister() {
    if (!name.trim())                                          { setError('Full name is required.');                              return; }
    if (!email.includes('@'))                                  { setError('Enter a valid email address.');                        return; }
    if (!phone.trim() || phone.replace(/\D/g,'').length < 10) { setError('Enter a valid phone number (e.g. 0300-1234567).');     return; }
    if (password.length < 6)                                   { setError('Password must be at least 6 characters.');            return; }

    setError('');
    setLoading(true);

    const res = await registerAPI({
      name:    name.trim(),
      email:   email.trim().toLowerCase(),
      phone:   phone.trim(),
      password,
      role:    'buyer',
    });

    setLoading(false);

    if (res.pendingApproval) {
      void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
      // Still let them in; show message
      router.replace('/(tabs)');
      return;
    }

    if (!res.success) {
      void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      setError(res.error ?? 'Registration failed. Please try again.');
      return;
    }

    void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    router.replace('/(tabs)');
  }

  return (
    <KeyboardAvoidingView
      style={[styles.screen, { backgroundColor: '#ffffff' }]}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView
        contentContainerStyle={{ paddingTop: insets.top + 12, paddingBottom: insets.bottom + 32 }}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        {/* Back arrow */}
        <Pressable onPress={() => router.back()} style={styles.backBtn} hitSlop={12}>
          <Feather name="chevron-left" size={26} color={ACTION} />
        </Pressable>

        {/* Brand logo — same as login */}
        <View style={styles.logoWrap}>
          <OGLandmarkLogo size={104} />
          <Text style={styles.logoName}>OG Landmark</Text>
          <Text style={styles.logoSub}>REAL ESTATE</Text>
        </View>

        <View style={styles.content}>
          <Text style={[styles.title, { textAlign: 'center' }]}>Create Account</Text>

          {/* Error banner */}
          {!!error && (
            <View style={styles.errorBox}>
              <Feather name="alert-circle" size={13} color="#b94b42" />
              <Text style={[styles.errorText, { textAlign: rtl }]}>{error}</Text>
            </View>
          )}

          {/* Full Name */}
          <View style={styles.fieldWrap}>
            <Text style={[styles.label, { textAlign: rtl }]}>FULL NAME</Text>
            <TextInput
              value={name}
              onChangeText={(v) => { setName(v); setError(''); }}
              placeholder="Muhammad Ali"
              placeholderTextColor={MUTED}
              textAlign={rtl}
              autoCapitalize="words"
              style={styles.underlineInput}
            />
          </View>

          {/* Email */}
          <View style={styles.fieldWrap}>
            <Text style={[styles.label, { textAlign: rtl }]}>EMAIL ADDRESS</Text>
            <TextInput
              value={email}
              onChangeText={(v) => { setEmail(v); setError(''); }}
              keyboardType="email-address"
              autoCapitalize="none"
              placeholder="you@example.com"
              placeholderTextColor={MUTED}
              textAlign={rtl}
              style={styles.underlineInput}
            />
          </View>

          {/* Phone */}
          <View style={styles.fieldWrap}>
            <Text style={[styles.label, { textAlign: rtl }]}>PHONE NUMBER</Text>
            <TextInput
              value={phone}
              onChangeText={(v) => { setPhone(v); setError(''); }}
              keyboardType="phone-pad"
              placeholder="0300-1234567"
              placeholderTextColor={MUTED}
              textAlign={rtl}
              style={styles.underlineInput}
            />
          </View>

          {/* Password */}
          <View style={styles.fieldWrap}>
            <Text style={[styles.label, { textAlign: rtl }]}>PASSWORD</Text>
            <View style={styles.passRow}>
              <TextInput
                value={password}
                onChangeText={(v) => { setPassword(v); setError(''); }}
                secureTextEntry={!showPwd}
                placeholder="Min. 6 characters"
                placeholderTextColor={MUTED}
                textAlign={rtl}
                style={[styles.underlineInput, { flex: 1, borderBottomWidth: 0 }]}
              />
              <Pressable onPress={() => setShowPwd(v => !v)} hitSlop={8} style={styles.eyeBtn}>
                <Feather name={showPwd ? 'eye' : 'eye-off'} size={18} color={MUTED} />
              </Pressable>
            </View>
            <View style={[styles.underlineLine, { borderColor: BORDER }]} />
          </View>

          {/* Create Account button */}
          <Pressable
            onPress={() => { void handleRegister(); }}
            disabled={loading}
            style={({ pressed }) => [
              styles.submitBtn,
              { backgroundColor: loading ? '#8fa8c0' : ACTION, opacity: pressed ? 0.88 : 1 },
            ]}
          >
            {loading
              ? <ActivityIndicator size="small" color="#fff" />
              : <Text style={styles.submitText}>Create Account</Text>
            }
          </Pressable>

          {/* Divider */}
          <View style={styles.dividerRow}>
            <View style={styles.dividerLine} />
            <Text style={styles.dividerText}>or continue with</Text>
            <View style={styles.dividerLine} />
          </View>

          {/* Social buttons — matching login exactly */}
          <View style={styles.socialRow}>
            <Pressable
              onPress={() => {}}
              style={({ pressed }) => [styles.socialBtn, { opacity: pressed ? 0.5 : 1 }]}
            >
              <FontAwesome5 name="facebook" size={18} color="#1877f2" />
              <Text style={styles.socialText}>Facebook</Text>
            </Pressable>

            <Pressable
              onPress={() => {}}
              style={({ pressed }) => [styles.socialBtn, { opacity: pressed ? 0.5 : 1 }]}
            >
              <Feather name="mail" size={18} color={ACTION} />
              <Text style={styles.socialText}>Email</Text>
            </Pressable>

            <Pressable
              onPress={() => {}}
              style={({ pressed }) => [styles.socialBtn, { opacity: pressed ? 0.5 : 1 }]}
            >
              <FontAwesome5 name="apple" size={18} color="#000" />
              <Text style={styles.socialText}>Apple</Text>
            </Pressable>
          </View>

          {/* Sign in link */}
          <View style={styles.footerRow}>
            <Text style={styles.footerText}>Already have an account?</Text>
            <Pressable onPress={() => router.push('/(auth)/login')} hitSlop={6}>
              <Text style={styles.footerLink}> Sign In</Text>
            </Pressable>
          </View>

        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  screen:         { flex: 1 },
  backBtn:        { marginLeft: 16, marginBottom: 4, width: 40, height: 40, justifyContent: 'center' },

  logoWrap:       { alignItems: 'center', marginBottom: 28, marginTop: 4, gap: 10 },
  logoName:       { fontFamily: 'PlayfairDisplay_600SemiBold', fontSize: 18, letterSpacing: 0.4, color: ACTION },
  logoSub:        { fontFamily: 'Inter_500Medium', fontSize: 9, letterSpacing: 3, color: GOLD, marginTop: -4 },

  content:        { paddingHorizontal: 24 },
  title:          { fontFamily: 'Inter_700Bold', fontSize: 22, color: '#1c2024', marginBottom: 24, letterSpacing: -0.3 },

  errorBox:       { flexDirection: 'row', alignItems: 'center', gap: 7, backgroundColor: '#b94b4212',
                    borderRadius: 10, borderWidth: 1, borderColor: '#b94b4230', padding: 11, marginBottom: 16 },
  errorText:      { fontFamily: 'Inter_400Regular', fontSize: 12, color: '#b94b42', flex: 1 },

  fieldWrap:      { marginBottom: 20 },
  label:          { fontFamily: 'Inter_500Medium', fontSize: 12, color: MUTED, marginBottom: 8, letterSpacing: 0.5 },
  underlineInput: { fontFamily: 'Inter_400Regular', fontSize: 14, color: '#1c2024',
                    borderBottomWidth: 1, borderBottomColor: BORDER, paddingBottom: 10, paddingTop: 2 },
  passRow:        { flexDirection: 'row', alignItems: 'center' },
  eyeBtn:         { paddingLeft: 8 },
  underlineLine:  { borderBottomWidth: 1, marginTop: 0 },

  submitBtn:      { height: 52, borderRadius: 12, alignItems: 'center', justifyContent: 'center', marginBottom: 28 },
  submitText:     { fontFamily: 'Inter_700Bold', fontSize: 15, color: '#fff', letterSpacing: 0.3 },

  dividerRow:     { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 20 },
  dividerLine:    { flex: 1, height: 1, backgroundColor: BORDER },
  dividerText:    { fontFamily: 'Inter_400Regular', fontSize: 12, color: MUTED },

  socialRow:      { flexDirection: 'row', gap: 10, marginBottom: 30 },
  socialBtn:      { flex: 1, height: 48, borderRadius: 10, borderWidth: 1, borderColor: BORDER,
                    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8,
                    backgroundColor: '#fff' },
  socialText:     { fontFamily: 'Inter_500Medium', fontSize: 12, color: '#1c2024' },

  footerRow:      { flexDirection: 'row', justifyContent: 'center', marginBottom: 20, flexWrap: 'wrap' },
  footerText:     { fontFamily: 'Inter_400Regular', fontSize: 13, color: '#1c2024' },
  footerLink:     { fontFamily: 'Inter_700Bold', fontSize: 13, color: GOLD },

  langBtn:        { alignItems: 'center', paddingVertical: 6, flexDirection: 'row', justifyContent: 'center', gap: 5 },
  langText:       { fontFamily: 'Inter_400Regular', fontSize: 12, color: MUTED },
});
