# Local preview — OG Landmark

## Two frontends (do not confuse them)

| Command | Port | What it is |
|---------|------|------------|
| `npm run preview:stack` / `npm run dev` | **5173** + API | **Full live site** preview + Laravel |
| `npm run preview:frontend` | **5173** | **Live Hostinger static site** (`index.prod.html` + hashed `assets/`) |
| `npm run dev:spa` / `dev:scaffold` | **5174** | **Vite + React** SPA scaffold (toolchain restored) |

Ports are split so the scaffold and the full-site preview can run side by side.

The full OG Landmark UI still ships as the pre-built bundle under
[`frontend/assets/`](frontend/assets/). React pages are rebuilt under
[`frontend/src/`](frontend/src/); Vite scaffold builds go to [`frontend/dist/`](frontend/dist/)
only (never wipe the live `assets/` folder until you intentionally cut over).

## Deploy to Hostinger

```sh
npm run build
```

Upload `frontend/build.zip` (or the `frontend/build/` folder) to `public_html/`.
See [`FRONTEND-HOSTINGER-UPLOAD.md`](FRONTEND-HOSTINGER-UPLOAD.md).

Do **not** upload `frontend/dist/` — that is the scaffold only.

## Develop the React scaffold

```sh
cd frontend
npm install
npm run dev:scaffold
```

Or from the repo root:

```sh
npm run dev:spa
```

UI: `http://127.0.0.1:5174/` — `/api` is proxied to Laravel on port `8000`.

Scaffold build check (writes to `frontend/dist/` only — **not** for Hostinger):

```sh
npm run build:spa
```

## Preview the live production static site

**Terminal A — Laravel API**

```sh
php artisan serve
```

**Terminal B — static frontend**

```sh
npm run preview:frontend
```

UI: `http://127.0.0.1:5173/` (temporarily swaps in
[`frontend/index.prod.html`](frontend/index.prod.html); restores the Vite
scaffold [`frontend/index.vite.html`](frontend/index.vite.html) when you stop)

Or both:

```sh
npm run preview:stack
```

## Point the SPA at local Laravel

[`frontend/og-api-base.js`](frontend/og-api-base.js) defaults to production
`https://api.oglandmark.com/api`. For Laragon, open:

```text
http://127.0.0.1:5173/?api=http://127.0.0.1:8000/api
```

Or once in the browser console:

```js
localStorage.setItem('og_api_base', 'http://127.0.0.1:8000/api')
location.reload()
```

CORS already allows `http://localhost:5173`, `http://127.0.0.1:5173`,
`http://localhost:5174`, and `http://127.0.0.1:5174`
(see `.env` `CORS_ALLOWED_ORIGINS` and `config/cors.php`).

### Port 5173 already in use

`preview:frontend` binds only to `127.0.0.1:5173` (override with `OG_PREVIEW_PORT`).
If that port is busy, the script **exits** instead of letting `serve` pick a random
port — a fallback origin would fail Laravel CORS. Free the port and re-run:

```text
Windows:  netstat -ano | findstr :5173   →  taskkill /PID <pid> /F
macOS/Linux:  lsof -i :5173   →  kill <pid>
```

## Quick checks

- `npm run preview:frontend` — homepage is the full OG Landmark site on **5173** (not the scaffold)
- `npm run dev:spa` — scaffold home on **5174** (“Vite + React toolchain restored”)
- `npm run build` — Hostinger package in `frontend/build/` + `frontend/build.zip` with real `index.html` + `assets/`
- DevTools Network: `/api/properties` → `127.0.0.1:8000` when using `?api=`
- Portals: `/portal/admin.html`, `/portal/seller.html`, etc. (on live preview)
