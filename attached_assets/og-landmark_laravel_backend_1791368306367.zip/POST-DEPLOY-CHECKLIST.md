# Post-deploy verification (local smoke + Hostinger checklist)

## Local (already run in this workspace)

- [x] `php artisan migrate --force` — nothing pending
- [x] `php artisan og:import-data --force` — imported `storage/app/imports/og-landmark-data.json`
- [x] `GET http://127.0.0.1:8000/api/healthz` — `status: ok`, MySQL connected, media ready
- [x] `GET http://127.0.0.1:8000/api/properties?limit=2` — 200
- [x] `GET http://127.0.0.1:8000/api/config` — 200
- [x] CORS OPTIONS for `https://oglandmark.com`, `https://www.oglandmark.com`, `http://oglandmark.com`, `http://www.oglandmark.com` — each returns matching `Access-Control-Allow-Origin`
- [x] Static package: `npm run package:hostinger` → `dist-hostinger-frontend/` + `dist-hostinger-frontend.zip`
- [x] `frontend/og-api-base.js` defaults to `https://api.oglandmark.com/api`
- [x] All 9 HTML entrypoints load `/og-api-base.js`
- [x] `frontend/.htaccess` SPA fallback present

## Build website package (before upload)

```sh
npm run package:hostinger
```

Upload `dist-hostinger-frontend.zip` contents (or the folder) into **`public_html/`** for `oglandmark.com`.
Do **not** upload `frontend/dist/` (Vite scaffold only).

## Hostinger — API (`api.oglandmark.com`)

1. Upload Laravel (document root = `public/`) per [HOSTINGER-UPLOAD.md](HOSTINGER-UPLOAD.md).  
   If the Hostinger default page appears while `/public/api/healthz` works, upload
   [`dist-hostinger-api-docroot-fix.zip`](dist-hostinger-api-docroot-fix.zip)
   (or run `npm run package:laravel` then upload that zip / run
   [`scripts/remote-fix-api-docroot.sh`](scripts/remote-fix-api-docroot.sh)).
2. Set production `.env` from [`.env.example`](.env.example), including all four site origins:

   ```env
   CORS_ALLOWED_ORIGINS=https://oglandmark.com,https://www.oglandmark.com,http://oglandmark.com,http://www.oglandmark.com
   ```

3. `php artisan migrate --force`
4. `php artisan og:import-data storage/app/imports/og-landmark-data.json` (omit `--force` if live data exists)
5. `php artisan optimize:clear && php artisan config:cache`
6. Confirm health + CORS:

   ```sh
   curl -sS https://api.oglandmark.com/api/healthz
   curl -sS -D - -o /dev/null -X OPTIONS https://api.oglandmark.com/api/properties \
     -H "Origin: https://oglandmark.com" -H "Access-Control-Request-Method: GET"
   curl -sS -D - -o /dev/null -X OPTIONS https://api.oglandmark.com/api/properties \
     -H "Origin: http://www.oglandmark.com" -H "Access-Control-Request-Method: GET"
   ```

   Expect `Access-Control-Allow-Origin` to echo the request `Origin` (not a mismatched fallback).

## Hostinger — Website (`oglandmark.com`)

1. Upload / extract `dist-hostinger-frontend.zip` (from `npm run package:hostinger`) into document root (`public_html/`)
2. Confirm `index.html` (from `index.prod.html`), `.htaccess`, and `og-api-base.js` are at the site root
3. Hard refresh each URL variant; DevTools Network shows API calls to `api.oglandmark.com`
4. Homepage properties, agents, admin OTP, and image upload — no CORS errors

## Rollback

`localStorage.setItem('og_api_base', 'https://PREVIOUS_ORIGIN/api')` or redeploy previous static files.
