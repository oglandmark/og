<?php

namespace App\Console\Commands;

use App\Services\JsonStore;
use Illuminate\Console\Command;

class EnsureAdmin extends Command
{
    protected $signature = 'og:ensure-admin
                            {email=admin@gmail.com : Admin email address}
                            {--password= : Plaintext password (required for new users; updates existing when set)}
                            {--name=Platform Admin : Display name}';

    protected $description = 'Upsert an Admin user into app_data JSON without wiping other data';

    public function handle(): int
    {
        $email = strtolower(trim((string) $this->argument('email')));
        $password = (string) ($this->option('password') ?? '');
        $name = trim((string) $this->option('name'));
        if ($name === '') {
            $name = 'Platform Admin';
        }

        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $this->error('A valid email is required.');
            return self::FAILURE;
        }

        try {
            $data = JsonStore::read();
        } catch (\Throwable $exception) {
            $this->error('Could not read app_data: '.$exception->getMessage());
            return self::FAILURE;
        }

        $users = $data['users'] ?? [];
        if (!is_array($users)) {
            $users = [];
        }

        $index = null;
        foreach ($users as $i => $user) {
            if (strtolower((string) ($user['email'] ?? '')) === $email) {
                $index = $i;
                break;
            }
        }

        if ($index === null && $password === '') {
            $this->error('Password is required when creating a new admin (--password=...).');
            return self::FAILURE;
        }

        $now = now()->toISOString();

        if ($index === null) {
            $user = [
                'id' => JsonStore::nextId($data),
                'name' => $name,
                'email' => $email,
                'role' => 'Admin',
                'status' => 'Active',
                'approvalStatus' => 'Approved',
                'password' => $this->hashLegacyPassword($password),
                'joinedDate' => $now,
            ];
            $data['users'][] = $user;
            $action = 'created';
        } else {
            $users[$index]['name'] = $name;
            $users[$index]['role'] = 'Admin';
            $users[$index]['status'] = 'Active';
            $users[$index]['approvalStatus'] = 'Approved';
            $users[$index]['email'] = $email;
            if ($password !== '') {
                $users[$index]['password'] = $this->hashLegacyPassword($password);
            }
            $data['users'] = $users;
            $action = 'updated';
        }

        try {
            JsonStore::write($data);
        } catch (\Throwable $exception) {
            $this->error('Could not write app_data: '.$exception->getMessage());
            return self::FAILURE;
        }

        $this->info("Admin user {$action}: {$email}");

        return self::SUCCESS;
    }

    private function hashLegacyPassword(string $password): string
    {
        $salt = bin2hex(random_bytes(16));

        return 'pbkdf2:'.$salt.':'.hash_pbkdf2('sha512', $password, $salt, 100000, 128, false);
    }
}
