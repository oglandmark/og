<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class ImportOgData extends Command
{
    protected $signature = 'og:import-data
                            {path? : Path to the JSON export (defaults to storage/app/imports/og-landmark-data.json)}
                            {--force : Overwrite existing app_data row id=1}';

    protected $description = 'Import OG Landmark canonical JSON into app_data (id=1)';

    public function handle(): int
    {
        $path = $this->argument('path');
        if ($path === null || $path === '') {
            foreach ([
                storage_path('app/imports/og-landmark-data.json'),
                base_path('frontend/og-landmark-data.json'),
            ] as $candidate) {
                if (is_file($candidate)) {
                    $path = $candidate;
                    break;
                }
            }
        }

        if ($path === null || $path === '' || !is_file($path)) {
            $this->error('JSON file not found. Pass a path or place og-landmark-data.json under storage/app/imports/.');
            return self::FAILURE;
        }

        $raw = file_get_contents($path);
        $data = json_decode((string) $raw, true);
        if (!is_array($data)) {
            $this->error('Invalid JSON: expected an object/array at the root.');
            return self::FAILURE;
        }

        $exists = DB::table('app_data')->where('id', 1)->exists();
        if ($exists && !$this->option('force')) {
            $this->error('app_data already contains data (id=1). Use --force to overwrite.');
            return self::FAILURE;
        }

        foreach ($data['users'] ?? [] as $index => $user) {
            $password = (string) ($user['password'] ?? '');
            if ($password !== '' && !str_starts_with($password, 'pbkdf2:')) {
                $salt = bin2hex(random_bytes(16));
                $hash = hash_pbkdf2('sha512', $password, $salt, 100000, 128, false);
                $data['users'][$index]['password'] = "pbkdf2:{$salt}:{$hash}";
            }
        }

        $json = json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        if ($json === false) {
            $this->error('Failed to encode JSON for storage.');
            return self::FAILURE;
        }

        DB::table('app_data')->updateOrInsert(
            ['id' => 1],
            ['data' => $json, 'updated_at' => now()],
        );

        $this->info($exists
            ? "Overwrote app_data from {$path}."
            : "Imported OG Landmark data into MySQL from {$path}.");

        return self::SUCCESS;
    }
}
