<?php

namespace App\Console\Commands;

use App\Services\JsonStore;
use App\Services\PropertySearchIndexer;
use Illuminate\Console\Command;

class ReindexProperties extends Command
{
    protected $signature = 'og:reindex-properties';

    protected $description = 'Rebuild property_search_index from app_data.properties';

    public function handle(PropertySearchIndexer $indexer): int
    {
        $data = JsonStore::read();
        $properties = $data['properties'] ?? [];
        if (!is_array($properties)) {
            $this->error('app_data.properties is missing or invalid.');

            return self::FAILURE;
        }

        $count = $indexer->rebuild($properties);
        $this->info("Reindexed {$count} properties into property_search_index.");

        return self::SUCCESS;
    }
}
