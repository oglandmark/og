<?php

namespace App\Http\Controllers;

use App\Services\JsonStore;
use App\Services\MediaStorage;
use App\Services\PropertySearchIndexer;
use App\Services\SiteContent;
use App\Support\CorsOrigin;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;

class ApiController extends Controller
{
    public function handle(Request $request, ?string $path = null)
    {
        $path = trim((string) ($path ?? ''), '/');
        $segments = $path === '' ? [] : explode('/', $path);
        $method = strtoupper($request->method());

        if (($segments[0] ?? '') === 'health' || ($segments[0] ?? '') === 'healthz') {
            return $this->health();
        }

        if (($segments[0] ?? '') === 'config' && $method === 'GET') {
            return $this->json(['recaptchaSiteKey' => env('RECAPTCHA_SITE_KEY') ?: null]);
        }

        if (app()->environment('production') && !$this->databaseReady()) {
            return $this->json([
                'error' => 'Database is not ready. Check the MySQL settings and app_data import.',
                'code' => 'DB_NOT_READY',
            ], 503);
        }

        if (($segments[0] ?? '') === 'auth') {
            return $this->auth($request, array_slice($segments, 1), $method);
        }

        if (($segments[0] ?? '') === 'properties') {
            return $this->properties($request, array_slice($segments, 1), $method);
        }

        if (($segments[0] ?? '') === 'admin') {
            return $this->admin($request, array_slice($segments, 1), $method);
        }

        if (($segments[0] ?? '') === 'users') {
            return $this->users($request, array_slice($segments, 1), $method);
        }

        if (($segments[0] ?? '') === 'account') {
            return $this->account($request, array_slice($segments, 1), $method);
        }

        if (($segments[0] ?? '') === 'saved') {
            return $this->saved($request, array_slice($segments, 1), $method);
        }

        if (($segments[0] ?? '') === 'saved-searches') {
            return $this->savedSearches($request, array_slice($segments, 1), $method);
        }

        if (($segments[0] ?? '') === 'settings') {
            return $this->settings($request, array_slice($segments, 1), $method);
        }

        if (($segments[0] ?? '') === 'site-content') {
            return $this->siteContent($request, $method);
        }

        if (($segments[0] ?? '') === 'city-agents') {
            return $this->cityAgents($request, array_slice($segments, 1), $method);
        }

        if (($segments[0] ?? '') === 'announcements') {
            return $this->announcements($request, array_slice($segments, 1), $method);
        }

        if (($segments[0] ?? '') === 'projects') {
            return $this->projects($request, array_slice($segments, 1), $method);
        }

        if (($segments[0] ?? '') === 'notifications' || ($segments[0] ?? '') === 'notification-preferences') {
            return $this->notifications($request, $segments, $method);
        }

        if (($segments[0] ?? '') === 'upload') {
            return $this->upload($request, array_slice($segments, 1));
        }

        if (($segments[0] ?? '') === 'mobile') {
            return $this->mobile($request, array_slice($segments, 1), $method);
        }

        if (($segments[0] ?? '') === 'blog') {
            return $this->blog($request, array_slice($segments, 1), $method);
        }

        if (($segments[0] ?? '') === 'mobile-agents' || ($segments[0] ?? '') === 'agents') {
            return $this->agents($request, $segments, $method);
        }

        if (($segments[0] ?? '') === 'offers' || ($segments[0] ?? '') === 'inquiries' || ($segments[0] ?? '') === 'appointments') {
            return $this->simpleCollection($request, $segments, $method);
        }

        if (($segments[0] ?? '') === 'conversations') {
            return $this->conversations($request, array_slice($segments, 1), $method);
        }

        if (($segments[0] ?? '') === 'my-properties') {
            return $this->myProperties($request);
        }

        if (($segments[0] ?? '') === 'search' && ($segments[1] ?? '') === 'ai') {
            return $this->json(['answer' => 'Search suggestions are available through the property filters.', 'filters' => $request->all()]);
        }

        if ($this->isGenericCollection($segments)) {
            return $this->genericCollection($request, $segments, $method);
        }

        return $this->json(['error' => 'Not found'], 404);
    }

    private function health()
    {
        $database = $this->databaseReady() ? 'connected' : 'not_connected';
        $media = app(MediaStorage::class)->health();
        $productionMediaReady = !app()->environment('production') || $media['status'] === 'ready';

        return $this->json([
            'status' => $database === 'connected' && $productionMediaReady ? 'ok' : 'degraded',
            'database' => $database,
            'databaseProvider' => 'mysql',
            'framework' => 'laravel',
            'smtp' => config('mail.mailers.smtp.username') && config('mail.mailers.smtp.password')
                ? 'configured'
                : 'not_configured',
            'mediaBaseUrl' => $this->mediaBaseUrl(),
            'mediaStorage' => $media,
        ]);
    }

    private function databaseReady(): bool
    {
        try {
            DB::select('SELECT 1');
            if (!app()->environment('production')) return true;
            foreach (['app_data', 'auth_sessions', 'auth_challenges'] as $table) {
                DB::select("SELECT 1 FROM `{$table}` LIMIT 0");
            }
            return DB::table('app_data')->where('id', 1)->exists();
        } catch (\Throwable) {
            // Keep healthz available so deployment configuration can be fixed.
            return false;
        }
    }

    private function auth(Request $request, array $parts, string $method)
    {
        $action = $parts[0] ?? '';

        if ($action === 'me' && $method === 'GET') {
            $user = $this->currentUser($request, true);
            return $this->json($this->safeUser($user));
        }

        if ($action === 'logout' && $method === 'POST') {
            $this->destroySession($request);
            return $this->json(['success' => true]);
        }

        if ($action === 'login' && $method === 'POST') {
            $input = $request->all();
            $identifier = strtolower(trim((string) ($input['identifier'] ?? $input['email'] ?? $input['username'] ?? $input['phone'] ?? '')));
            $password = (string) ($input['password'] ?? '');
            $data = JsonStore::read();
            $user = collect($data['users'] ?? [])->first(function ($candidate) use ($identifier) {
                return strtolower((string) ($candidate['email'] ?? '')) === $identifier
                    || strtolower((string) ($candidate['username'] ?? '')) === $identifier
                    || strtolower((string) ($candidate['phone'] ?? '')) === $identifier;
            });

            if (!$user || !$this->verifyLegacyPassword($password, (string) ($user['password'] ?? ''))) {
                return $this->json(['error' => 'Invalid login credentials.'], 401);
            }
            if (in_array(strtolower((string) ($user['status'] ?? 'active')), ['inactive', 'suspended', 'blocked'], true)) {
                return $this->json(['error' => 'This account is not active.'], 403);
            }

            $roleLower = strtolower((string) ($user['role'] ?? ''));
            if ($roleLower === 'agent') {
                $approval = strtolower((string) ($user['approvalStatus'] ?? $user['status'] ?? 'active'));
                if (in_array($approval, ['pending', 'awaiting', 'awaiting_approval'], true)) {
                    return $this->json([
                        'error' => 'Your agent account is pending admin approval.',
                        'code' => 'AGENT_PENDING',
                    ], 403);
                }
                if (in_array($approval, ['rejected', 'denied'], true)) {
                    return $this->json([
                        'error' => 'Your agent account was not approved.',
                        'code' => 'AGENT_REJECTED',
                    ], 403);
                }
            }

            try {
                $token = $this->createSession($user);
            } catch (\Throwable $exception) {
                Log::error('Login session could not be created.', ['error' => $exception->getMessage()]);
                return $this->json(['error' => 'Unable to start a session. Try again shortly.', 'code' => 'SESSION_UNAVAILABLE'], 503);
            }

            return $this->json(['user' => $this->safeUser($user), 'token' => $token]);
        }

        if ($action === 'register' && $method === 'POST') {
            $input = $request->all();
            $validator = Validator::make($input, [
                'email' => ['required', 'email', 'max:320'],
                'password' => ['required', 'min:8'],
                'role' => ['nullable', 'in:buyer,agent,seller,Buyer,Agent,Seller'],
            ]);
            if ($validator->fails()) {
                return $this->json(['error' => $validator->errors()->first(), 'errors' => $validator->errors()], 422);
            }

            $data = JsonStore::read();
            $email = strtolower(trim((string) $input['email']));
            if (collect($data['users'] ?? [])->contains(fn ($u) => strtolower((string) ($u['email'] ?? '')) === $email)) {
                return $this->json(['error' => 'An account with this email already exists.'], 409);
            }
            $name = trim((string) ($input['name'] ?? trim(($input['firstName'] ?? '') . ' ' . ($input['lastName'] ?? ''))));
            $roleInput = strtolower((string) ($input['role'] ?? 'buyer'));
            $role = match ($roleInput) {
                'agent' => 'Agent',
                'seller' => 'Seller',
                default => 'Buyer',
            };
            $user = [
                'id' => JsonStore::nextId($data),
                'name' => $name !== '' ? $name : 'OG Landmark User',
                'email' => $email,
                'username' => $input['username'] ?? null,
                'phone' => $input['phone'] ?? null,
                'city' => $input['city'] ?? null,
                'role' => $role,
                'status' => $role === 'Agent' ? 'Pending' : 'Active',
                'approvalStatus' => $role === 'Agent' ? 'Pending' : 'Approved',
                'password' => $this->hashLegacyPassword($input['password']),
                'joinedDate' => now()->toISOString(),
            ];
            if ($role === 'Agent') {
                foreach (['specialization', 'experience'] as $extra) {
                    if (!empty($input[$extra])) {
                        $user[$extra] = $input[$extra];
                    }
                }
            }
            $data['users'][] = $user;
            JsonStore::write($data);

            if ($role === 'Agent') {
                return $this->json(['pending' => true, 'message' => 'Your agent account is awaiting approval.'], 201);
            }

            try {
                $token = $this->createSession($user);
            } catch (\Throwable $exception) {
                Log::error('Register session could not be created.', ['error' => $exception->getMessage()]);
                return $this->json([
                    'user' => $this->safeUser($user),
                    'error' => 'Account created but session could not be started. Please log in.',
                    'code' => 'SESSION_UNAVAILABLE',
                ], 201);
            }

            return $this->json(['user' => $this->safeUser($user), 'token' => $token], 201);
        }

        if (in_array($action, ['forgot-password', 'request-reset'], true) && $method === 'POST') {
            $email = strtolower(trim((string) $request->input('email')));
            if ($email === '') return $this->json(['error' => 'Email is required'], 400);
            $user = $this->findUserByEmail($email);
            if (!$user) {
                return $this->json(['success' => true, 'message' => 'If an account exists with this email, a reset code has been sent.']);
            }

            $code = (string) random_int(100000, 999999);
            try {
                DB::table('auth_challenges')->updateOrInsert(
                    ['email' => $email, 'purpose' => 'password-reset'],
                    [
                        'code_hash' => hash('sha256', $code),
                        'attempts' => 0,
                        'expires_at' => now()->addMinutes(15),
                    ],
                );
            } catch (\Throwable $exception) {
                Log::error('Password reset challenge could not be stored.', ['error' => $exception->getMessage()]);
                return $this->json(['error' => 'Password reset is temporarily unavailable.'], 503);
            }

            $smtpOff = false;
            try {
                if (!config('mail.mailers.smtp.username') || !config('mail.mailers.smtp.password')) {
                    $smtpOff = true;
                } else {
                    Mail::raw("Your OG Landmark password reset code is {$code}. It expires in 15 minutes. Do not share this code.", function ($message) use ($email) {
                        $message->to($email)
                            ->subject('OG Landmark — Password Reset Code');
                    });
                }
            } catch (\Throwable $exception) {
                $smtpOff = true;
                Log::error('Password reset email could not be sent.', ['error' => $exception->getMessage()]);
            }

            return $this->json([
                'success' => true,
                'smtpOff' => $smtpOff,
                'message' => $smtpOff
                    ? 'Email service is not configured. Please contact admin to get your reset code.'
                    : 'Reset code sent. Check your email.',
            ]);
        }

        if (in_array($action, ['reset-password', 'confirm-reset'], true) && $method === 'POST') {
            $email = strtolower(trim((string) $request->input('email')));
            $code = trim((string) ($request->input('code') ?? $request->input('otp')));
            $newPassword = (string) $request->input('newPassword');
            if ($email === '' || $code === '' || $newPassword === '') {
                return $this->json(['error' => 'Email, code and new password are required'], 400);
            }
            if (strlen($newPassword) < 8) {
                return $this->json(['error' => 'Password must be at least 8 characters'], 400);
            }

            $user = $this->findUserByEmail($email);
            if (!$user) return $this->json(['error' => 'Invalid or expired reset code'], 400);
            $challenge = $this->consumeChallenge($email, 'password-reset', $code);
            if (!$challenge['ok']) {
                return $this->json([
                    'error' => $challenge['reason'] === 'expired'
                        ? 'Reset code has expired. Please request a new one.'
                        : 'Incorrect reset code. Please try again.',
                ], 400);
            }

            $data = JsonStore::read();
            $index = $this->indexById($data['users'] ?? [], $user['id']);
            if ($index === null) return $this->json(['error' => 'Invalid or expired reset code'], 400);
            $data['users'][$index]['password'] = $this->hashLegacyPassword($newPassword);
            JsonStore::write($data);
            $this->invalidateSessions($user['id']);
            return $this->json(['success' => true]);
        }

        if ($action === 'admin-verify' && $method === 'POST') {
            $user = $this->findUserByEmail((string) $request->input('email'));
            if (!$user || !$this->isAdmin($user) || !$this->verifyLegacyPassword((string) $request->input('password'), (string) ($user['password'] ?? ''))) {
                return $this->json(['error' => 'Invalid admin credentials.'], 401);
            }
            try {
                $token = $this->createSession($user);
            } catch (\Throwable $exception) {
                Log::error('Admin session could not be created.', ['error' => $exception->getMessage()]);
                return $this->json(['error' => 'Unable to start a session. Try again shortly.', 'code' => 'SESSION_UNAVAILABLE'], 503);
            }

            // Password login issues a token immediately (OTP optional / not required in this deploy).
            return $this->json([
                'success' => true,
                'message' => 'Admin verification successful.',
                'user' => $this->safeUser($user),
                'token' => $token,
            ]);
        }

        if ($action === 'admin-otp' && $method === 'POST') {
            // OTP is not configured; accept only when a prior admin-verify already issued a session.
            // For compatibility: re-check password if provided, else return clear 503.
            $email = (string) $request->input('email');
            $password = (string) $request->input('password', '');
            $user = $this->findUserByEmail($email);
            if ($user && $this->isAdmin($user) && $password !== '' && $this->verifyLegacyPassword($password, (string) ($user['password'] ?? ''))) {
                try {
                    $token = $this->createSession($user);
                } catch (\Throwable $exception) {
                    return $this->json(['error' => 'Unable to start a session.', 'code' => 'SESSION_UNAVAILABLE'], 503);
                }
                return $this->json(['user' => $this->safeUser($user), 'token' => $token]);
            }

            return $this->json([
                'error' => 'Admin OTP is not configured. Use password login (token is returned from admin-verify).',
                'code' => 'ADMIN_OTP_DISABLED',
            ], 503);
        }

        if ($action === 'change-password' && $method === 'POST') {
            $userId = $request->input('userId');
            $currentPassword = (string) $request->input('currentPassword', '');
            $newPassword = (string) $request->input('newPassword', '');
            if (!$userId || $newPassword === '') {
                return $this->json(['error' => 'userId and newPassword required'], 400);
            }
            if (strlen($newPassword) < 8) {
                return $this->json(['error' => 'New password must be at least 8 characters'], 400);
            }
            $data = JsonStore::read();
            $index = $this->indexById($data['users'] ?? [], $userId);
            if ($index === null) {
                return $this->json(['error' => 'User not found'], 404);
            }
            $user = $data['users'][$index];
            if ($currentPassword !== '' && !$this->verifyLegacyPassword($currentPassword, (string) ($user['password'] ?? ''))) {
                return $this->json(['error' => 'Current password is incorrect'], 400);
            }
            $data['users'][$index]['password'] = $this->hashLegacyPassword($newPassword);
            JsonStore::write($data);
            $this->invalidateSessions($user['id']);
            return $this->json(['success' => true, 'message' => 'Password changed successfully']);
        }

        if ($action === 'captcha' && $method === 'POST') {
            $secret = (string) env('RECAPTCHA_SECRET_KEY', '');
            if ($secret === '') {
                return $this->json(['success' => true, 'skipped' => true]);
            }
            $token = (string) $request->input('token', '');
            if ($token === '') {
                return $this->json(['success' => false, 'error' => 'CAPTCHA token missing'], 400);
            }
            try {
                $response = file_get_contents('https://www.google.com/recaptcha/api/siteverify', false, stream_context_create([
                    'http' => [
                        'method' => 'POST',
                        'header' => "Content-Type: application/x-www-form-urlencoded\r\n",
                        'content' => http_build_query(['secret' => $secret, 'response' => $token]),
                        'timeout' => 10,
                    ],
                ]));
                $payload = json_decode((string) $response, true);
                return $this->json(['success' => (bool) ($payload['success'] ?? false)]);
            } catch (\Throwable) {
                return $this->json(['success' => false, 'error' => 'CAPTCHA check failed'], 500);
            }
        }

        if (in_array($action, ['google', 'social'], true) && $method === 'POST') {
            $email = strtolower(trim((string) ($request->input('email') ?? $request->input('user')['email'] ?? '')));
            $name = trim((string) ($request->input('name') ?? $request->input('user')['name'] ?? 'OG Landmark User'));
            if ($email === '') {
                return $this->json(['error' => 'Email is required for social login.'], 400);
            }
            $data = JsonStore::read();
            $user = collect($data['users'] ?? [])->first(fn ($u) => strtolower((string) ($u['email'] ?? '')) === $email);
            if (!$user) {
                $user = [
                    'id' => JsonStore::nextId($data),
                    'name' => $name !== '' ? $name : 'OG Landmark User',
                    'email' => $email,
                    'role' => 'Buyer',
                    'status' => 'Active',
                    'password' => $this->hashLegacyPassword(bin2hex(random_bytes(16))),
                    'joinedDate' => now()->toISOString(),
                    'authProvider' => $action === 'google' ? 'google' : (string) ($request->input('provider') ?? 'social'),
                ];
                $data['users'][] = $user;
                JsonStore::write($data);
            }
            try {
                $token = $this->createSession($user);
            } catch (\Throwable $exception) {
                Log::error('Social login session could not be created.', ['error' => $exception->getMessage()]);
                return $this->json(['error' => 'Unable to start a session.', 'code' => 'SESSION_UNAVAILABLE'], 503);
            }
            return $this->json(['user' => $this->safeUser($user), 'token' => $token]);
        }

        return $this->json(['error' => 'Not found'], 404);
    }

    private function properties(Request $request, array $parts, string $method)
    {
        $id = $parts[0] ?? null;
        $action = $parts[1] ?? null;
        $user = $this->currentUser($request);
        $data = JsonStore::read();

        if ($method === 'GET' && $id === null) {
            $items = collect($data['properties'] ?? [])
                ->filter(fn ($p) => $this->propertyVisible($p, $user))
                ->filter(fn ($p) => $this->propertyMatches($p, $request))
                ->values();

            $nearby = $request->filled(['lat', 'lng', 'radiusKm']);
            if ($nearby) {
                $lat = (float) $request->input('lat');
                $lng = (float) $request->input('lng');
                $radius = (float) $request->input('radiusKm');
                $items = $items->map(function ($p) use ($lat, $lng) {
                    $p['distanceKm'] = $this->distanceKm($lat, $lng, $this->propertyLat($p), $this->propertyLng($p));
                    return $p;
                })->filter(fn ($p) => $p['distanceKm'] !== null && $p['distanceKm'] <= $radius)
                    ->sortBy('distanceKm')->values();
            }

            $offset = max(0, (int) $request->input('offset', 0));
            $limit = min(100, max(1, (int) $request->input('limit', 50)));
            $total = $items->count();
            $page = $items->slice($offset, $limit)->values()->all();
            if ($request->boolean('paginated') || $request->input('response') === 'page') {
                return $this->json(['items' => $page, 'total' => $total, 'offset' => $offset, 'limit' => $limit, 'hasMore' => $offset + count($page) < $total]);
            }
            return $this->json($page);
        }

        if ($method === 'GET' && $id !== null) {
            $property = $this->findById($data['properties'] ?? [], $id);
            if (!$property || !$this->propertyVisible($property, $user)) {
                return $this->json(['error' => 'Property not found'], 404);
            }
            return $this->json($property);
        }

        if ($method === 'POST' && $id === null) {
            $user = $this->currentUser($request, true);
            $payload = $request->all();
            $isAdmin = $this->isAdmin($user);
            $asActive = $isAdmin && ($request->boolean('publish') || strcasecmp((string) $request->input('approvalStatus', ''), 'Active') === 0);
            $sellerId = $request->input('sellerId', $user['id']);
            $seller = $this->findById($data['users'] ?? [], $sellerId) ?: $user;
            $property = array_merge($payload, [
                'id' => JsonStore::nextId($data),
                'sellerId' => $sellerId,
                'sellerName' => $seller['name'] ?? ($user['name'] ?? null),
                'createdAt' => now()->toISOString(),
                'updatedAt' => now()->toISOString(),
                'approvalStatus' => $asActive ? 'Active' : 'Pending',
                'listingStatus' => $asActive
                    ? 'Active'
                    : (($payload['submissionState'] ?? 'submitted') === 'draft' ? 'Draft' : 'Pending'),
                'views' => 0,
                'inquiryCount' => 0,
                'images' => array_values($payload['images'] ?? []),
                'featured' => $isAdmin ? $request->boolean('featured') : false,
                'priority' => $isAdmin ? $request->boolean('priority') : false,
                'createdByAdmin' => $isAdmin,
            ]);
            $data['properties'][] = $property;
            JsonStore::write($data);
            app(PropertySearchIndexer::class)->upsert($property);
            return $this->json($property, 201);
        }

        if ($id === null) {
            return $this->json(['error' => 'Property id is required.'], 400);
        }
        $index = $this->indexById($data['properties'] ?? [], $id);
        if ($index === null) {
            return $this->json(['error' => 'Property not found'], 404);
        }
        $property = $data['properties'][$index];

        if ($action === 'views' && $method === 'PATCH') {
            $data['properties'][$index]['views'] = ((int) ($property['views'] ?? 0)) + 1;
            JsonStore::write($data);
            app(PropertySearchIndexer::class)->upsert($data['properties'][$index]);
            return $this->json(['success' => true]);
        }

        $adminAction = in_array($action, ['approve', 'reject', 'request-changes', 'verify', 'feature', 'priority', 'assign-agent', 'resubmit'], true);
        if ($adminAction) {
            if ($action === 'resubmit') {
                $current = $this->currentUser($request, true);
                if (!$this->isAdmin($current) && (string) ($property['sellerId'] ?? $property['userId'] ?? '') !== (string) ($current['id'] ?? '') && (string) ($property['agentId'] ?? '') !== (string) ($current['id'] ?? '')) {
                    return $this->json(['error' => 'Forbidden'], 403);
                }
                $from = $property['approvalStatus'] ?? null;
                $data['properties'][$index]['approvalStatus'] = 'Pending';
                $data['properties'][$index]['listingStatus'] = 'Pending';
                $data['properties'][$index]['submissionState'] = 'submitted';
                $data['properties'][$index]['changeRequest'] = null;
                $data['properties'][$index]['rejectionReason'] = null;
                $data['properties'][$index]['reviewHistory'][] = [
                    'action' => 'resubmitted', 'by' => $current['id'], 'byName' => $current['name'] ?? null,
                    'fromStatus' => $from, 'toStatus' => 'Pending', 'createdAt' => now()->toISOString(),
                ];
                JsonStore::write($data);
                app(PropertySearchIndexer::class)->upsert($data['properties'][$index]);
                return $this->json(['success' => true, 'property' => $data['properties'][$index]]);
            }

            $admin = $this->currentUser($request, true);
            if (!$this->isAdmin($admin)) {
                return $this->json(['error' => 'Forbidden'], 403);
            }
            $from = $property['approvalStatus'] ?? $property['listingStatus'] ?? null;
            if ($action === 'approve' || $action === 'verify') {
                $data['properties'][$index]['approvalStatus'] = 'Active';
                $data['properties'][$index]['listingStatus'] = 'Active';
            } elseif ($action === 'reject') {
                $data['properties'][$index]['approvalStatus'] = 'Rejected';
                $data['properties'][$index]['rejectionReason'] = $request->input('reason');
            } elseif ($action === 'request-changes') {
                $data['properties'][$index]['approvalStatus'] = 'Changes Requested';
                $data['properties'][$index]['changeRequest'] = $request->input('reason');
            } elseif ($action === 'feature') {
                $data['properties'][$index]['featured'] = $request->has('featured') ? $request->boolean('featured') : !(bool) ($property['featured'] ?? false);
            } elseif ($action === 'priority') {
                $data['properties'][$index]['priority'] = $request->has('priority') ? $request->boolean('priority') : !(bool) ($property['priority'] ?? false);
                JsonStore::write($data);
                app(PropertySearchIndexer::class)->upsert($data['properties'][$index]);
                return $this->json(['success' => true, 'priority' => $data['properties'][$index]['priority']]);
            } elseif ($action === 'assign-agent') {
                if ($method === 'DELETE') {
                    unset($data['properties'][$index]['assignedAgent']);
                    JsonStore::write($data);
                    app(PropertySearchIndexer::class)->upsert($data['properties'][$index]);
                    return $this->json(['success' => true]);
                }
                $cityAgentId = $request->input('cityAgentId');
                if ($cityAgentId) {
                    $ca = $this->findById($data['cityAgents'] ?? [], $cityAgentId);
                    if (!$ca) {
                        return $this->json(['error' => 'City agent not found'], 404);
                    }
                    $data['properties'][$index]['assignedAgent'] = [
                        'cityAgentId' => $ca['id'], 'name' => $ca['name'] ?? null, 'phone' => $ca['phone'] ?? null,
                        'whatsapp' => $ca['whatsapp'] ?? null, 'city' => $ca['city'] ?? null,
                    ];
                } else {
                    $name = trim((string) $request->input('name', ''));
                    $phone = trim((string) $request->input('phone', ''));
                    if ($name === '' || $phone === '') {
                        return $this->json(['error' => 'name and phone required'], 400);
                    }
                    $whatsapp = trim((string) $request->input('whatsapp', '')) ?: preg_replace('/^0/', '92', $phone);
                    $data['properties'][$index]['assignedAgent'] = [
                        'name' => $name, 'phone' => $phone, 'whatsapp' => $whatsapp, 'city' => $property['city'] ?? '',
                    ];
                }
                JsonStore::write($data);
                app(PropertySearchIndexer::class)->upsert($data['properties'][$index]);
                return $this->json(['success' => true, 'assignedAgent' => $data['properties'][$index]['assignedAgent']]);
            }
            $data['properties'][$index]['reviewedAt'] = now()->toISOString();
            $data['properties'][$index]['reviewHistory'][] = [
                'action' => $action, 'reason' => $request->input('reason'), 'by' => $admin['id'],
                'fromStatus' => $from, 'toStatus' => $data['properties'][$index]['approvalStatus'] ?? null,
                'createdAt' => now()->toISOString(),
            ];
            JsonStore::write($data);
            app(PropertySearchIndexer::class)->upsert($data['properties'][$index]);
            return $this->json($data['properties'][$index]);
        }

        $current = $this->currentUser($request, true);
        if (!$this->isAdmin($current) && (string) ($property['sellerId'] ?? $property['userId'] ?? '') !== (string) ($current['id'] ?? '')) {
            return $this->json(['error' => 'Forbidden'], 403);
        }
        if ($method === 'DELETE') {
            $deletedId = $property['id'] ?? $id;
            array_splice($data['properties'], $index, 1);
            JsonStore::write($data);
            app(PropertySearchIndexer::class)->delete($deletedId);
            return $this->noContent();
        }
        if ($method === 'PATCH' && $action === 'listing-status') {
            $data['properties'][$index]['listingStatus'] = $request->input('listingStatus');
            $data['properties'][$index]['updatedAt'] = now()->toISOString();
            JsonStore::write($data);
            app(PropertySearchIndexer::class)->upsert($data['properties'][$index]);
            return $this->json($data['properties'][$index]);
        }
        if (in_array($method, ['PUT', 'PATCH'], true)) {
            $data['properties'][$index] = array_merge($property, $request->all(), [
                'id' => $property['id'],
                'updatedAt' => now()->toISOString(),
            ]);
            JsonStore::write($data);
            app(PropertySearchIndexer::class)->upsert($data['properties'][$index]);
            return $this->json($data['properties'][$index]);
        }

        return $this->json(['error' => 'Method not allowed'], 405);
    }

    private function myProperties(Request $request)
    {
        $user = $this->currentUser($request, true);
        return $this->json(collect(JsonStore::read()['properties'] ?? [])->filter(fn ($p) => (string) ($p['sellerId'] ?? $p['userId'] ?? '') === (string) $user['id'])->values());
    }

    private function admin(Request $request, array $parts, string $method)
    {
        $admin = $this->currentUser($request, true);
        if (!$this->isAdmin($admin)) return $this->json(['error' => 'Forbidden'], 403);
        $data = JsonStore::read();
        $resource = $parts[0] ?? '';
        $id = $parts[1] ?? null;
        if ($resource === 'stats' && $method === 'GET') {
            $properties = $data['properties'] ?? [];
            return $this->json([
                'totalProperties' => count($properties), 'totalUsers' => count($data['users'] ?? []),
                'totalAgents' => count($data['mobileAgents'] ?? []), 'totalInquiries' => count($data['inquiries'] ?? []),
                'pendingApprovals' => count(array_filter($properties, fn ($p) => in_array($p['approvalStatus'] ?? '', ['Pending', 'Changes Requested'], true))),
                'activeListings' => count(array_filter($properties, fn ($p) => ($p['listingStatus'] ?? $p['approvalStatus'] ?? '') === 'Active')),
                'featuredListings' => count(array_filter($properties, fn ($p) => !empty($p['featured']))),
                'totalViews' => array_sum(array_map(fn ($p) => (int) ($p['views'] ?? 0), $properties)),
            ]);
        }
        if ($resource === 'properties' && $method === 'GET' && $id === null) return $this->json($data['properties'] ?? []);
        if ($resource === 'properties' && $id !== null && ($parts[2] ?? '') === 'review' && $method === 'GET') {
            $property = $this->findById($data['properties'] ?? [], $id);
            if (!$property) return $this->json(['error' => 'Property not found'], 404);
            $seller = $this->findById($data['users'] ?? [], $property['sellerId'] ?? $property['userId'] ?? null);
            return $this->json([
                'property' => $property,
                'seller' => $seller ? $this->safeUser($seller) : null,
                'audit' => $property['reviewHistory'] ?? [],
            ]);
        }
        if ($resource === 'users' && $method === 'GET' && $id === null) return $this->json(array_map(fn ($u) => $this->safeUser($u), $data['users'] ?? []));
        if ($resource === 'users' && $id !== null && ($parts[2] ?? '') === 'activity' && $method === 'GET') {
            $items = collect($data['userActivity'] ?? [])
                ->filter(fn ($a) => (string) ($a['userId'] ?? '') === (string) $id)
                ->values();
            return $this->json($items);
        }
        if ($resource === 'users' && $id !== null && $method === 'PATCH' && ($parts[2] ?? '') === 'role') {
            $index = $this->indexById($data['users'] ?? [], $id);
            if ($index === null) return $this->json(['error' => 'User not found'], 404);
            $data['users'][$index]['role'] = $request->input('role', $data['users'][$index]['role']);
            JsonStore::write($data);
            return $this->json($this->safeUser($data['users'][$index]));
        }
        if ($resource === 'users' && $id !== null && $method === 'DELETE') {
            $index = $this->indexById($data['users'] ?? [], $id);
            if ($index === null) return $this->json(['error' => 'User not found'], 404);
            array_splice($data['users'], $index, 1); JsonStore::write($data); return $this->noContent();
        }
        if ($resource === 'reports') return $this->crudNamed($request, $data, 'reports', $id, $method);
        if ($resource === 'announcements') {
            if ($id !== null && ($parts[2] ?? '') === 'send' && $method === 'POST') {
                $index = $this->indexById($data['announcements'] ?? [], $id);
                if ($index === null) return $this->json(['error' => 'Announcement not found'], 404);
                $announcement = $data['announcements'][$index];
                $recipients = collect($data['users'] ?? []);
                $audience = $announcement['audience'] ?? [];
                if (!empty($audience['role'])) {
                    $recipients = $recipients->filter(fn ($u) => strcasecmp((string) ($u['role'] ?? ''), (string) $audience['role']) === 0);
                }
                if (!empty($audience['city'])) {
                    $recipients = $recipients->filter(fn ($u) => strcasecmp((string) ($u['city'] ?? ''), (string) $audience['city']) === 0);
                }
                $data['notifications'] ??= [];
                foreach ($recipients as $recipient) {
                    $data['notifications'][] = [
                        'id' => JsonStore::nextId($data),
                        'recipientUserId' => $recipient['id'],
                        'type' => 'ANNOUNCEMENT',
                        'title' => $announcement['title'] ?? 'Announcement',
                        'body' => $announcement['message'] ?? $announcement['body'] ?? '',
                        'createdAt' => now()->toISOString(),
                        'read' => false,
                    ];
                }
                $data['announcements'][$index]['status'] = 'sent';
                $data['announcements'][$index]['sentAt'] = now()->toISOString();
                $data['announcements'][$index]['recipientCount'] = $recipients->count();
                JsonStore::write($data);
                return $this->json($data['announcements'][$index]);
            }
            return $this->crudNamed($request, $data, 'announcements', $id, $method);
        }
        if ($resource === 'mobile-agents') {
            return $this->adminMobileAgents($request, $data, $id, $parts[2] ?? null, $method);
        }
        if ($resource === 'notifications' || $resource === 'conversations') {
            return $this->crudNamed($request, $data, $resource, $id, $method, $admin);
        }

        $adminResourceMap = [
            'buyer-requests' => 'buyerRequests',
            'verification-requests' => 'verificationRequests',
            'agent-leads' => 'agentLeads',
            'agent-visits' => 'agentVisits',
            'developer-projects' => 'developerProjects',
            'developer-units' => 'inventoryUnits',
            'developer-leads' => 'developerLeads',
            'developer-blocks' => 'developerBlocks',
            'developer-team' => 'developerTeam',
            'developer-documents' => 'developerDocuments',
            'developer-payment-plans' => 'developerPaymentPlans',
            'developer-promotions' => 'developerPromotions',
        ];
        if (isset($adminResourceMap[$resource])) {
            $key = $adminResourceMap[$resource];
            $data[$key] ??= [];
            if ($method === 'GET' && $id === null) {
                $items = collect($data[$key]);
                if ($request->filled('agentId')) {
                    $agentId = (string) $request->input('agentId');
                    $items = $items->filter(fn ($x) => (string) ($x['agentId'] ?? '') === $agentId);
                }
                if ($request->filled('projectId')) {
                    $projectId = (string) $request->input('projectId');
                    $items = $items->filter(fn ($x) => (string) ($x['projectId'] ?? '') === $projectId);
                }
                return $this->json($items->values());
            }
            return $this->crudNamed($request, $data, $key, $id, $method, $admin);
        }

        return $this->json(['error' => 'Not found'], 404);
    }

    private function users(Request $request, array $parts, string $method)
    {
        $data = JsonStore::read();
        $id = $parts[0] ?? null;

        if ($id === null) {
            $admin = $this->currentUser($request, true);
            if (!$this->isAdmin($admin)) return $this->json(['error' => 'Forbidden'], 403);
            if ($method === 'GET') {
                return $this->json(array_map(fn ($u) => $this->safeUser($u), $data['users'] ?? []));
            }
            if ($method === 'POST') {
                $email = strtolower(trim((string) $request->input('email', '')));
                $password = (string) $request->input('password', '');
                $name = trim((string) $request->input('name', ''));
                if ($email === '' || $password === '' || $name === '') {
                    return $this->json(['error' => 'Name, email and password are required'], 400);
                }
                if (collect($data['users'] ?? [])->contains(fn ($u) => strtolower((string) ($u['email'] ?? '')) === $email)) {
                    return $this->json(['error' => 'An account with this email already exists.'], 409);
                }
                $user = array_merge($request->except(['password']), [
                    'id' => JsonStore::nextId($data),
                    'name' => $name,
                    'email' => $email,
                    'role' => $request->input('role', 'Buyer'),
                    'status' => $request->input('status', 'Active'),
                    'password' => $this->hashLegacyPassword($password),
                    'joinedDate' => now()->toDateString(),
                    'createdByAdmin' => true,
                ]);
                $data['users'][] = $user;
                JsonStore::write($data);
                return $this->json($this->safeUser($user), 201);
            }
            return $this->json(['error' => 'Method not allowed'], 405);
        }

        $user = $this->currentUser($request);
        $index = $this->indexById($data['users'] ?? [], $id);
        if ($index === null) return $this->json(['error' => 'User not found'], 404);

        if ($method === 'GET') {
            return $this->json($this->safeUser($data['users'][$index]));
        }

        $actor = $this->currentUser($request, true);
        if ((string) $id !== (string) $actor['id'] && !$this->isAdmin($actor)) {
            return $this->json(['error' => 'Forbidden'], 403);
        }

        if ($method === 'PUT') {
            $allowed = ['name', 'phone', 'email', 'agencyName', 'companyName', 'city', 'profilePhoto', 'coverPhoto'];
            if ($this->isAdmin($actor)) {
                $allowed = array_merge($allowed, ['role', 'status']);
            }
            foreach ($allowed as $key) {
                if ($request->has($key)) {
                    $data['users'][$index][$key] = $request->input($key);
                }
            }
            if ($this->isAdmin($actor) && $request->filled('password')) {
                $password = (string) $request->input('password');
                if (strlen($password) < 8) {
                    return $this->json(['error' => 'Password must be at least 8 characters'], 400);
                }
                $data['users'][$index]['password'] = $this->hashLegacyPassword($password);
            }
            JsonStore::write($data);
            return $this->json($this->safeUser($data['users'][$index]));
        }
        if ($method === 'PATCH' && ($parts[1] ?? '') === 'push-token') {
            $data['users'][$index]['pushToken'] = $request->input('pushToken');
            JsonStore::write($data); return $this->json(['success' => true]);
        }
        if ($method === 'PATCH' && ($parts[1] ?? '') === 'status') {
            if (!$this->isAdmin($actor)) return $this->json(['error' => 'Forbidden'], 403);
            $data['users'][$index]['status'] = $request->input('status', $data['users'][$index]['status'] ?? 'Active');
            JsonStore::write($data);
            return $this->json($this->safeUser($data['users'][$index]));
        }
        if ($method === 'PATCH' && ($parts[1] ?? '') === 'password') {
            $newPassword = (string) $request->input('newPassword', '');
            $currentPassword = (string) $request->input('currentPassword', '');
            if (strlen($newPassword) < 8) return $this->json(['error' => 'Password must be at least 8 characters'], 400);
            if ($currentPassword !== '' && !$this->verifyLegacyPassword($currentPassword, (string) ($data['users'][$index]['password'] ?? ''))) {
                return $this->json(['error' => 'Current password is incorrect'], 400);
            }
            $data['users'][$index]['password'] = $this->hashLegacyPassword($newPassword);
            JsonStore::write($data);
            return $this->json(['success' => true]);
        }
        if ($method === 'DELETE') {
            if (!$this->isAdmin($actor)) return $this->json(['error' => 'Forbidden'], 403);
            array_splice($data['users'], $index, 1);
            JsonStore::write($data);
            return $this->noContent();
        }
        return $this->json($this->safeUser($data['users'][$index]));
    }

    private function account(Request $request, array $parts, string $method)
    {
        $user = $this->currentUser($request, true);
        $data = JsonStore::read();
        $index = $this->indexById($data['users'] ?? [], $user['id']);
        if ($index === null) return $this->json(['error' => 'Account not found'], 404);
        $photo = $parts[0] ?? null;
        if ($photo && in_array($photo, ['profile-photo', 'cover-photo'], true)) {
            $key = $photo === 'profile-photo' ? 'profilePhoto' : 'coverPhoto';
            if ($method === 'GET') return $this->json(['url' => $data['users'][$index][$key] ?? null]);
            if ($method === 'DELETE') { $data['users'][$index][$key] = null; JsonStore::write($data); return $this->noContent(); }
            if ($method === 'PUT') { $data['users'][$index][$key] = $request->input('url'); JsonStore::write($data); return $this->json(['url' => $data['users'][$index][$key]]); }
        }
        if ($method === 'GET') return $this->json($this->safeUser($data['users'][$index]));
        if ($method === 'DELETE') { array_splice($data['users'], $index, 1); JsonStore::write($data); $this->destroySession($request); return $this->noContent(); }
        if ($method === 'PUT') {
            foreach (['name', 'phone', 'city', 'agencyName', 'companyName', 'profilePhoto', 'coverPhoto'] as $key) if ($request->has($key)) $data['users'][$index][$key] = $request->input($key);
            JsonStore::write($data); return $this->json($this->safeUser($data['users'][$index]));
        }
        return $this->json(['error' => 'Method not allowed'], 405);
    }

    private function saved(Request $request, array $parts, string $method)
    {
        $user = $this->currentUser($request, true);
        $data = JsonStore::read();
        $userId = $parts[0] ?? $user['id'];
        if ((string) $userId !== (string) $user['id'] && !$this->isAdmin($user)) return $this->json(['error' => 'Forbidden'], 403);
        $saved = $data['savedProperties'] ?? [];
        if (is_array($saved) && array_is_list($saved)) $saved = [$userId => $saved];
        $saved[(string) $userId] = array_values($saved[(string) $userId] ?? []);
        if ($method === 'GET' && count($parts) === 1) return $this->json($saved[(string) $userId]);
        $propertyId = $parts[1] ?? null;
        if ($method === 'POST' && $propertyId !== null) {
            $key = array_search((int) $propertyId, array_map('intval', $saved[(string) $userId]), true);
            if ($key === false) { $saved[(string) $userId][] = (int) $propertyId; $isSaved = true; }
            else { array_splice($saved[(string) $userId], $key, 1); $isSaved = false; }
            $data['savedProperties'] = $saved; JsonStore::write($data); return $this->json(['saved' => $isSaved]);
        }
        return $this->json(['error' => 'Not found'], 404);
    }

    private function notifications(Request $request, array $segments, string $method)
    {
        $user = $this->currentUser($request, true);
        $data = JsonStore::read();
        if (($segments[0] ?? '') === 'notification-preferences') {
            $key = 'notificationPreferences';
            $preferences = $data[$key][(string) $user['id']] ?? [
                'properties' => true, 'projects' => true, 'announcements' => true,
                'promotional' => true, 'account' => true, 'system' => true, 'frequency' => 'immediate',
            ];
            if ($method === 'PUT') { $preferences = array_merge($preferences, $request->all()); $data[$key][(string) $user['id']] = $preferences; JsonStore::write($data); }
            return $this->json($preferences);
        }
        $items = collect($data['notifications'] ?? [])->filter(fn ($n) => (string) ($n['recipientUserId'] ?? $n['userId'] ?? $n['forUserId'] ?? '') === (string) $user['id'])->values();
        $id = $segments[1] ?? null;
        $sub = $segments[2] ?? null;
        if ($id === 'unread-count') return $this->json(['unreadCount' => $items->filter(fn ($n) => empty($n['read']) && empty($n['isRead']))->count()]);
        if ($id === 'mark-all-read' && in_array($method, ['PATCH', 'POST'], true)) {
            foreach ($data['notifications'] ?? [] as $index => $notification) if ((string) ($notification['recipientUserId'] ?? $notification['userId'] ?? '') === (string) $user['id']) { $data['notifications'][$index]['read'] = true; $data['notifications'][$index]['isRead'] = true; $data['notifications'][$index]['readAt'] = now()->toISOString(); }
            JsonStore::write($data); return $this->json(['success' => true]);
        }
        if ($method === 'GET') {
            $page = max(1, (int) $request->input('page', 1)); $limit = min(100, max(1, (int) $request->input('limit', 25)));
            $pageItems = $items->forPage($page, $limit)->values()->all();
            // Flat array when ?flat=1 or Accept legacy portal clients; default keep pagination object
            if ($request->boolean('flat') || $request->input('format') === 'array') {
                return $this->json($pageItems);
            }
            return $this->json(['items' => $pageItems, 'page' => $page, 'limit' => $limit, 'total' => $items->count(), 'hasMore' => $page * $limit < $items->count(), 'unreadCount' => $items->filter(fn ($n) => empty($n['read']) && empty($n['isRead']))->count()]);
        }
        if ($id !== null) {
            $index = $this->indexById($data['notifications'] ?? [], $id);
            if ($index === null) return $this->json(['error' => 'Notification not found'], 404);
            // Alias: PATCH|POST /api/notifications/{id}/read
            if (($sub === 'read' && in_array($method, ['PATCH', 'POST'], true)) || ($method === 'PATCH' && $sub === null)) {
                $data['notifications'][$index]['read'] = true;
                $data['notifications'][$index]['isRead'] = true;
                JsonStore::write($data);
                return $this->json($data['notifications'][$index]);
            }
            if ($method === 'DELETE') { array_splice($data['notifications'], $index, 1); JsonStore::write($data); return $this->noContent(); }
        }
        return $this->json(['error' => 'Method not allowed'], 405);
    }

    private function upload(Request $request, array $parts)
    {
        $user = $this->currentUser($request, true);
        $field = ($parts[0] ?? '') === 'video' ? 'video' : (($parts[0] ?? '') === 'single' ? 'image' : 'images');
        $files = $request->file($field);
        $files = is_array($files) ? $files : ($files ? [$files] : []);
        if (!$files) return $this->json(['error' => 'No upload received.'], 422);
        $mediaStorage = app(MediaStorage::class);
        try {
            $mediaStorage->ensureReady();
        } catch (\Throwable $exception) {
            Log::error('Media storage is not ready for upload.', ['error' => $exception->getMessage()]);

            return $this->json([
                'error' => 'Media storage is not available. Contact the administrator.',
                'code' => 'MEDIA_STORAGE_NOT_READY',
            ], 503);
        }
        $directory = $mediaStorage->directory();
        $urls = [];
        $media = [];
        foreach ($files as $file) {
            if (!$file->isValid() || !in_array(strtolower($file->getClientOriginalExtension()), ['jpg', 'jpeg', 'png', 'webp', 'mp4', 'mov'], true)) {
                return $this->json(['error' => 'Allowed: JPG, PNG, WebP, MP4, MOV'], 422);
            }
            $name = now()->format('YmdHis') . '-' . Str::random(24) . '.' . strtolower($file->getClientOriginalExtension());
            $file->move($directory, $name);
            $path = '/images/uploads/' . $name;
            $url = $mediaStorage->url($path);
            $urls[] = $url;
            $media[] = [
                'url' => $url,
                'path' => $path,
                'mimeType' => $file->getMimeType(),
                'bytes' => filesize($directory . DIRECTORY_SEPARATOR . $name) ?: 0,
                'kind' => str_starts_with((string) $file->getMimeType(), 'video/') ? 'video' : 'image',
            ];
        }
        return $this->json(count($urls) === 1
            ? ['url' => $urls[0], 'media' => $media[0]]
            : ['urls' => $urls, 'media' => $media]);
    }

    private function mobile(Request $request, array $parts, string $method)
    {
        $resource = $parts[0] ?? '';
        $data = JsonStore::read();
        if ($resource === 'settings') {
            $settings = $data['mobileSettings'] ?? [
                'verificationBadgeEnabled' => true, 'pushNotificationsEnabled' => true,
                'darkModeEnabled' => true, 'maintenanceMode' => false, 'maintenanceMessage' => '',
                'appVersion' => '1.0.0', 'minAppVersion' => '1.0.0', 'content' => [],
            ];
            if ($method === 'GET') return $this->json($settings);
            $admin = $this->currentUser($request, true); if (!$this->isAdmin($admin)) return $this->json(['error' => 'Forbidden'], 403);
            $settings = $this->deepMerge($settings, $request->all()); $data['mobileSettings'] = $settings; JsonStore::write($data);
            return $this->json(['success' => true, 'settings' => $settings]);
        }
        if ($resource === 'banners') {
            $all = $data['banners'] ?? [];
            if ($method === 'GET' && ($parts[1] ?? '') !== 'all') return $this->json(array_values(array_filter($all, fn ($b) => ($b['active'] ?? true) === true)));
            $admin = $this->currentUser($request, true); if (!$this->isAdmin($admin)) return $this->json(['error' => 'Forbidden'], 403);
            if ($method === 'GET') return $this->json($all);
            $id = $parts[1] ?? null;
            if ($method === 'POST') { $banner = array_merge($request->except(['media']), ['id' => JsonStore::nextId($data), 'active' => $request->has('active') ? $request->boolean('active') : true, 'order' => (int) $request->input('order', count($all))]); $data['banners'][] = $banner; JsonStore::write($data); return $this->json(['success' => true, 'banner' => $banner], 201); }
            $index = $this->indexById($all, $id); if ($index === null) return $this->json(['error' => 'Banner not found'], 404);
            if ($method === 'DELETE') { array_splice($data['banners'], $index, 1); JsonStore::write($data); return $this->json(['success' => true]); }
            if ($method === 'PATCH' && ($parts[2] ?? '') === 'toggle') { $data['banners'][$index]['active'] = !($data['banners'][$index]['active'] ?? false); JsonStore::write($data); return $this->json(['success' => true, 'active' => $data['banners'][$index]['active']]); }
            $data['banners'][$index] = array_merge($data['banners'][$index], $request->all()); JsonStore::write($data); return $this->json(['success' => true, 'banner' => $data['banners'][$index]]);
        }
        if ($resource === 'push' && $method === 'POST') {
            $admin = $this->currentUser($request, true); if (!$this->isAdmin($admin)) return $this->json(['error' => 'Forbidden'], 403);
            return $this->json(['success' => true, 'sent' => 0, 'totalRecipients' => count($data['users'] ?? []), 'title' => $request->input('title'), 'body' => $request->input('body'), 'sentAt' => now()->toISOString()]);
        }
        if ($resource === 'stats' && $method === 'GET') return $this->adminStats($data);
        if ($resource === 'developer-analytics' && $method === 'GET') return $this->json(['projects' => count($data['developerProjects'] ?? []), 'leads' => count($data['developerLeads'] ?? []), 'units' => count($data['inventoryUnits'] ?? []), 'generatedAt' => now()->toISOString()]);
        return $this->json(['error' => 'Not found'], 404);
    }

    private function blog(Request $request, array $parts, string $method)
    {
        $data = JsonStore::read();
        $posts = $data['blogPosts'] ?? [];
        $id = $parts[0] ?? null;

        if ($method === 'GET') {
            if ($id === null) {
                return $this->json(collect($posts)->filter(fn ($p) => $p['published'] ?? true)->take((int) $request->input('limit', 50))->values());
            }
            $post = $this->findById($posts, $id);
            return $post ? $this->json($post) : $this->json(['error' => 'Post not found'], 404);
        }

        $admin = $this->currentUser($request, true);
        if (!$this->isAdmin($admin)) return $this->json(['error' => 'Forbidden'], 403);

        if ($method === 'POST' && $id === null) {
            $post = array_merge($request->all(), [
                'id' => JsonStore::nextId($data),
                'published' => $request->has('published') ? $request->boolean('published') : true,
                'createdAt' => now()->toISOString(),
                'authorId' => $admin['id'],
            ]);
            $data['blogPosts'][] = $post;
            JsonStore::write($data);
            return $this->json($post, 201);
        }

        $index = $this->indexById($posts, $id);
        if ($index === null) return $this->json(['error' => 'Post not found'], 404);
        if ($method === 'DELETE') {
            array_splice($data['blogPosts'], $index, 1);
            JsonStore::write($data);
            return $this->noContent();
        }
        if (in_array($method, ['PUT', 'PATCH'], true)) {
            $data['blogPosts'][$index] = array_merge($data['blogPosts'][$index], $request->all());
            JsonStore::write($data);
            return $this->json($data['blogPosts'][$index]);
        }
        return $this->json(['error' => 'Method not allowed'], 405);
    }

    private function agents(Request $request, array $segments, string $method)
    {
        $data = JsonStore::read();
        $resource = $segments[0] ?? '';
        $id = $segments[1] ?? null;
        $action = $segments[2] ?? null;

        if ($resource === 'mobile-agents') {
            if ($method === 'GET') {
                $items = collect($data['mobileAgents'] ?? [])
                    ->filter(fn ($a) => ($a['visible'] ?? true) !== false && ($a['status'] ?? '') !== 'Suspended' && ($a['approvalStatus'] ?? '') !== 'Rejected')
                    ->when($request->filled('city'), function ($c) use ($request) {
                        $city = strtolower((string) $request->input('city'));
                        return $c->filter(fn ($a) => collect($a['areas'] ?? [])->contains(fn ($area) => strtolower((string) $area) === $city));
                    })
                    ->values();
                if ($request->filled('limit')) $items = $items->take(max(0, (int) $request->input('limit')));
                return $this->json($items->map(fn ($a) => $this->safeMobileAgent($a))->values());
            }
            return $this->json(['error' => 'Method not allowed'], 405);
        }

        // /api/agents — Node returns users with role Agent (+ approved mobileAgents when filtered)
        if ($method === 'GET' && $id === null) {
            $agents = collect($data['users'] ?? [])->filter(fn ($u) => strcasecmp((string) ($u['role'] ?? ''), 'Agent') === 0);
            if ($request->filled('approvalStatus')) {
                $status = (string) $request->input('approvalStatus');
                $agents = $agents->filter(fn ($a) => ($a['approvalStatus'] ?? '') === $status);
            }
            if ($request->filled('city')) {
                $city = strtolower((string) $request->input('city'));
                $agents = $agents->filter(fn ($a) => strtolower((string) ($a['city'] ?? '')) === $city);
            }
            if ($request->input('approvalStatus') === 'Approved') {
                $mobile = collect($data['mobileAgents'] ?? [])->filter(fn ($a) =>
                    ($a['approvalStatus'] ?? '') === 'Approved'
                    && ($a['status'] ?? '') === 'Active'
                    && ($a['visible'] ?? true) !== false
                );
                $agents = $agents->concat($mobile);
            }
            if ($request->filled('status')) {
                $st = (string) $request->input('status');
                $agents = $agents->filter(fn ($a) => ($a['status'] ?? 'Active') === $st);
            }
            if ($request->filled('limit')) $agents = $agents->take(max(0, (int) $request->input('limit')));
            return $this->json($agents->map(fn ($a) => $this->safeMobileAgent($a))->values());
        }

        $admin = $this->currentUser($request, true);
        if (!$this->isAdmin($admin)) return $this->json(['error' => 'Forbidden'], 403);

        if ($method === 'POST' && $id === null) {
            $name = trim((string) $request->input('name', ''));
            $email = strtolower(trim((string) $request->input('email', '')));
            $password = (string) $request->input('password', '');
            if ($name === '' || $email === '' || $password === '') {
                return $this->json(['error' => 'Name, email and password are required'], 400);
            }
            if (strlen($password) < 8) return $this->json(['error' => 'Password must be at least 8 characters'], 400);
            if (collect($data['users'] ?? [])->contains(fn ($u) => strtolower((string) ($u['email'] ?? '')) === $email)) {
                return $this->json(['error' => 'A user with this email already exists'], 409);
            }
            $agent = [
                'id' => JsonStore::nextId($data),
                'name' => $name,
                'email' => $email,
                'phone' => $request->input('phone', ''),
                'role' => 'Agent',
                'status' => 'Active',
                'approvalStatus' => 'Approved',
                'password' => $this->hashLegacyPassword($password),
                'joinedDate' => now()->toDateString(),
                'createdByAdmin' => true,
                'photo' => $request->input('photo'),
                'specialization' => $request->input('specialization', ''),
                'title' => $request->input('title', ''),
                'bio' => $request->input('bio', ''),
                'experience' => $request->input('experience', ''),
                'license' => $request->input('license', ''),
                'city' => $request->input('city', ''),
                'languages' => $request->input('languages', ''),
                'rating' => $request->input('rating'),
            ];
            $data['users'][] = $agent;
            JsonStore::write($data);
            return $this->json($this->safeUser($agent), 201);
        }

        $index = $this->indexById($data['users'] ?? [], $id);
        if ($index === null || strcasecmp((string) ($data['users'][$index]['role'] ?? ''), 'Agent') !== 0) {
            return $this->json(['error' => 'Agent not found'], 404);
        }

        if ($method === 'DELETE') {
            array_splice($data['users'], $index, 1);
            JsonStore::write($data);
            return $this->json(['success' => true]);
        }

        if ($method === 'PATCH' && $action === 'approve') {
            $data['users'][$index]['approvalStatus'] = 'Approved';
            $data['users'][$index]['status'] = 'Active';
            $data['users'][$index]['approvedAt'] = now()->toISOString();
            JsonStore::write($data);
            return $this->json(['success' => true, 'agent' => $this->safeUser($data['users'][$index])]);
        }
        if ($method === 'PATCH' && $action === 'reject') {
            $data['users'][$index]['approvalStatus'] = 'Rejected';
            $data['users'][$index]['status'] = 'Suspended';
            $data['users'][$index]['rejectedAt'] = now()->toISOString();
            $data['users'][$index]['rejectReason'] = $request->input('reason', '');
            JsonStore::write($data);
            return $this->json(['success' => true, 'agent' => $this->safeUser($data['users'][$index])]);
        }
        if ($method === 'PATCH' && $action === 'credentials') {
            $email = $request->input('email');
            $password = $request->input('password');
            if (!$email && !$password) return $this->json(['error' => 'Provide email or password to update'], 400);
            if ($email) {
                $conflict = collect($data['users'] ?? [])->first(fn ($u) => strtolower((string) ($u['email'] ?? '')) === strtolower((string) $email) && (string) $u['id'] !== (string) $id);
                if ($conflict) return $this->json(['error' => 'Email already in use by another account'], 409);
                $data['users'][$index]['email'] = $email;
            }
            if ($password) {
                if (strlen((string) $password) < 8) return $this->json(['error' => 'Password must be at least 8 characters'], 400);
                $data['users'][$index]['password'] = $this->hashLegacyPassword((string) $password);
            }
            $data['users'][$index]['credentialsUpdatedAt'] = now()->toISOString();
            JsonStore::write($data);
            return $this->json(['success' => true, 'agent' => $this->safeUser($data['users'][$index])]);
        }
        if ($method === 'PATCH' && $action === 'status') {
            $data['users'][$index]['status'] = $request->input('status', ($data['users'][$index]['status'] ?? '') === 'Active' ? 'Suspended' : 'Active');
            JsonStore::write($data);
            return $this->json(['success' => true, 'agent' => $this->safeUser($data['users'][$index])]);
        }

        return $this->json(['error' => 'Method not allowed'], 405);
    }

    private function siteContent(Request $request, string $method)
    {
        $data = JsonStore::read();
        $content = SiteContent::resolve($data['siteContent'] ?? null);

        if ($method === 'GET') {
            return $this->json($content);
        }

        if ($method === 'PUT' || $method === 'PATCH') {
            $admin = $this->currentUser($request, true);
            if (!$this->isAdmin($admin)) {
                return $this->json(['error' => 'Forbidden'], 403);
            }
            $incoming = $request->all();
            unset($incoming['updatedAt']);
            $merged = SiteContent::deepMerge($content, $incoming);
            $merged['updatedAt'] = now()->toISOString();
            $data['siteContent'] = $merged;
            JsonStore::write($data);
            return $this->json($merged);
        }

        return $this->json(['error' => 'Method not allowed'], 405);
    }

    private function settings(Request $request, array $parts, string $method)
    {
        $key = $parts[0] ?? '';
        if ($key !== 'hidden-react-agents') {
            return $this->json(['error' => 'Not found'], 404);
        }
        $data = JsonStore::read();
        if ($method === 'GET') {
            return $this->json($data['hiddenReactAgents'] ?? []);
        }
        if ($method === 'POST') {
            $admin = $this->currentUser($request, true);
            if (!$this->isAdmin($admin)) return $this->json(['error' => 'Forbidden'], 403);
            $name = trim((string) $request->input('name', ''));
            if ($name === '') return $this->json(['error' => 'name required'], 400);
            $hidden = $request->boolean('hidden');
            $list = $data['hiddenReactAgents'] ?? [];
            if ($hidden) {
                if (!in_array($name, $list, true)) $list[] = $name;
            } else {
                $list = array_values(array_filter($list, fn ($n) => $n !== $name));
            }
            $data['hiddenReactAgents'] = $list;
            JsonStore::write($data);
            return $this->json(['success' => true, 'hiddenReactAgents' => $list]);
        }
        return $this->json(['error' => 'Method not allowed'], 405);
    }

    private function cityAgents(Request $request, array $parts, string $method)
    {
        $data = JsonStore::read();
        $id = $parts[0] ?? null;
        $items = $data['cityAgents'] ?? [];

        if ($method === 'GET' && $id === null) {
            $filtered = collect($items)
                ->when($request->filled('city'), fn ($c) => $c->filter(fn ($a) => strcasecmp((string) ($a['city'] ?? ''), (string) $request->input('city')) === 0))
                ->values();
            return $this->json($filtered);
        }

        $admin = $this->currentUser($request, true);
        if (!$this->isAdmin($admin)) return $this->json(['error' => 'Forbidden'], 403);

        if ($method === 'POST' && $id === null) {
            $city = trim((string) $request->input('city', ''));
            $name = trim((string) $request->input('name', ''));
            $phone = trim((string) $request->input('phone', ''));
            if ($city === '' || $name === '' || $phone === '') {
                return $this->json(['error' => 'city, name and phone are required'], 400);
            }
            $whatsapp = trim((string) $request->input('whatsapp', '')) ?: preg_replace('/^0/', '92', $phone);
            $agent = ['id' => JsonStore::nextId($data), 'city' => $city, 'name' => $name, 'phone' => $phone, 'whatsapp' => $whatsapp, 'active' => true];
            $data['cityAgents'][] = $agent;
            JsonStore::write($data);
            return $this->json($agent, 201);
        }

        $index = $this->indexById($items, $id);
        if ($index === null) return $this->json(['error' => 'Agent not found'], 404);
        if ($method === 'PUT') {
            $data['cityAgents'][$index] = array_merge($data['cityAgents'][$index], $request->all(), ['id' => $data['cityAgents'][$index]['id']]);
            JsonStore::write($data);
            return $this->json($data['cityAgents'][$index]);
        }
        if ($method === 'DELETE') {
            array_splice($data['cityAgents'], $index, 1);
            JsonStore::write($data);
            return $this->json(['success' => true]);
        }
        return $this->json(['error' => 'Method not allowed'], 405);
    }

    private function savedSearches(Request $request, array $parts, string $method)
    {
        $user = $this->currentUser($request, true);
        $data = JsonStore::read();
        $data['savedSearches'] ??= [];
        $id = $parts[0] ?? null;

        if ($method === 'GET' && $id === null) {
            return $this->json(collect($data['savedSearches'])->filter(fn ($x) => (string) ($x['userId'] ?? '') === (string) $user['id'])->values());
        }
        if ($method === 'POST' && $id === null) {
            if (!$request->filled('label') || !$request->filled('query')) {
                return $this->json(['error' => 'label and query are required'], 400);
            }
            $item = array_merge($request->all(), [
                'id' => JsonStore::id('search'),
                'userId' => $user['id'],
                'savedAt' => now()->toISOString(),
            ]);
            $data['savedSearches'][] = $item;
            JsonStore::write($data);
            return $this->json($item, 201);
        }
        if ($method === 'DELETE' && $id === null) {
            $data['savedSearches'] = array_values(array_filter($data['savedSearches'], fn ($x) => (string) ($x['userId'] ?? '') !== (string) $user['id']));
            JsonStore::write($data);
            return $this->noContent();
        }
        if ($method === 'DELETE' && $id !== null) {
            $index = null;
            foreach ($data['savedSearches'] as $i => $item) {
                if ((string) ($item['id'] ?? '') === (string) $id && (string) ($item['userId'] ?? '') === (string) $user['id']) {
                    $index = $i;
                    break;
                }
            }
            if ($index === null) return $this->json(['error' => 'Not found'], 404);
            array_splice($data['savedSearches'], $index, 1);
            JsonStore::write($data);
            return $this->noContent();
        }
        return $this->json(['error' => 'Method not allowed'], 405);
    }

    private function announcements(Request $request, array $parts, string $method)
    {
        $user = $this->currentUser($request, true);
        $id = $parts[0] ?? null;
        if ($method !== 'GET' || $id === null) {
            return $this->json(['error' => 'Not found'], 404);
        }
        $announcement = $this->findById(JsonStore::read()['announcements'] ?? [], $id);
        if (!$announcement || ($announcement['status'] ?? '') !== 'sent') {
            return $this->json(['error' => 'Announcement is no longer available.'], 404);
        }
        if (!empty($announcement['expiresAt']) && now()->greaterThan($announcement['expiresAt'])) {
            return $this->json(['error' => 'Announcement is no longer available.'], 404);
        }
        $audience = $announcement['audience'] ?? [];
        if (!empty($audience['role']) && strcasecmp((string) ($user['role'] ?? ''), (string) $audience['role']) !== 0) {
            return $this->json(['error' => 'This announcement is not available for your account.'], 403);
        }
        return $this->json($announcement);
    }

    private function projects(Request $request, array $parts, string $method)
    {
        $data = JsonStore::read();
        $projects = $data['developerProjects'] ?? $data['projects'] ?? [];
        $id = $parts[0] ?? null;
        if ($method !== 'GET') return $this->json(['error' => 'Method not allowed'], 405);
        if ($id === null) return $this->json(array_values($projects));
        $project = $this->findById($projects, $id);
        return $project ? $this->json($project) : $this->json(['error' => 'Not found'], 404);
    }

    private function adminMobileAgents(Request $request, array &$data, ?string $id, ?string $sub, string $method)
    {
        $data['mobileAgents'] ??= [];
        if ($method === 'GET' && $id === null) {
            return $this->json(collect($data['mobileAgents'])->map(fn ($a) => $this->safeMobileAgent($a, true))->values());
        }
        if ($method === 'POST' && $id === null) {
            $name = trim((string) ($request->input('name') ?? $request->input('displayName') ?? ''));
            $email = strtolower(trim((string) $request->input('email', '')));
            $password = (string) $request->input('password', '');
            if ($name === '' || $email === '' || $password === '') {
                return $this->json(['error' => 'Agent name, email and password are required'], 400);
            }
            if (strlen($password) < 8) return $this->json(['error' => 'Password must be at least 8 characters'], 400);
            if (collect($data['users'] ?? [])->contains(fn ($u) => strtolower((string) ($u['email'] ?? '')) === $email)) {
                return $this->json(['error' => 'This login email is already in use.'], 409);
            }
            $agentId = JsonStore::nextId($data);
            $authUserId = JsonStore::nextId($data);
            $now = now()->toISOString();
            $areas = $request->input('areas', []);
            if (!is_array($areas)) $areas = array_filter(array_map('trim', explode(',', (string) $areas)));
            $specialties = $request->input('specialties', []);
            if (!is_array($specialties)) $specialties = array_filter(array_map('trim', explode(',', (string) $specialties)));
            $agent = [
                'id' => $agentId, 'name' => $name, 'displayName' => $name,
                'initials' => strtoupper(substr(preg_replace('/\s+/', '', $name) ?: 'AG', 0, 2)),
                'agency' => trim((string) $request->input('agency', '')),
                'verified' => $request->has('verified') ? $request->boolean('verified') : true,
                'approvalStatus' => $request->input('approvalStatus', 'Approved'),
                'status' => $request->input('status', 'Active'),
                'visible' => $request->has('visible') ? $request->boolean('visible') : true,
                'rating' => (float) $request->input('rating', 0),
                'reviewCount' => (int) $request->input('reviewCount', 0),
                'years' => (int) $request->input('years', 0),
                'listings' => (int) $request->input('listings', 0),
                'areas' => array_values($areas), 'color' => $request->input('color', '#102a43'),
                'phone' => trim((string) $request->input('phone', '')),
                'specialties' => array_values($specialties), 'photo' => $request->input('photo'),
                'about' => trim((string) $request->input('about', '')),
                'email' => $email, 'authUserId' => $authUserId, 'createdAt' => $now, 'updatedAt' => $now,
            ];
            $data['users'][] = [
                'id' => $authUserId, 'name' => $name, 'email' => $email, 'phone' => $agent['phone'],
                'role' => 'Agent', 'status' => $agent['status'], 'approvalStatus' => $agent['approvalStatus'],
                'password' => $this->hashLegacyPassword($password), 'joinedDate' => now()->toDateString(),
                'createdByAdmin' => true, 'agencyName' => $agent['agency'],
                'specialization' => implode(', ', $specialties), 'experience' => $agent['years'],
                'city' => implode(', ', $areas), 'title' => 'Property Agent', 'photo' => $agent['photo'],
            ];
            $data['mobileAgents'][] = $agent;
            JsonStore::write($data);
            return $this->json($this->safeMobileAgent($agent, true), 201);
        }

        $index = $this->indexById($data['mobileAgents'], $id);
        if ($index === null) return $this->json(['error' => 'Mobile agent not found'], 404);
        $agent = &$data['mobileAgents'][$index];

        if ($method === 'DELETE') {
            $authUserId = $agent['authUserId'] ?? null;
            array_splice($data['mobileAgents'], $index, 1);
            if ($authUserId) {
                $ui = $this->indexById($data['users'] ?? [], $authUserId);
                if ($ui !== null) array_splice($data['users'], $ui, 1);
            }
            JsonStore::write($data);
            return $this->json(['success' => true]);
        }

        if ($method === 'PATCH' && $sub === 'status') {
            $agent['status'] = $request->input('status', ($agent['status'] ?? '') === 'Active' ? 'Suspended' : 'Active');
            $agent['updatedAt'] = now()->toISOString();
            $ui = $this->indexById($data['users'] ?? [], $agent['authUserId'] ?? null);
            if ($ui !== null) $data['users'][$ui]['status'] = $agent['status'] === 'Suspended' ? 'Suspended' : 'Active';
            JsonStore::write($data);
            return $this->json(['success' => true, 'agent' => $this->safeMobileAgent($agent, true)]);
        }
        if ($method === 'PATCH' && $sub === 'approval') {
            $agent['approvalStatus'] = $request->input('approvalStatus', 'Approved');
            $agent['status'] = $agent['approvalStatus'] === 'Rejected' ? 'Suspended' : 'Active';
            $agent['updatedAt'] = now()->toISOString();
            $ui = $this->indexById($data['users'] ?? [], $agent['authUserId'] ?? null);
            if ($ui !== null) {
                $data['users'][$ui]['approvalStatus'] = $agent['approvalStatus'];
                $data['users'][$ui]['status'] = $agent['status'];
            }
            JsonStore::write($data);
            return $this->json(['success' => true, 'agent' => $this->safeMobileAgent($agent, true)]);
        }
        if (in_array($method, ['PUT', 'PATCH'], true)) {
            foreach (['name', 'displayName', 'agency', 'phone', 'about', 'photo', 'color', 'status', 'approvalStatus', 'email'] as $key) {
                if ($request->has($key)) $agent[$key] = $request->input($key);
            }
            foreach (['verified', 'visible'] as $key) if ($request->has($key)) $agent[$key] = $request->boolean($key);
            foreach (['rating', 'reviewCount', 'years', 'listings'] as $key) if ($request->has($key)) $agent[$key] = (float) $request->input($key);
            foreach (['areas', 'specialties'] as $key) {
                if ($request->has($key)) {
                    $val = $request->input($key);
                    $agent[$key] = is_array($val) ? array_values(array_filter($val)) : array_filter(array_map('trim', explode(',', (string) $val)));
                }
            }
            if ($request->filled('password')) {
                $ui = $this->indexById($data['users'] ?? [], $agent['authUserId'] ?? null);
                if ($ui !== null) $data['users'][$ui]['password'] = $this->hashLegacyPassword((string) $request->input('password'));
            }
            $agent['updatedAt'] = now()->toISOString();
            JsonStore::write($data);
            return $this->json($this->safeMobileAgent($agent, true));
        }
        return $this->json(['error' => 'Method not allowed'], 405);
    }

    private function safeMobileAgent(array $agent, bool $includePrivate = false): array
    {
        $safe = $agent;
        unset($safe['password']);
        if (!$includePrivate) {
            unset($safe['authUserId']);
        }
        return $safe;
    }

    private function simpleCollection(Request $request, array $segments, string $method)
    {
        $key = match ($segments[0]) { 'inquiries' => 'inquiries', 'offers' => 'offers', default => 'appointments' };
        $user = $this->currentUser($request, true);
        $data = JsonStore::read();
        $id = $segments[1] ?? null;

        if ($method === 'GET' && $id === null) {
            $items = collect($data[$key] ?? []);
            $buyerId = $request->input('buyer_id', $request->input('buyerId'));
            $sellerId = $request->input('seller_id', $request->input('sellerId'));
            $agentId = $request->input('agent_id', $request->input('agentId'));
            $userId = $request->input('user_id', $request->input('userId'));

            if ($buyerId !== null && $buyerId !== '') {
                $items = $items->filter(fn ($x) => (string) ($x['buyerId'] ?? $x['userId'] ?? '') === (string) $buyerId);
            }
            if ($sellerId !== null && $sellerId !== '') {
                $items = $items->filter(fn ($x) => (string) ($x['sellerId'] ?? '') === (string) $sellerId);
            }
            if ($agentId !== null && $agentId !== '') {
                $items = $items->filter(fn ($x) => (string) ($x['agentId'] ?? '') === (string) $agentId);
            }
            if ($userId !== null && $userId !== '') {
                $items = $items->filter(fn ($x) => (string) ($x['userId'] ?? $x['buyerId'] ?? $x['sellerId'] ?? '') === (string) $userId);
            }

            // Non-admin without explicit filter: only own rows
            if (!$this->isAdmin($user) && $buyerId === null && $sellerId === null && $agentId === null && $userId === null) {
                $uid = (string) ($user['id'] ?? '');
                $items = $items->filter(function ($x) use ($uid) {
                    return in_array($uid, [
                        (string) ($x['userId'] ?? ''),
                        (string) ($x['buyerId'] ?? ''),
                        (string) ($x['sellerId'] ?? ''),
                        (string) ($x['agentId'] ?? ''),
                    ], true);
                });
            }

            return $this->json($items->values());
        }

        return $this->crudNamed($request, $data, $key, $id, $method, $user);
    }

    private function conversations(Request $request, array $parts, string $method)
    {
        $user = $this->currentUser($request, true);
        $data = JsonStore::read(); $items = $data['conversations'] ?? []; $id = $parts[0] ?? null;
        if ($method === 'GET' && $id === null) return $this->json($items);
        $index = $this->indexById($items, $id); if ($index === null) return $this->json(['error' => 'Conversation not found'], 404);
        if (($parts[1] ?? '') === 'messages') {
            if ($method === 'GET') return $this->json($items[$index]['messages'] ?? []);
            if ($method === 'POST') { $message = array_merge($request->all(), ['id' => JsonStore::nextId($data), 'senderId' => $user['id'], 'createdAt' => now()->toISOString(), 'timestamp' => now()->toISOString()]); $data['conversations'][$index]['messages'][] = $message; JsonStore::write($data); return $this->json($message, 201); }
        }
        if ($method === 'DELETE') { array_splice($data['conversations'], $index, 1); JsonStore::write($data); return $this->noContent(); }
        return $this->json($items[$index]);
    }

    private function genericCollection(Request $request, array $segments, string $method)
    {
        $map = [
            'buyer-requests' => 'buyerRequests', 'agent-leads' => 'agentLeads', 'agent-visits' => 'agentVisits',
            'recent-searches' => 'recentSearches', 'comparisons' => 'comparisons', 'visit-history' => 'visitHistory',
            'promotions' => 'promotions', 'verification-requests' => 'verificationRequests', 'measurements' => 'measurements',
        ];
        $key = $map[$segments[0]] ?? null;
        if ($segments[0] === 'mobile' && isset($segments[1])) $key = Str::camel($segments[1]);
        if ($key === null) return $this->json(['error' => 'Not found'], 404);
        $user = $this->currentUser($request, true); $data = JsonStore::read(); $data[$key] ??= [];
        $id = $segments[0] === 'mobile' ? ($segments[2] ?? null) : ($segments[1] ?? null);
        return $this->crudNamed($request, $data, $key, $id, $method, $user);
    }

    private function crudNamed(Request $request, array $data, string $key, ?string $id, string $method, ?array $user = null)
    {
        $data[$key] ??= [];
        if ($method === 'GET' && $id === null) {
            if ($user && !$this->isAdmin($user)) return $this->json(collect($data[$key])->filter(fn ($x) => (string) ($x['userId'] ?? $x['developerId'] ?? '') === (string) $user['id'])->values());
            return $this->json($data[$key]);
        }
        if ($method === 'POST') {
            $user ??= $this->currentUser($request, true);
            $item = array_merge($request->all(), ['id' => JsonStore::nextId($data, $key), 'userId' => $user['id'], 'createdAt' => now()->toISOString()]);
            $data[$key][] = $item; JsonStore::write($data); return $this->json($item, 201);
        }
        $index = $this->indexById($data[$key], $id); if ($index === null) return $this->json(['error' => 'Not found'], 404);
        if ($method === 'DELETE') { array_splice($data[$key], $index, 1); JsonStore::write($data); return $this->noContent(); }
        if (in_array($method, ['PUT', 'PATCH'], true)) { $data[$key][$index] = array_merge($data[$key][$index], $request->all()); JsonStore::write($data); return $this->json($data[$key][$index]); }
        return $this->json($data[$key][$index]);
    }

    private function currentUser(Request $request, bool $required = false): ?array
    {
        $header = (string) $request->header('Authorization', '');
        $token = preg_replace('/^Bearer\s+/i', '', $header);
        if (!$token) {
            if ($required) abort(response()->json(['error' => 'Authentication required.'], 401));
            return null;
        }
        try {
            $session = DB::table('auth_sessions')->where('token_hash', hash('sha256', $token))->where('expires_at', '>', now())->first();
            if ($session) {
                $user = $this->findById(JsonStore::read()['users'] ?? [], $session->user_id);
                if ($user) return $user;
            }
        } catch (\Throwable $exception) {
            Log::warning('Laravel auth session lookup failed.', ['error' => $exception->getMessage()]);
        }
        if ($required) abort(response()->json(['error' => 'Invalid or expired session.'], 401));
        return null;
    }

    private function createSession(array $user): string
    {
        $token = rtrim(strtr(base64_encode(random_bytes(48)), '+/', '-_'), '=');
        try {
            DB::table('auth_sessions')->updateOrInsert(
                ['token_hash' => hash('sha256', $token)],
                ['user_id' => $user['id'], 'expires_at' => now()->addHours((int) env('SESSION_TTL_HOURS', 168)), 'created_at' => now()],
            );
        } catch (\Throwable $exception) {
            Log::error('Laravel auth session could not be persisted.', ['error' => $exception->getMessage()]);
            throw $exception;
        }
        return $token;
    }

    private function destroySession(Request $request): void
    {
        $header = (string) $request->header('Authorization', '');
        $token = preg_replace('/^Bearer\s+/i', '', $header);
        if (!$token) return;
        try { DB::table('auth_sessions')->where('token_hash', hash('sha256', $token))->delete(); } catch (\Throwable) {}
    }

    private function invalidateSessions($userId): void
    {
        try { DB::table('auth_sessions')->where('user_id', $userId)->delete(); } catch (\Throwable $exception) {
            Log::warning('Laravel auth sessions could not be invalidated.', ['error' => $exception->getMessage()]);
        }
    }

    private function consumeChallenge(string $email, string $purpose, string $code): array
    {
        try {
            $challenge = DB::table('auth_challenges')
                ->where('email', $email)
                ->where('purpose', $purpose)
                ->first();
            if (!$challenge || now()->greaterThan($challenge->expires_at)) return ['ok' => false, 'reason' => 'expired'];
            if ((int) $challenge->attempts >= 3) return ['ok' => false, 'reason' => 'attempts'];
            if (!hash_equals((string) $challenge->code_hash, hash('sha256', $code))) {
                DB::table('auth_challenges')->where('email', $email)->where('purpose', $purpose)->increment('attempts');
                return ['ok' => false, 'reason' => 'invalid'];
            }
            DB::table('auth_challenges')->where('email', $email)->where('purpose', $purpose)->delete();
            return ['ok' => true];
        } catch (\Throwable $exception) {
            Log::warning('Laravel auth challenge lookup failed.', ['error' => $exception->getMessage()]);
            return ['ok' => false, 'reason' => 'expired'];
        }
    }

    private function mediaBaseUrl(): string
    {
        return rtrim((string) config('media.public_base_url', ''), '/');
    }

    private function safeUser(array $user): array { unset($user['password']); return $user; }
    private function findUserByEmail(string $email): ?array { return collect(JsonStore::read()['users'] ?? [])->first(fn ($u) => strtolower((string) ($u['email'] ?? '')) === strtolower(trim($email))); }
    private function isAdmin(?array $user): bool { return $user !== null && strtolower((string) ($user['role'] ?? '')) === 'admin'; }
    private function findById(array $items, $id): ?array { return collect($items)->first(fn ($item) => (string) ($item['id'] ?? '') === (string) $id); }
    private function indexById(array $items, $id): ?int { foreach ($items as $index => $item) if ((string) ($item['id'] ?? '') === (string) $id) return $index; return null; }
    private function hashLegacyPassword(string $password): string { $salt = bin2hex(random_bytes(16)); return 'pbkdf2:' . $salt . ':' . hash_pbkdf2('sha512', $password, $salt, 100000, 128, false); }
    private function verifyLegacyPassword(string $plain, string $stored): bool { if (!str_starts_with($stored, 'pbkdf2:')) return Hash::check($plain, $stored); [, $salt, $hash] = array_pad(explode(':', $stored, 3), 3, ''); return $hash !== '' && hash_equals($hash, hash_pbkdf2('sha512', $plain, $salt, 100000, 128, false)); }
    private function propertyVisible(array $property, ?array $user): bool { if ($this->isAdmin($user)) return true; $owner = $user && (string) ($property['sellerId'] ?? $property['userId'] ?? '') === (string) $user['id']; if ($owner) return true; return in_array(strtolower((string) ($property['approvalStatus'] ?? 'active')), ['active', 'approved'], true) && in_array(strtolower((string) ($property['listingStatus'] ?? 'active')), ['active', 'approved'], true); }
    private function propertyMatches(array $p, Request $r): bool
    {
        $text = strtolower((string) ($r->input('search', $r->input('keyword', ''))));
        if ($text !== '' && !str_contains(strtolower(json_encode($p)), $text)) {
            return false;
        }
        foreach (['type', 'city', 'status', 'purpose', 'constructionAge', 'furnishing', 'availability'] as $key) {
            if ($r->filled($key) && strtolower((string) ($p[$key] ?? '')) !== strtolower((string) $r->input($key))) {
                return false;
            }
        }

        $sellerFilter = $r->input('seller_id', $r->input('sellerId', $r->input('ownerId', $r->input('userId'))));
        if ($sellerFilter !== null && $sellerFilter !== '') {
            $owner = (string) ($p['sellerId'] ?? $p['userId'] ?? $p['ownerId'] ?? '');
            if ($owner !== (string) $sellerFilter) {
                return false;
            }
        }

        $agentFilter = $r->input('agent_id', $r->input('agentId'));
        if ($agentFilter !== null && $agentFilter !== '') {
            if ((string) ($p['agentId'] ?? '') !== (string) $agentFilter) {
                return false;
            }
        }

        if ($r->filled('minPrice') && (float) ($p['price'] ?? 0) < (float) $r->input('minPrice')) {
            return false;
        }
        if ($r->filled('maxPrice') && (float) ($p['price'] ?? 0) > (float) $r->input('maxPrice')) {
            return false;
        }
        if ($r->filled('minBeds') && (float) ($p['bedrooms'] ?? 0) < (float) $r->input('minBeds')) {
            return false;
        }
        foreach (['minLat' => 0, 'maxLat' => 0, 'minLng' => 0, 'maxLng' => 0] as $key => $fallback) {
            if ($r->filled($key)) {
                $value = str_contains($key, 'Lat') ? $this->propertyLat($p) : $this->propertyLng($p);
                if ($value === null
                    || ($key === 'minLat' && $value < (float) $r->input($key))
                    || ($key === 'maxLat' && $value > (float) $r->input($key))
                    || ($key === 'minLng' && $value < (float) $r->input($key))
                    || ($key === 'maxLng' && $value > (float) $r->input($key))) {
                    return false;
                }
            }
        }

        return true;
    }
    private function propertyLat(array $p): ?float { return isset($p['lat']) ? (float) $p['lat'] : (isset($p['location']['latitude']) ? (float) $p['location']['latitude'] : null); }
    private function propertyLng(array $p): ?float { return isset($p['lng']) ? (float) $p['lng'] : (isset($p['location']['longitude']) ? (float) $p['location']['longitude'] : null); }
    private function distanceKm(?float $lat1, ?float $lng1, ?float $lat2, ?float $lng2): ?float { if ($lat1 === null || $lng1 === null || $lat2 === null || $lng2 === null) return null; $dLat = deg2rad($lat2 - $lat1); $dLng = deg2rad($lng2 - $lng1); $a = sin($dLat / 2) ** 2 + cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * sin($dLng / 2) ** 2; return round(6371 * 2 * asin(min(1, sqrt($a))), 3); }
    private function adminStats(array $data) { return $this->json(['projects' => count($data['developerProjects'] ?? []), 'leads' => count($data['developerLeads'] ?? []), 'units' => count($data['inventoryUnits'] ?? []), 'generatedAt' => now()->toISOString()]); }
    private function deepMerge(array $base, array $patch): array { foreach ($patch as $key => $value) $base[$key] = is_array($value) && is_array($base[$key] ?? null) ? $this->deepMerge($base[$key], $value) : $value; return $base; }
    private function isGenericCollection(array $segments): bool { return in_array($segments[0] ?? '', ['buyer-requests', 'agent-leads', 'agent-visits', 'recent-searches', 'comparisons', 'visit-history', 'promotions', 'verification-requests', 'measurements'], true) || (($segments[0] ?? '') === 'mobile' && isset($segments[1])); }
    private function json($data, int $status = 200)
    {
        return response()->json($data, $status)->withHeaders($this->corsHeaders());
    }

    private function noContent()
    {
        return response()->noContent()->withHeaders($this->corsHeaders());
    }

    private function corsHeaders(): array
    {
        return CorsOrigin::headers();
    }
}