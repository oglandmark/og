<?php

namespace App\Services;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Schema;

class PropertySearchIndexer
{
    public function upsert(array $property): void
    {
        if (!Schema::hasTable('property_search_index')) {
            return;
        }

        $id = (int) ($property['id'] ?? 0);
        if ($id <= 0) {
            return;
        }

        try {
            DB::table('property_search_index')->updateOrInsert(
                ['property_id' => $id],
                $this->rowFromProperty($property)
            );
        } catch (\Throwable $exception) {
            Log::warning('property_search_index upsert failed', [
                'property_id' => $id,
                'error' => $exception->getMessage(),
            ]);
        }
    }

    public function delete(int|string $propertyId): void
    {
        if (!Schema::hasTable('property_search_index')) {
            return;
        }

        try {
            DB::table('property_search_index')->where('property_id', (int) $propertyId)->delete();
        } catch (\Throwable $exception) {
            Log::warning('property_search_index delete failed', [
                'property_id' => $propertyId,
                'error' => $exception->getMessage(),
            ]);
        }
    }

    /**
     * @param  list<array<string, mixed>>  $properties
     */
    public function rebuild(array $properties): int
    {
        if (!Schema::hasTable('property_search_index')) {
            return 0;
        }

        DB::table('property_search_index')->delete();
        $count = 0;
        foreach ($properties as $property) {
            if (!is_array($property)) {
                continue;
            }
            $id = (int) ($property['id'] ?? 0);
            if ($id <= 0) {
                continue;
            }
            DB::table('property_search_index')->insert($this->rowFromProperty($property));
            $count++;
        }

        return $count;
    }

    /**
     * @param  array<string, mixed>  $property
     * @return array<string, mixed>
     */
    public function rowFromProperty(array $property): array
    {
        $title = (string) ($property['title'] ?? $property['name'] ?? '');
        $type = (string) ($property['type'] ?? $property['propertyType'] ?? '');
        $city = (string) ($property['city'] ?? '');
        $society = (string) ($property['society'] ?? $property['location'] ?? '');
        $description = (string) ($property['description'] ?? '');
        $tags = $property['tags'] ?? $property['amenities'] ?? [];
        if (!is_array($tags)) {
            $tags = [];
        }

        $searchParts = array_filter([
            $title,
            $type,
            $city,
            $society,
            $description,
            implode(' ', array_map('strval', $tags)),
        ]);

        return [
            'property_id' => (int) $property['id'],
            'title' => mb_substr($title, 0, 500),
            'type' => mb_substr($type, 0, 120),
            'status' => mb_substr((string) ($property['status'] ?? $property['listingStatus'] ?? ''), 0, 80),
            'listing_status' => isset($property['listingStatus']) ? mb_substr((string) $property['listingStatus'], 0, 80) : null,
            'approval_status' => isset($property['approvalStatus']) ? mb_substr((string) $property['approvalStatus'], 0, 80) : null,
            'purpose' => isset($property['purpose']) ? mb_substr((string) $property['purpose'], 0, 80) : null,
            'city' => $city !== '' ? mb_substr($city, 0, 160) : null,
            'society' => $society !== '' ? mb_substr($society, 0, 200) : null,
            'seller_id' => isset($property['sellerId']) ? (int) $property['sellerId'] : (isset($property['userId']) ? (int) $property['userId'] : null),
            'agent_id' => isset($property['agentId']) ? (int) $property['agentId'] : null,
            'price' => isset($property['price']) ? (float) $property['price'] : null,
            'area_sqft' => isset($property['area']) ? (float) $property['area'] : (isset($property['areaSqft']) ? (float) $property['areaSqft'] : null),
            'bedrooms' => isset($property['bedrooms']) ? (float) $property['bedrooms'] : null,
            'bathrooms' => isset($property['bathrooms']) ? (float) $property['bathrooms'] : null,
            'featured' => !empty($property['featured']),
            'priority' => !empty($property['priority']),
            'score_overall' => isset($property['scoreOverall']) ? (float) $property['scoreOverall'] : null,
            'latitude' => $this->coord($property, 'lat', 'latitude'),
            'longitude' => $this->coord($property, 'lng', 'longitude'),
            'construction_age' => isset($property['constructionAge']) ? mb_substr((string) $property['constructionAge'], 0, 80) : null,
            'furnishing' => isset($property['furnishing']) ? mb_substr((string) $property['furnishing'], 0, 80) : null,
            'availability' => isset($property['availability']) ? mb_substr((string) $property['availability'], 0, 120) : null,
            'tags' => json_encode(array_values($tags), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'search_text' => implode(' ', $searchParts),
            'property_json' => json_encode($property, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'created_at' => $this->datetime($property['createdAt'] ?? null) ?? now(),
            'updated_at' => now(),
        ];
    }

    private function coord(array $property, string $short, string $long): ?float
    {
        if (isset($property[$short]) && is_numeric($property[$short])) {
            return (float) $property[$short];
        }
        if (isset($property[$long]) && is_numeric($property[$long])) {
            return (float) $property[$long];
        }
        $loc = $property['location'] ?? null;
        if (is_array($loc) && isset($loc[$short]) && is_numeric($loc[$short])) {
            return (float) $loc[$short];
        }

        return null;
    }

    private function datetime(mixed $value): ?\DateTimeInterface
    {
        if ($value === null || $value === '') {
            return null;
        }
        try {
            return \Carbon\Carbon::parse((string) $value);
        } catch (\Throwable) {
            return null;
        }
    }
}
