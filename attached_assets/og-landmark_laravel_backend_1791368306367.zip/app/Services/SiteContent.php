<?php

namespace App\Services;

/**
 * Default CMS payload for the public site (hero, CTAs, contact, SEO).
 */
class SiteContent
{
    /**
     * @return array<string, mixed>
     */
    public static function defaults(): array
    {
        return [
            'heroTitle' => 'Find Your Dream Property',
            'heroSubtitle' => 'Buy, sell, and rent verified listings across Pakistan with OG Landmark.',
            'primaryCta' => ['label' => 'Browse Properties', 'href' => '/properties'],
            'secondaryCta' => ['label' => 'List Your Property', 'href' => '/seller'],
            'featuredSectionTitle' => 'Featured Properties',
            'aboutTeaser' => 'OG Landmark connects buyers, sellers, and agents with trusted real-estate listings.',
            'contact' => [
                'phone' => '',
                'email' => 'info@oglandmark.com',
                'whatsapp' => '',
                'address' => '',
            ],
            'seo' => [
                'title' => 'OG Landmark — Real Estate Platform',
                'description' => 'OG Landmark — Real Estate Platform for buying, selling, and renting properties.',
            ],
            'updatedAt' => null,
        ];
    }

    /**
     * @param  array<string, mixed>|null  $stored
     * @return array<string, mixed>
     */
    public static function resolve(?array $stored): array
    {
        $base = self::defaults();
        if (!is_array($stored) || $stored === []) {
            return $base;
        }

        return self::deepMerge($base, $stored);
    }

    /**
     * @param  array<string, mixed>  $base
     * @param  array<string, mixed>  $overlay
     * @return array<string, mixed>
     */
    public static function deepMerge(array $base, array $overlay): array
    {
        foreach ($overlay as $key => $value) {
            if (is_array($value) && isset($base[$key]) && is_array($base[$key]) && self::isAssoc($base[$key])) {
                $base[$key] = self::deepMerge($base[$key], $value);
            } else {
                $base[$key] = $value;
            }
        }

        return $base;
    }

    /**
     * @param  array<mixed>  $array
     */
    private static function isAssoc(array $array): bool
    {
        if ($array === []) {
            return true;
        }

        return array_keys($array) !== range(0, count($array) - 1);
    }
}
