<?php

namespace App\Support;

/**
 * Resolve Access-Control-Allow-Origin from config/cors.php
 * (exact allow-list + allowed_origins_patterns).
 */
final class CorsOrigin
{
    public static function resolve(?string $origin): string
    {
        $origin = (string) $origin;
        $allowed = config('cors.allowed_origins', []);
        $patterns = config('cors.allowed_origins_patterns', []);

        if ($origin !== '' && in_array($origin, $allowed, true)) {
            return $origin;
        }

        if ($origin !== '') {
            foreach ($patterns as $pattern) {
                if (@preg_match($pattern, $origin) === 1) {
                    return $origin;
                }
            }
        }

        return $allowed[0] ?? 'https://oglandmark.com';
    }

    /**
     * Headers for API JSON responses and OPTIONS preflight.
     *
     * @return array<string, string>
     */
    public static function headers(?string $origin = null): array
    {
        $origin ??= (string) request()->headers->get('Origin', '');

        return [
            'Access-Control-Allow-Origin' => self::resolve($origin),
            'Access-Control-Allow-Headers' => implode(', ', config('cors.allowed_headers', ['Authorization', 'Content-Type'])),
            'Access-Control-Allow-Methods' => implode(', ', config('cors.allowed_methods', ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'])),
            'Access-Control-Max-Age' => (string) config('cors.max_age', 86400),
            'Vary' => 'Origin',
        ];
    }
}
