<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Cross-Origin Resource Sharing (CORS) Configuration
    |--------------------------------------------------------------------------
    |
    | Allowed origins for the OG Landmark React frontend talking to the
    | Laravel API on api.oglandmark.com.
    |
    | Live site may be opened as http/https and with/without www — all four
    | production origins are listed so browsers do not fail CORS checks.
    |
    */

    'paths' => ['api/*', 'sanctum/csrf-cookie', 'images/uploads/*'],

    'allowed_methods' => ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],

    'allowed_origins' => array_values(array_filter(array_map(
        'trim',
        explode(',', (string) env(
            'CORS_ALLOWED_ORIGINS',
            'https://oglandmark.com,https://www.oglandmark.com,http://oglandmark.com,http://www.oglandmark.com,http://localhost:5173,http://127.0.0.1:5173,http://localhost:5174,http://127.0.0.1:5174,http://localhost:8000,http://127.0.0.1:8000'
        ))
    ))),

    // Safety net if env omit a variant (http vs https, www vs apex)
    'allowed_origins_patterns' => [
        '#^https?://(www\.)?oglandmark\.com$#',
    ],

    'allowed_headers' => ['Authorization', 'Content-Type', 'Accept', 'X-Requested-With'],

    'exposed_headers' => [],

    'max_age' => 86400,

    'supports_credentials' => false,

];
