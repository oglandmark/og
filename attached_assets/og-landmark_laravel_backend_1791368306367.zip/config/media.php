<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Persistent media directory
    |--------------------------------------------------------------------------
    |
    | Absolute path preferred on Hostinger (outside ephemeral release folders).
    | Relative paths resolve from the Laravel base path.
    |
    */

    'storage_dir' => env('MEDIA_STORAGE_DIR', 'public/images/uploads'),

    /*
    | Production uploads require a persistent volume (not a throwaway deploy dir).
    | Default false in production until MEDIA_STORAGE_PERSISTENT=true is set.
    */

    'persistent' => env('MEDIA_STORAGE_PERSISTENT'),

    /*
    | Optional CDN / public mirror base URL for uploaded files.
    */

    'public_base_url' => env('MEDIA_PUBLIC_BASE_URL', ''),

];
