<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('property_search_index')) {
            return;
        }

        Schema::create('property_search_index', function (Blueprint $table) {
            $table->unsignedBigInteger('property_id')->primary();
            $table->string('title', 500);
            $table->string('type', 120);
            $table->string('status', 80);
            $table->string('listing_status', 80)->nullable();
            $table->string('approval_status', 80)->nullable();
            $table->string('purpose', 80)->nullable();
            $table->string('city', 160)->nullable();
            $table->string('society', 200)->nullable();
            $table->unsignedBigInteger('seller_id')->nullable()->index('idx_property_search_seller');
            $table->unsignedBigInteger('agent_id')->nullable()->index('idx_property_search_agent');
            $table->decimal('price', 20, 2)->nullable()->index('idx_property_search_price');
            $table->decimal('area_sqft', 20, 2)->nullable()->index('idx_property_search_area');
            $table->decimal('bedrooms', 10, 2)->nullable();
            $table->decimal('bathrooms', 10, 2)->nullable();
            $table->boolean('featured')->default(false);
            $table->boolean('priority')->default(false);
            $table->decimal('score_overall', 5, 2)->nullable();
            $table->decimal('latitude', 10, 7)->nullable();
            $table->decimal('longitude', 10, 7)->nullable();
            $table->string('construction_age', 80)->nullable();
            $table->string('furnishing', 80)->nullable();
            $table->string('availability', 120)->nullable();
            $table->json('tags')->nullable();
            $table->text('search_text');
            $table->json('property_json');
            $table->dateTime('created_at', 3)->nullable();
            $table->dateTime('updated_at', 3)->useCurrent();

            $table->index(['approval_status', 'listing_status', 'created_at'], 'idx_property_search_status');
            $table->index(['city', 'type', 'status'], 'idx_property_search_city');
            $table->index(['latitude', 'longitude'], 'idx_property_search_geo');
        });

        // FULLTEXT is MySQL-specific and not fully expressed via Blueprint on all drivers.
        if (Schema::getConnection()->getDriverName() === 'mysql') {
            DB::statement('ALTER TABLE property_search_index ADD FULLTEXT KEY ft_property_search_text (search_text)');
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('property_search_index');
    }
};
