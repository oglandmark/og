<?php

/**
 * Replaces Hostinger's placeholder default.php when DirectoryIndex prefers it
 * over index.php. Boots the same Laravel public front controller.
 */
require __DIR__.'/public/index.php';
