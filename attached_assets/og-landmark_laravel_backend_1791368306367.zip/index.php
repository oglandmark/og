<?php

/**
 * Shared-hosting front controller when the subdomain document root is the
 * Laravel project root (parent of public/), not public/ itself.
 * Prefer pointing the Hostinger document root at public/ instead.
 */
require __DIR__.'/public/index.php';
