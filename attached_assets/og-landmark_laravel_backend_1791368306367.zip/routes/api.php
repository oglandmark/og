<?php

use App\Http\Controllers\ApiController;
use App\Support\CorsOrigin;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::options('/{path?}', function (Request $request) {
    return response('', 204)->withHeaders(CorsOrigin::headers($request->headers->get('Origin')));
})->where('path', '.*');

Route::any('/{path?}', [ApiController::class, 'handle'])->where('path', '.*');
