# Live MySQL 1045 fix (Hostinger)

## Already done on server (`public_html/api`)

- `DB_HOST=localhost` (was `127.0.0.1`)
- `CACHE_STORE=file`
- `DATABASE_URL` / `DB_URL` commented out

## Still failing

`1045 Access denied ... (using password: YES)` means login is rejected — usually wrong password **or** the MySQL user is not linked to the database in hPanel.

## You must do in hPanel (cannot GRANT over SSH)

1. Open https://hpanel.hostinger.com/ → **Databases** → **Management**
2. Confirm database **`u133241207_ogland`** and user **`u133241207_oglandmark26`**
3. **Add user to database** → select that pair → **All Privileges** → save
4. **Reset password** for `u133241207_oglandmark26` and copy the new password

## Then paste this in the open SSH session

Replace `YOUR_NEW_PASSWORD` then run:

```bash
cd /home/u133241207/domains/oglandmark.com/public_html/api
php -r '$e=".env";$p="YOUR_NEW_PASSWORD";$L=file($e,FILE_IGNORE_NEW_LINES);$o=[];$s=[];foreach($L as $l){if(str_starts_with($l,"DATABASE_URL=")||str_starts_with($l,"DB_URL=")){$o[]=str_starts_with($l,"#")?$l:"#".$l;continue;}if(str_starts_with($l,"DB_HOST=")){$o[]="DB_HOST=localhost";$s["DB_HOST"]=1;continue;}if(str_starts_with($l,"DB_USERNAME=")){$o[]="DB_USERNAME=u133241207_oglandmark26";$s["DB_USERNAME"]=1;continue;}if(str_starts_with($l,"DB_DATABASE=")){$o[]="DB_DATABASE=u133241207_ogland";$s["DB_DATABASE"]=1;continue;}if(str_starts_with($l,"DB_PASSWORD=")){$safe=preg_match("/[ #\"'\''`$\\\\]/",$p)?"\"".addcslashes($p,"\\\"\"")."\"":$p;$o[]="DB_PASSWORD=$safe";$s["DB_PASSWORD"]=1;continue;}if(str_starts_with($l,"CACHE_STORE=")){$o[]="CACHE_STORE=file";$s["CACHE_STORE"]=1;continue;}$o[]=$l;}file_put_contents($e,implode("\n",$o)."\n");echo "ENV_OK\n";try{new PDO("mysql:host=localhost;dbname=u133241207_ogland","u133241207_oglandmark26",$p);echo "PDO_OK\n";}catch(Throwable $ex){echo "PDO_FAIL: ".$ex->getMessage()."\n";exit(1);}'
php artisan config:clear
php artisan migrate --force
php artisan config:cache
curl -sS https://api.oglandmark.com/api/healthz
```

## Or sync password from Node `public_html/.env` DATABASE_URL

If Node’s `DATABASE_URL` still works:

```bash
php /tmp/remote-sync-db.php
```

(Upload [`scripts/remote-sync-db.php`](remote-sync-db.php) to `/tmp/` first, or paste its contents.)
