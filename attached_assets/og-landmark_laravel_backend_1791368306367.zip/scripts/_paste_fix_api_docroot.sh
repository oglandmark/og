﻿set -e
APP=""
for d in "$PWD" "/home/u133241207/domains/oglandmark.com/public_html/api" "/home/u133241207/domains/api.oglandmark.com/public_html"; do
  if [ -f "$d/public/index.php" ] && [ -f "$d/artisan" ]; then APP="$d"; break; fi
done
if [ -z "$APP" ]; then APP=$(find /home/u133241207/domains -maxdepth 5 -type f -path '*/public/index.php' 2>/dev/null | head -1 | xargs -r dirname | xargs -r dirname); fi
echo APP=$APP
cd "$APP"
cat > index.php <<'PHP'
<?php

/**
 * Shared-hosting front controller when the subdomain document root is the
 * Laravel project root (parent of public/), not public/ itself.
 * Prefer pointing the Hostinger document root at public/ instead.
 */
require __DIR__.'/public/index.php';
PHP
cat > default.php <<'PHP'
<?php

/**
 * Replaces Hostinger's placeholder default.php when DirectoryIndex prefers it
 * over index.php. Boots the same Laravel public front controller.
 */
require __DIR__.'/public/index.php';
PHP
cat > .htaccess <<'HTA'
# Place this file as `.htaccess` in the Laravel project root when the
# Hostinger document root is the project root (not public/).
# Prefer hPanel â†’ subdomain â†’ Document root = .../public instead.

<IfModule mod_rewrite.c>
    RewriteEngine On

    # Prefer Laravel over Hostinger placeholder pages
    DirectoryIndex index.php default.php

    # Allow existing files/dirs (including public/) to be served as-is
    RewriteCond %{REQUEST_URI} !^/public/
    RewriteCond %{REQUEST_FILENAME} !-f
    RewriteCond %{REQUEST_FILENAME} !-d
    RewriteRule ^(.*)$ public/$1 [L]

    # Root URL â†’ public front controller (skip Hostinger default.html leftovers)
    RewriteRule ^$ public/index.php [L]
</IfModule>
HTA
ls -la index.php default.php .htaccess
php artisan optimize:clear || true
curl -sS https://api.oglandmark.com/api/healthz; echo
curl -sS https://api.oglandmark.com/ | head -c 180; echo