cd /home/u133241207/domains/oglandmark.com/public_html/api && \
cat > index.php <<'PHP'
<?php
require __DIR__.'/public/index.php';
PHP
cat > default.php <<'PHP'
<?php
require __DIR__.'/public/index.php';
PHP
cat > .htaccess <<'HTA'
DirectoryIndex index.php default.php
<IfModule mod_rewrite.c>
    RewriteEngine On
    RewriteCond %{REQUEST_URI} !^/public/
    RewriteCond %{REQUEST_FILENAME} !-f
    RewriteCond %{REQUEST_FILENAME} !-d
    RewriteRule ^(.*)$ public/$1 [L]
    RewriteRule ^$ public/index.php [L]
</IfModule>
HTA
cat > routes/web.php <<'PHP'
<?php
use Illuminate\Support\Facades\Route;
use App\Services\MediaStorage;
Route::get('/', function () {
    return response()->json([
        'app' => 'OG Landmark API',
        'ok' => true,
        'healthz' => url('/api/healthz'),
        'docs' => 'Use /api/* endpoints. Frontend: https://oglandmark.com',
    ]);
});
Route::get('/images/uploads/{filename}', function (string $filename) {
    $file = app(MediaStorage::class)->fileForPublicPath('/images/uploads/' . $filename);
    abort_unless($file !== null && is_file($file), 404);
    return response()->file($file);
})->where('filename', '[^/]+');
PHP
chmod -R ug+rwx storage bootstrap/cache
php artisan optimize:clear
php artisan route:clear
php artisan config:cache
curl -sS https://api.oglandmark.com/; echo
curl -sS https://api.oglandmark.com/api/healthz; echo