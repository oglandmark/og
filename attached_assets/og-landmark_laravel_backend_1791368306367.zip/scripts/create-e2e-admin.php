<?php

use App\Http\Controllers\ApiController;
use App\Services\JsonStore;
use Illuminate\Contracts\Console\Kernel;

require __DIR__ . '/../vendor/autoload.php';
$app = require __DIR__ . '/../bootstrap/app.php';
$app->make(Kernel::class)->bootstrap();

$email = 'e2e.admin.20260927@oglandmark.test';
$pass = 'E2eAdmin!2026';

$data = JsonStore::read();
$idx = null;
foreach ($data['users'] ?? [] as $i => $u) {
    if (strtolower((string) ($u['email'] ?? '')) === $email) {
        $idx = $i;
        break;
    }
}

$controller = (new ReflectionClass(ApiController::class))->newInstanceWithoutConstructor();
$method = new ReflectionMethod(ApiController::class, 'hashLegacyPassword');
$method->setAccessible(true);
$hashed = $method->invoke($controller, $pass);

$user = [
    'id' => $idx === null ? JsonStore::nextId($data) : $data['users'][$idx]['id'],
    'name' => 'E2E Admin',
    'email' => $email,
    'phone' => '+92 300 0000999',
    'role' => 'Admin',
    'status' => 'Active',
    'approvalStatus' => 'Approved',
    'password' => $hashed,
    'joinedDate' => now()->toDateString(),
    'createdByAdmin' => true,
];

if ($idx === null) {
    $data['users'][] = $user;
    echo "created admin id={$user['id']}\n";
} else {
    $data['users'][$idx] = array_merge($data['users'][$idx], $user);
    echo "updated admin id={$user['id']}\n";
}

JsonStore::write($data);
echo "ok email={$email}\n";
