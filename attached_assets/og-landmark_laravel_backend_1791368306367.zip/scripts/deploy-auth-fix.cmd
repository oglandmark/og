@echo off
setlocal EnableExtensions
cd /d "d:\laragon\www\og-landmark(property-project)"
set LOG=%TEMP%\og-deploy-auth-fix.log
echo === OG Landmark auth/portal deploy === > "%LOG%"
echo Host: u133241207@145.79.30.73 port 65002
echo.
echo Enter Hostinger SSH password when prompted (twice: once for upload, once for remote commands).
echo Log: %LOG%
echo.

set PLINK="C:\Program Files\PuTTY\plink.exe"
set PSCP="C:\Program Files\PuTTY\pscp.exe"
set HOST=u133241207@145.79.30.73
set PORT=65002
set SITE=/home/u133241207/domains/oglandmark.com/public_html
set API=%SITE%/api

echo Caching host key (type y if asked)... >> "%LOG%"
echo y | %PLINK% -ssh -P %PORT% %HOST% "echo SSH_OK" >> "%LOG%" 2>&1
if errorlevel 1 (
  echo SSH failed. Check password / network.
  type "%LOG%"
  pause
  exit /b 1
)

echo Uploading index.html .htaccess ...
%PSCP% -P %PORT% "frontend\build\index.html" %HOST%:%SITE%/index.html >> "%LOG%" 2>&1
%PSCP% -P %PORT% "frontend\build\.htaccess" %HOST%:%SITE%/.htaccess >> "%LOG%" 2>&1

echo Uploading portal HTML...
%PSCP% -P %PORT% "frontend\build\portal\*.html" %HOST%:%SITE%/portal/ >> "%LOG%" 2>&1

echo Uploading EnsureAdmin.php...
%PLINK% -ssh -P %PORT% %HOST% "mkdir -p %API%/app/Console/Commands" >> "%LOG%" 2>&1
%PSCP% -P %PORT% "app\Console\Commands\EnsureAdmin.php" %HOST%:%API%/app/Console/Commands/EnsureAdmin.php >> "%LOG%" 2>&1

echo Running migrate + ensure-admin on server...
%PLINK% -ssh -P %PORT% %HOST% "cd %API% && php artisan migrate --force && php artisan og:ensure-admin admin@gmail.com --password=12345678 --name=\"Platform Admin\" && php artisan optimize:clear && curl -sS https://api.oglandmark.com/api/healthz && echo && php -r \"require 'vendor/autoload.php'; \\$a=require 'bootstrap/app.php'; \\$a->make(Illuminate\\Contracts\\Console\\Kernel::class)->bootstrap(); \\$r=DB::table('app_data')->where('id',1)->first(); \\$d=json_decode(\\$r->data,true); echo 'user_count='.count(\\$d['users']??[]).PHP_EOL; echo 'admin_gmail='.(collect(\\$d['users']??[])->contains(fn(\\$u)=>strtolower((string)(\\$u['email']??''))==='admin@gmail.com')?'yes':'no').PHP_EOL;\"" >> "%LOG%" 2>&1

echo.
echo === DONE — last log lines ===
powershell -NoProfile -Command "Get-Content -Tail 40 '%LOG%'"
echo.
echo Verify https://oglandmark.com/user redirects to buyer dashboard
echo Admin: https://oglandmark.com/portal/admin  admin@gmail.com / 12345678
pause
