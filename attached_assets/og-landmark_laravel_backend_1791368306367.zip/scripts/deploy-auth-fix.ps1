# Deploy frontend portal redirects + EnsureAdmin, seed admin on Hostinger.
$ErrorActionPreference = 'Continue'
$log = Join-Path $env:TEMP 'og-deploy-auth-fix.log'
function Log([string]$m) {
    $line = "[{0}] {1}" -f (Get-Date -Format 'HH:mm:ss'), $m
    Add-Content -Path $log -Value $line
    Write-Host $line
}
'' | Set-Content $log
Log 'Starting deploy-auth-fix'

$root = Split-Path -Parent $PSScriptRoot
$hostName = '145.79.30.73'
$port = 65002
$user = 'u133241207'
$remoteSite = '/home/u133241207/domains/oglandmark.com/public_html'
$remoteApi = "$remoteSite/api"
$plink = 'C:\Program Files\PuTTY\plink.exe'
$pscp = 'C:\Program Files\PuTTY\pscp.exe'

Add-Type -AssemblyName Microsoft.VisualBasic
$pass = [Microsoft.VisualBasic.Interaction]::InputBox(
    "Enter Hostinger SSH password for ${user}@${hostName}:${port}`n`nUploads index.html, .htaccess, portal/, EnsureAdmin.php and seeds admin@gmail.com.",
    'Hostinger SSH deploy',
    ''
)
if ([string]::IsNullOrWhiteSpace($pass)) {
    Log 'CANCELLED_NO_PASSWORD'
    [System.Windows.Forms.MessageBox]::Show('Cancelled — no password entered.', 'OG Deploy') | Out-Null
    exit 2
}

# Accept host key once
Log 'Accepting host key...'
$psi = New-Object System.Diagnostics.ProcessStartInfo
$psi.FileName = $plink
$psi.Arguments = "-ssh -P $port -pw `"$pass`" ${user}@${hostName} echo SSH_OK"
$psi.RedirectStandardInput = $true
$psi.RedirectStandardOutput = $true
$psi.RedirectStandardError = $true
$psi.UseShellExecute = $false
$psi.CreateNoWindow = $true
$p = [System.Diagnostics.Process]::Start($psi)
$p.StandardInput.WriteLine('y')
$p.StandardInput.Close()
$stdout = $p.StandardOutput.ReadToEnd()
$stderr = $p.StandardError.ReadToEnd()
$p.WaitForExit(60000) | Out-Null
Log "SSH_OK probe exit=$($p.ExitCode) out=$stdout err=$stderr"
if ($stdout -notmatch 'SSH_OK' -and $p.ExitCode -ne 0) {
    Log 'SSH failed — wrong password or network?'
    Add-Type -AssemblyName System.Windows.Forms
    [System.Windows.Forms.MessageBox]::Show("SSH failed.`nSee $log", 'OG Deploy') | Out-Null
    exit 1
}

function Invoke-Remote([string]$cmd) {
    Log "REMOTE: $cmd"
    $args = @('-ssh', '-P', "$port", '-pw', $pass, '-batch', "${user}@${hostName}", $cmd)
    $out = & $plink @args 2>&1 | Out-String
    Log $out
    return $out
}

function Copy-Remote([string]$local, [string]$remotePath) {
    Log "UPLOAD: $local -> $remotePath"
    $out = & $pscp -P $port -pw $pass -batch $local "${user}@${hostName}:$remotePath" 2>&1 | Out-String
    Log $out
    if ($LASTEXITCODE -ne 0) { throw "pscp failed: $local" }
}

try {
    Copy-Remote (Join-Path $root 'frontend\build\index.html') "$remoteSite/index.html"
    Copy-Remote (Join-Path $root 'frontend\build\.htaccess') "$remoteSite/.htaccess"

    Get-ChildItem (Join-Path $root 'frontend\build\portal') -Filter '*.html' | ForEach-Object {
        Copy-Remote $_.FullName "$remoteSite/portal/$($_.Name)"
    }

    Invoke-Remote "mkdir -p $remoteApi/app/Console/Commands"
    Copy-Remote (Join-Path $root 'app\Console\Commands\EnsureAdmin.php') "$remoteApi/app/Console/Commands/EnsureAdmin.php"

    # Write remote script to avoid quoting hell
    $remoteSh = @'
#!/bin/bash
set -e
cd /home/u133241207/domains/oglandmark.com/public_html/api
php artisan migrate --force
php artisan og:ensure-admin admin@gmail.com --password=12345678 --name="Platform Admin"
php artisan optimize:clear || true
echo "--- healthz ---"
curl -sS https://api.oglandmark.com/api/healthz || true
echo
echo "--- user_count ---"
php -r 'require "vendor/autoload.php"; $app=require "bootstrap/app.php"; $app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap(); $row=DB::table("app_data")->where("id",1)->first(); if(!$row){echo "NO_APP_DATA\n"; exit(1);} $d=json_decode($row->data,true); $n=is_array($d["users"]??null)?count($d["users"]):0; $has=false; foreach(($d["users"]??[]) as $u){ if(strtolower((string)($u["email"]??""))==="admin@gmail.com"){ $has=true; break; } } echo "user_count=$n admin_gmail=".($has?"yes":"no")."\n";'
'@
    $tmpSh = Join-Path $env:TEMP 'og-deploy-auth-fix.sh'
    [IO.File]::WriteAllText($tmpSh, ($remoteSh -replace "`r`n", "`n" -replace "`r", "`n"))
    Copy-Remote $tmpSh '/tmp/og-deploy-auth-fix.sh'
    Invoke-Remote 'bash /tmp/og-deploy-auth-fix.sh'

    Log 'DONE'
    Add-Type -AssemblyName System.Windows.Forms
    [System.Windows.Forms.MessageBox]::Show("Deploy finished.`nSee $log", 'OG Deploy') | Out-Null
} catch {
    Log ("ERROR: " + $_.Exception.Message)
    Add-Type -AssemblyName System.Windows.Forms
    [System.Windows.Forms.MessageBox]::Show("Deploy error: $($_.Exception.Message)`nSee $log", 'OG Deploy') | Out-Null
    exit 1
}
