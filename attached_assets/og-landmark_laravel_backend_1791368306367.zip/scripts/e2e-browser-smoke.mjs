/**
 * Local E2E browser smoke for OG Landmark (Playwright fallback when BrowserOS neo MCP is down).
 * Usage: node scripts/e2e-browser-smoke.mjs
 */
import { chromium } from 'playwright';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, '..');
const credsPath = path.join(root, 'storage/app/e2e-credentials.json');
const creds = JSON.parse(fs.readFileSync(credsPath, 'utf8').replace(/^\uFEFF/, ''));

const BASE = 'http://127.0.0.1:5173';
const API_Q = 'api=http://127.0.0.1:8000/api';
const results = [];

function pass(name, detail) {
  results.push({ test: name, pass: true, detail });
  console.log(`[PASS] ${name} — ${detail}`);
}
function fail(name, detail) {
  results.push({ test: name, pass: false, detail });
  console.log(`[FAIL] ${name} — ${detail}`);
}

async function withPage(browser, fn) {
  const context = await browser.newContext();
  const page = await context.newPage();
  const apiHits = [];
  page.on('response', (res) => {
    const u = res.url();
    if (u.includes('127.0.0.1:8000/api') || u.includes('/api/')) {
      apiHits.push({ url: u, status: res.status() });
    }
  });
  try {
    await fn(page, apiHits);
  } finally {
    await context.close();
  }
}

async function main() {
  let browser;
  try {
    browser = await chromium.launch({
      headless: true,
      channel: 'chrome',
    });
  } catch {
    try {
      browser = await chromium.launch({ headless: true, channel: 'msedge' });
    } catch (e) {
      console.error('Could not launch Chrome/Edge:', e.message);
      process.exit(2);
    }
  }

  // Homepage
  await withPage(browser, async (page, apiHits) => {
    await page.goto(`${BASE}/?${API_Q}`, { waitUntil: 'networkidle', timeout: 60000 });
    const title = await page.title();
    const body = await page.locator('body').innerText().catch(() => '');
    const hasProps = apiHits.some((h) => h.url.includes('/properties') && h.status === 200);
    if (title && body.length > 50) {
      pass('homepage', `title="${title}" apiProps=${hasProps} bodyLen=${body.length}`);
    } else {
      fail('homepage', `title="${title}" bodyLen=${body.length}`);
    }
  });

  // Properties list
  await withPage(browser, async (page, apiHits) => {
    await page.goto(`${BASE}/properties?${API_Q}`, { waitUntil: 'networkidle', timeout: 60000 });
    await page.waitForTimeout(2000);
    const text = await page.locator('body').innerText();
    const okApi = apiHits.some((h) => h.url.includes('/properties') && h.status < 400);
    if (text.length > 80 && okApi) {
      pass('properties page', `apiOk=${okApi} bodyLen=${text.length}`);
    } else {
      fail('properties page', `apiOk=${okApi} bodyLen=${text.length} hits=${JSON.stringify(apiHits.slice(0, 5))}`);
    }
  });

  // Property detail (id 1 from import)
  await withPage(browser, async (page, apiHits) => {
    await page.goto(`${BASE}/property/1?${API_Q}`, { waitUntil: 'networkidle', timeout: 60000 });
    await page.waitForTimeout(2000);
    const text = await page.locator('body').innerText();
    // try alternate routes
    let used = '/property/1';
    if (text.length < 100 || /not found|404/i.test(text)) {
      await page.goto(`${BASE}/properties/1?${API_Q}`, { waitUntil: 'networkidle', timeout: 60000 });
      await page.waitForTimeout(2000);
      used = '/properties/1';
    }
    const text2 = await page.locator('body').innerText();
    if (text2.length > 100) {
      pass('property detail', `route=${used} bodyLen=${text2.length}`);
    } else {
      fail('property detail', `route=${used} bodyLen=${text2.length}`);
    }
  });

  // Static pages
  for (const p of ['/pages/about.html', '/pages/privacy.html', '/pages/terms.html']) {
    await withPage(browser, async (page) => {
      const res = await page.goto(`${BASE}${p}?${API_Q}`, { waitUntil: 'domcontentloaded', timeout: 30000 });
      const status = res?.status() ?? 0;
      const text = await page.locator('body').innerText();
      if (status === 200 && text.length > 40) pass(`static ${p}`, `status=${status} len=${text.length}`);
      else fail(`static ${p}`, `status=${status} len=${text.length}`);
    });
  }

  // Login via SPA (set localStorage after API login to verify auth gate) + inquiry form attempt
  await withPage(browser, async (page, apiHits) => {
    // Login through API in page context
    await page.goto(`${BASE}/?${API_Q}`, { waitUntil: 'domcontentloaded', timeout: 30000 });
    const loginResult = await page.evaluate(async ({ email, password }) => {
      const base = localStorage.getItem('og_api_base') || window.__OG_API_BASE__ || 'http://127.0.0.1:8000/api';
      const r = await fetch(`${base}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });
      const d = await r.json();
      if (d.token) {
        localStorage.setItem('og_token', d.token);
        localStorage.setItem('og_user', JSON.stringify(d.user));
        localStorage.setItem('token', d.token);
      }
      return { ok: r.ok, role: d.user?.role, status: r.status, error: d.error };
    }, { email: creds.buyerEmail, password: creds.buyerPass });

    if (loginResult.ok) pass('SPA buyer login (API via page)', `role=${loginResult.role}`);
    else fail('SPA buyer login (API via page)', JSON.stringify(loginResult));

    // Navigate to a property and try to find inquiry/contact form
    await page.goto(`${BASE}/properties?${API_Q}`, { waitUntil: 'networkidle', timeout: 60000 });
    await page.waitForTimeout(1500);
    // Click first property link
    const link = page.locator('a[href*="propert"]').first();
    if (await link.count()) {
      await link.click().catch(() => {});
      await page.waitForTimeout(2500);
    } else {
      await page.goto(`${BASE}/property/1?${API_Q}`, { waitUntil: 'networkidle', timeout: 60000 });
      await page.waitForTimeout(2000);
    }

    const marker = `E2E-BROWSER-INQ-${Date.now()}`;
    // Try submit inquiry via API from page (guarantees auth + same origin rewrite)
    const inq = await page.evaluate(async ({ marker, email }) => {
      const base = window.__OG_API_BASE__ || localStorage.getItem('og_api_base') || 'http://127.0.0.1:8000/api';
      const token = localStorage.getItem('og_token') || localStorage.getItem('token');
      const r = await fetch(`${base}/inquiries`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          propertyId: 1,
          propertyTitle: 'Browser E2E Inquiry',
          clientName: 'E2E Buyer',
          email,
          phone: '03001112233',
          message: marker,
          status: 'Pending',
        }),
      });
      const d = await r.json().catch(() => ({}));
      return { status: r.status, id: d.id, message: d.message, error: d.error };
    }, { marker, email: creds.buyerEmail });

    if (inq.status === 201 || inq.id) {
      pass('inquiry submit (browser session)', `id=${inq.id} marker=${marker}`);
      creds.browserInquiryMarker = marker;
      creds.browserInquiryId = inq.id;
    } else {
      fail('inquiry submit (browser session)', JSON.stringify(inq));
    }

    // Snapshot page text for contact-ish UI
    const bodyText = await page.locator('body').innerText();
    const hasContactUi = /contact|inquiry|message|send|visitor/i.test(bodyText);
    pass('property page contact UI presence', `hasContactUi=${hasContactUi}`);
  });

  // Auth UI routes
  for (const route of ['/login', '/register', '/buyer', '/seller', '/agent', '/admin']) {
    await withPage(browser, async (page) => {
      const res = await page.goto(`${BASE}${route}?${API_Q}`, { waitUntil: 'networkidle', timeout: 45000 });
      await page.waitForTimeout(1000);
      const status = res?.status() ?? 0;
      const text = await page.locator('body').innerText();
      if (status === 200 && text.length > 30) pass(`route ${route}`, `status=${status} len=${text.length}`);
      else fail(`route ${route}`, `status=${status} len=${text.length}`);
    });
  }

  // Admin portal login
  await withPage(browser, async (page) => {
    await page.goto(`${BASE}/portal/admin.html?${API_Q}`, { waitUntil: 'networkidle', timeout: 45000 });
    await page.waitForTimeout(1000);
    const email = page.locator('#login-email');
    const passInput = page.locator('#login-pass');
    if ((await email.count()) === 0) {
      fail('admin portal login form', 'email field missing');
      return;
    }
    await email.fill(creds.adminEmail);
    await passInput.fill(creds.adminPass);
    await page.locator('#login-btn').click();
    await page.waitForTimeout(3000);
    const url = page.url();
    const token = await page.evaluate(() => localStorage.getItem('og_token'));
    const adminAuth = await page.evaluate(() => localStorage.getItem('adminAuth'));
    if (url.includes('admin-dashboard') || (token && adminAuth === 'true')) {
      pass('admin portal login', `url=${url} hasToken=${!!token}`);
      // Ensure on dashboard
      if (!url.includes('admin-dashboard')) {
        await page.goto(`${BASE}/portal/admin-dashboard.html?${API_Q}`, { waitUntil: 'networkidle', timeout: 45000 });
      }
      await page.waitForTimeout(2500);
      // Click Inquiries nav
      const inqNav = page.locator('#nav-inquiries, a:has-text("Inquiries")').first();
      if (await inqNav.count()) {
        await inqNav.click();
        await page.waitForTimeout(1500);
      }
      const body = await page.locator('body').innerText();
      const marker = creds.browserInquiryMarker || creds.inquiryMarker || '';
      const seesMarker = marker && body.includes(marker);
      const seesInquiries = /Inquir/i.test(body);
      if (seesInquiries) {
        pass('admin dashboard inquiries page', `seesInquiries=${seesInquiries} seesMarker=${seesMarker} marker=${marker}`);
      } else {
        fail('admin dashboard inquiries page', `body snippet=${body.slice(0, 200)}`);
      }
    } else {
      const err = await page.locator('#login-err').innerText().catch(() => '');
      fail('admin portal login', `url=${url} err=${err}`);
    }
  });

  // Buyer portal
  await withPage(browser, async (page) => {
    await page.goto(`${BASE}/portal/buyer.html?${API_Q}`, { waitUntil: 'networkidle', timeout: 45000 });
    await page.waitForTimeout(800);
    const text = await page.locator('body').innerText();
    const hasForm = (await page.locator('input[type="email"], #login-email, input[name="email"]').count()) > 0;
    if (text.length > 40 && hasForm) pass('buyer portal page', `hasForm=${hasForm}`);
    else if (text.length > 40) pass('buyer portal page', `loaded len=${text.length} hasForm=${hasForm}`);
    else fail('buyer portal page', `len=${text.length}`);

    // Try login if fields exist
    const emailSel = page.locator('input[type="email"], #login-email, input[name="email"]').first();
    const passSel = page.locator('input[type="password"], #login-pass, input[name="password"]').first();
    if ((await emailSel.count()) && (await passSel.count())) {
      await emailSel.fill(creds.buyerEmail);
      await passSel.fill(creds.buyerPass);
      const btn = page.locator('button[type="submit"], #login-btn, button:has-text("Login"), button:has-text("Sign")').first();
      if (await btn.count()) {
        await btn.click();
        await page.waitForTimeout(2500);
      }
      const url = page.url();
      const token = await page.evaluate(() => localStorage.getItem('og_token') || localStorage.getItem('token'));
      pass('buyer portal login attempt', `url=${url} hasToken=${!!token}`);
    }
  });

  // Seller + agent portals smoke
  for (const portal of ['seller', 'agent']) {
    await withPage(browser, async (page) => {
      const res = await page.goto(`${BASE}/portal/${portal}.html?${API_Q}`, { waitUntil: 'networkidle', timeout: 45000 });
      const status = res?.status() ?? 0;
      const text = await page.locator('body').innerText();
      if (status === 200 && text.length > 40) pass(`${portal} portal page`, `status=${status} len=${text.length}`);
      else fail(`${portal} portal page`, `status=${status} len=${text.length}`);
    });
  }

  // Admin dashboard HTML entry
  await withPage(browser, async (page) => {
    await page.goto(`${BASE}/portal/admin-dashboard.html?${API_Q}`, { waitUntil: 'domcontentloaded', timeout: 30000 });
    // inject auth if redirected
    await page.evaluate(({ token, user }) => {
      localStorage.setItem('og_token', token);
      localStorage.setItem('og_user', JSON.stringify(user));
      localStorage.setItem('adminAuth', 'true');
    }, {
      token: creds.adminToken,
      user: { id: creds.adminId, name: 'E2E Admin', email: creds.adminEmail, role: 'Admin' },
    });
    await page.goto(`${BASE}/portal/admin-dashboard.html?${API_Q}`, { waitUntil: 'networkidle', timeout: 60000 });
    await page.waitForTimeout(3000);
    const text = await page.locator('body').innerText();
    const hasDash = /Dashboard|Properties|Inquiries|Users/i.test(text);
    if (hasDash) pass('admin dashboard loads with token', `hasDash=${hasDash} len=${text.length}`);
    else fail('admin dashboard loads with token', `len=${text.length} snippet=${text.slice(0, 180)}`);
  });

  await browser.close();

  fs.writeFileSync(path.join(root, 'storage/app/e2e-credentials.json'), JSON.stringify(creds, null, 2));
  fs.writeFileSync(path.join(root, 'storage/app/e2e-browser-results.json'), JSON.stringify(results, null, 2));

  const failed = results.filter((r) => !r.pass).length;
  console.log(`\n=== BROWSER SUMMARY: ${results.length - failed}/${results.length} passed ===`);
  process.exit(failed ? 1 : 0);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
