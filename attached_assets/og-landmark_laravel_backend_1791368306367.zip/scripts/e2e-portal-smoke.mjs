/**
 * Portal HTML E2E — inject auth tokens (API already verified), then exercise portal UIs on :5175 (no SPA -s).
 * Note: preview:stack :5173 uses serve -s which currently serves SPA index for /portal/*.html (defect).
 */
import { chromium } from 'playwright';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const creds = JSON.parse(fs.readFileSync(path.join(root, 'storage/app/e2e-credentials.json'), 'utf8').replace(/^\uFEFF/, ''));
const BASE = 'http://127.0.0.1:5175';
const API = 'http://127.0.0.1:8000/api';
const results = [];

function pass(n, d) { results.push({ test: n, pass: true, detail: d }); console.log(`[PASS] ${n} — ${d}`); }
function fail(n, d) { results.push({ test: n, pass: false, detail: d }); console.log(`[FAIL] ${n} — ${d}`); }

async function api(method, pathName, body, token) {
  const r = await fetch(`${API}${pathName}`, {
    method,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  const text = await r.text();
  let data;
  try { data = JSON.parse(text); } catch { data = { raw: text.slice(0, 120) }; }
  return { status: r.status, data };
}

async function main() {
  let browser;
  try { browser = await chromium.launch({ headless: true, channel: 'chrome' }); }
  catch { browser = await chromium.launch({ headless: true, channel: 'msedge' }); }

  // Fresh admin token
  const av = await api('POST', '/auth/admin-verify', { email: creds.adminEmail, password: creds.adminPass });
  if (av.status !== 200 || !av.data.token) {
    fail('admin token refresh', JSON.stringify(av));
    process.exit(1);
  }
  const adminToken = av.data.token;
  const adminUser = av.data.user;
  pass('admin token refresh', `role=${adminUser.role}`);

  // Fresh buyer token
  const bl = await api('POST', '/auth/login', { email: creds.buyerEmail, password: creds.buyerPass });
  const buyerToken = bl.data.token;
  const buyerUser = bl.data.user;
  pass('buyer token refresh', `role=${buyerUser?.role} status=${bl.status}`);

  // Confirm inquiry still visible via API
  const inqs = await api('GET', '/inquiries', null, adminToken);
  const marker = creds.browserInquiryMarker || creds.inquiryMarker;
  const found = Array.isArray(inqs.data) && inqs.data.some((i) => i.message === marker || i.id === creds.browserInquiryId || i.id === creds.inquiryId);
  pass('admin API inquiries contain E2E', `count=${Array.isArray(inqs.data) ? inqs.data.length : 0} found=${found} marker=${marker}`);

  // Admin portal HTML loads + login form present
  {
    const ctx = await browser.newContext();
    const page = await ctx.newPage();
    await page.goto(`${BASE}/portal/admin.html`, { waitUntil: 'domcontentloaded', timeout: 30000 });
    const hasEmail = await page.locator('#login-email').count();
    const title = await page.title();
    if (hasEmail) pass('admin portal HTML form', `title=${title}`);
    else fail('admin portal HTML form', `title=${title}`);

    // Inject session and open dashboard
    await page.evaluate(({ token, user }) => {
      localStorage.setItem('og_token', token);
      localStorage.setItem('og_user', JSON.stringify(user));
      localStorage.setItem('adminAuth', 'true');
      localStorage.setItem('og_api_base', 'http://127.0.0.1:8000/api');
    }, { token: adminToken, user: adminUser });

    // Dashboard with API proxied via page.evaluate fetches to absolute API (CORS: need 5175 in allow list OR use init script)
    // Use CDP/addInitScript won't help CORS. Load dashboard and override fetch in page before scripts run.
    await ctx.close();
  }

  // Load dashboard with request interception BEFORE navigation scripts using route from Node fetch
  {
    const ctx = await browser.newContext();
    await ctx.route(/http:\/\/127\.0\.0\.1:5175\/api\/.*/, async (route) => {
      const u = route.request().url().replace('http://127.0.0.1:5175/api', API);
      const headers = { ...route.request().headers() };
      delete headers['host'];
      const res = await fetch(u, {
        method: route.request().method(),
        headers,
        body: ['POST', 'PUT', 'PATCH'].includes(route.request().method()) ? route.request().postData() : undefined,
      });
      const buf = Buffer.from(await res.arrayBuffer());
      const rh = {};
      res.headers.forEach((v, k) => { rh[k] = v; });
      // Avoid CORS issues by fulfilling as same-origin
      await route.fulfill({ status: res.status, headers: { ...rh, 'access-control-allow-origin': '*' }, body: buf });
    });
    // Also allow absolute API calls from og-api-base pointing at 8000 — fulfill CORS
    await ctx.route(/http:\/\/127\.0\.0\.1:8000\/api\/.*/, async (route) => {
      if (route.request().method() === 'OPTIONS') {
        await route.fulfill({
          status: 204,
          headers: {
            'access-control-allow-origin': 'http://127.0.0.1:5175',
            'access-control-allow-methods': 'GET,POST,PUT,PATCH,DELETE,OPTIONS',
            'access-control-allow-headers': 'Content-Type,Authorization',
          },
        });
        return;
      }
      const res = await fetch(route.request().url(), {
        method: route.request().method(),
        headers: route.request().headers(),
        body: ['POST', 'PUT', 'PATCH'].includes(route.request().method()) ? route.request().postData() : undefined,
      });
      const buf = Buffer.from(await res.arrayBuffer());
      const rh = { 'access-control-allow-origin': 'http://127.0.0.1:5175' };
      res.headers.forEach((v, k) => { rh[k] = v; });
      await route.fulfill({ status: res.status, headers: rh, body: buf });
    });

    const page = await ctx.newPage();
    await page.addInitScript(({ token, user }) => {
      localStorage.setItem('og_token', token);
      localStorage.setItem('og_user', JSON.stringify(user));
      localStorage.setItem('adminAuth', 'true');
      localStorage.setItem('og_api_base', 'http://127.0.0.1:8000/api');
    }, { token: adminToken, user: adminUser });

    await page.goto(`${BASE}/portal/admin-dashboard.html`, { waitUntil: 'networkidle', timeout: 90000 });
    await page.waitForTimeout(4000);
    const dash = await page.locator('body').innerText();
    if (/Dashboard|Properties|Inquiries|Users/i.test(dash) && !/404 Page Not Found/i.test(dash)) {
      pass('admin dashboard UI', `len=${dash.length}`);
    } else {
      fail('admin dashboard UI', dash.slice(0, 250));
    }

    const nav = page.locator('#nav-inquiries');
    if (await nav.count()) {
      await nav.click();
      await page.waitForTimeout(2000);
    }
    const inqPage = await page.locator('#page-inquiries').innerText().catch(() => '');
    const body = await page.locator('body').innerText();
    const text = inqPage || body;
    const seesMarker = marker && text.includes(marker);
    const hasRows = (await page.locator('#page-inquiries tbody tr').count().catch(() => 0)) > 0;
    if (seesMarker || hasRows || /Inquir/i.test(text)) {
      pass('admin inquiries UI', `seesMarker=${seesMarker} hasRows=${hasRows}`);
    } else {
      fail('admin inquiries UI', text.slice(0, 300));
    }
    await ctx.close();
  }

  // Buyer / seller / agent portal HTML smoke
  for (const p of ['buyer', 'seller', 'agent']) {
    const ctx = await browser.newContext();
    const page = await ctx.newPage();
    await page.goto(`${BASE}/portal/${p}.html`, { waitUntil: 'domcontentloaded', timeout: 30000 });
    const text = await page.locator('body').innerText();
    const hasPass = (await page.locator('input[type="password"]').count()) > 0;
    if (text.length > 80 && hasPass) pass(`${p} portal HTML`, `len=${text.length}`);
    else fail(`${p} portal HTML`, `len=${text.length} hasPass=${hasPass}`);
    await ctx.close();
  }

  // Buyer dashboard with token
  {
    const ctx = await browser.newContext();
    await ctx.route(/http:\/\/127\.0\.0\.1:8000\/api\/.*/, async (route) => {
      if (route.request().method() === 'OPTIONS') {
        await route.fulfill({
          status: 204,
          headers: {
            'access-control-allow-origin': 'http://127.0.0.1:5175',
            'access-control-allow-methods': 'GET,POST,PUT,PATCH,DELETE,OPTIONS',
            'access-control-allow-headers': 'Content-Type,Authorization',
          },
        });
        return;
      }
      const res = await fetch(route.request().url(), {
        method: route.request().method(),
        headers: route.request().headers(),
        body: ['POST', 'PUT', 'PATCH'].includes(route.request().method()) ? route.request().postData() : undefined,
      });
      const buf = Buffer.from(await res.arrayBuffer());
      const rh = { 'access-control-allow-origin': 'http://127.0.0.1:5175' };
      res.headers.forEach((v, k) => { rh[k] = v; });
      await route.fulfill({ status: res.status, headers: rh, body: buf });
    });
    const page = await ctx.newPage();
    await page.addInitScript(({ token, user }) => {
      localStorage.setItem('og_token', token);
      localStorage.setItem('og_user', JSON.stringify(user));
      localStorage.setItem('buyerAuth', 'true');
      localStorage.setItem('og_api_base', 'http://127.0.0.1:8000/api');
    }, { token: buyerToken, user: buyerUser });
    const res = await page.goto(`${BASE}/portal/buyer-dashboard.html`, { waitUntil: 'networkidle', timeout: 60000 });
    await page.waitForTimeout(2500);
    const text = await page.locator('body').innerText();
    if ((res?.status() ?? 0) === 200 && text.length > 100 && !/404 Page Not Found/i.test(text)) {
      pass('buyer dashboard UI', `len=${text.length}`);
    } else {
      fail('buyer dashboard UI', `status=${res?.status()} ${text.slice(0, 200)}`);
    }
    await ctx.close();
  }

  // Seller register + dashboard
  {
    const reg = await api('POST', '/auth/register', {
      name: 'E2E Seller',
      email: `e2e.seller.${Date.now()}@oglandmark.test`,
      password: 'E2eSeller!2026',
      role: 'seller',
    });
    if (reg.data?.token) {
      creds.sellerEmail = reg.data.user.email;
      creds.sellerPass = 'E2eSeller!2026';
      pass('seller register API', `id=${reg.data.user.id}`);
      const ctx = await browser.newContext();
      await ctx.route(/http:\/\/127\.0\.0\.1:8000\/api\/.*/, async (route) => {
        if (route.request().method() === 'OPTIONS') {
          await route.fulfill({
            status: 204,
            headers: {
              'access-control-allow-origin': 'http://127.0.0.1:5175',
              'access-control-allow-methods': 'GET,POST,PUT,PATCH,DELETE,OPTIONS',
              'access-control-allow-headers': 'Content-Type,Authorization',
            },
          });
          return;
        }
        const res = await fetch(route.request().url(), {
          method: route.request().method(),
          headers: route.request().headers(),
          body: ['POST', 'PUT', 'PATCH'].includes(route.request().method()) ? route.request().postData() : undefined,
        });
        const buf = Buffer.from(await res.arrayBuffer());
        const rh = { 'access-control-allow-origin': 'http://127.0.0.1:5175' };
        res.headers.forEach((v, k) => { rh[k] = v; });
        await route.fulfill({ status: res.status, headers: rh, body: buf });
      });
      const page = await ctx.newPage();
      await page.addInitScript(({ token, user }) => {
        localStorage.setItem('og_token', token);
        localStorage.setItem('og_user', JSON.stringify(user));
        localStorage.setItem('sellerAuth', 'true');
        localStorage.setItem('og_api_base', 'http://127.0.0.1:8000/api');
      }, { token: reg.data.token, user: reg.data.user });
      await page.goto(`${BASE}/portal/seller-dashboard.html`, { waitUntil: 'networkidle', timeout: 60000 });
      await page.waitForTimeout(2500);
      const text = await page.locator('body').innerText();
      if (text.length > 100 && !/404 Page Not Found/i.test(text)) pass('seller dashboard UI', `len=${text.length}`);
      else fail('seller dashboard UI', text.slice(0, 200));
      await ctx.close();
    } else {
      fail('seller register API', JSON.stringify(reg));
    }
  }

  // Document SPA -s portal defect on 5173
  {
    const ctx = await browser.newContext();
    const page = await ctx.newPage();
    await page.goto('http://127.0.0.1:5173/portal/admin.html?api=http://127.0.0.1:8000/api', { waitUntil: 'domcontentloaded', timeout: 30000 });
    const hasLogin = await page.locator('#login-email').count();
    const text = await page.locator('body').innerText();
    if (hasLogin === 0) {
      fail('preview:stack portals on :5173', 'serve -s rewrites /portal/*.html to SPA index (use :5175 without -s or fix serve config)');
    } else {
      pass('preview:stack portals on :5173', 'admin form present');
    }
    // also note SPA still works
    if (text.length > 50) pass('spa still loads when hitting /portal on :5173', `len=${text.length}`);
    await ctx.close();
  }

  await browser.close();

  fs.writeFileSync(path.join(root, 'storage/app/e2e-credentials.json'), JSON.stringify(creds, null, 2));
  let prev = [];
  try {
    prev = JSON.parse(fs.readFileSync(path.join(root, 'storage/app/e2e-browser-results.json'), 'utf8').replace(/^\uFEFF/, ''));
  } catch {}
  const spa = prev.filter((r) => !/portal|admin dashboard|admin inquiries|buyer dashboard|seller/i.test(r.test));
  const all = [...spa, ...results];
  fs.writeFileSync(path.join(root, 'storage/app/e2e-browser-results.json'), JSON.stringify(all, null, 2));
  const failed = results.filter((r) => !r.pass).length;
  console.log(`\n=== PORTAL SUMMARY: ${results.length - failed}/${results.length} passed ===`);
  process.exit(failed ? 1 : 0);
}

main().catch((e) => { console.error(e); process.exit(1); });
