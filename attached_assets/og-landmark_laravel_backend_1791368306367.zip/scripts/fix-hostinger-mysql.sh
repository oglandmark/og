#!/usr/bin/env bash
# Fix Laravel MySQL 1045 on Hostinger shared hosting.
# Run from SSH inside (or pass) the live API root:
#   /home/u133241207/domains/oglandmark.com/public_html/api
set -euo pipefail

APP_DIR="${1:-/home/u133241207/domains/oglandmark.com/public_html/api}"
cd "$APP_DIR"

if [[ ! -f .env ]]; then
  echo "ERROR: .env not found in $APP_DIR"
  exit 1
fi

cp -a .env ".env.bak.$(date +%Y%m%d%H%M%S)"

# Prefer localhost over 127.0.0.1 (Hostinger grants are usually user@localhost)
if grep -qE '^DB_HOST=' .env; then
  sed -i 's/^DB_HOST=.*/DB_HOST=localhost/' .env
else
  echo 'DB_HOST=localhost' >> .env
fi

# Avoid DATABASE_URL / DB_URL overriding DB_* with stale creds
sed -i -E 's/^(DATABASE_URL=)/#\1/' .env
sed -i -E 's/^(DB_URL=)/#\1/' .env

# File cache until DB is healthy (optimize:clear was failing on database cache)
if grep -qE '^CACHE_STORE=' .env; then
  sed -i 's/^CACHE_STORE=.*/CACHE_STORE=file/' .env
else
  echo 'CACHE_STORE=file' >> .env
fi

echo "=== DB config (password masked) ==="
grep -E '^(DB_|DATABASE_URL|CACHE_STORE)=' .env | sed -E 's/(PASSWORD|URL)=.*/\1=***/'

# Load password for mysql CLI test without echoing it
DB_USER=$(grep -E '^DB_USERNAME=' .env | head -1 | cut -d= -f2- | tr -d '"' | tr -d "'")
DB_NAME=$(grep -E '^DB_DATABASE=' .env | head -1 | cut -d= -f2- | tr -d '"' | tr -d "'")
DB_PASS=$(grep -E '^DB_PASSWORD=' .env | head -1 | cut -d= -f2- | tr -d '"' | tr -d "'")
DB_HOST=$(grep -E '^DB_HOST=' .env | head -1 | cut -d= -f2- | tr -d '"' | tr -d "'")

echo "=== mysql CLI test ($DB_USER@$DB_HOST / $DB_NAME) ==="
if mysql -h "$DB_HOST" -u "$DB_USER" -p"$DB_PASS" "$DB_NAME" -e "SELECT 1 AS ok;" ; then
  echo "MYSQL_OK"
else
  echo "MYSQL_FAIL — reset password in hPanel and update DB_PASSWORD, or Add user to database with All Privileges"
  exit 2
fi

php artisan config:clear
php artisan cache:clear || true
php artisan migrate --force
php artisan config:cache

echo "=== healthz ==="
curl -sS https://api.oglandmark.com/api/healthz || true
echo
echo "DONE"
