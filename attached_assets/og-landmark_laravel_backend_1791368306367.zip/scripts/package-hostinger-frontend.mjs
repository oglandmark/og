/**
 * Package the production static site for Hostinger public_html.
 *
 * Output:
 *   frontend/build/     (folder ready to upload)
 *   frontend/build.zip  (same contents zipped)
 *
 * index.prod.html is renamed to index.html in the package.
 * Does NOT use frontend/dist/ (Vite scaffold) — that would break production.
 *
 * Prefer: npm run build  (alias: build:live / package:hostinger / build:hostinger)
 */
import {
  copyFileSync,
  cpSync,
  existsSync,
  mkdirSync,
  readFileSync,
  readdirSync,
  rmSync,
  statSync,
  writeFileSync,
} from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const frontend = path.join(root, 'frontend');
const outDir = path.join(frontend, 'build');
const outZip = path.join(frontend, 'build.zip');

const prodIndex = path.join(frontend, 'index.prod.html');
const assetsDir = path.join(frontend, 'assets');

const UPLOAD_README = `OG Landmark — Hostinger upload package
=====================================

Upload ALL files in this folder (or unzip this archive) into the document root
of oglandmark.com (usually public_html/).

Required after extract:
  - index.html          (production shell — NOT index.vite.html)
  - og-api-base.js
  - og-force-db.js
  - .htaccess
  - assets/             (hashed production React bundle)
  - admin/              (React admin SPA at /admin)
  - user/               (React user SPA at /user)
  - portal/             (legacy static portals — optional fallback)

Do NOT upload frontend/dist/ (Vite scaffold). That shows
"Vite + React toolchain restored" instead of the real homepage.

Rebuild this package from the repo root or frontend/:
  npm run build

Output: frontend/build/ and frontend/build.zip
`;

function fail(msg) {
  console.error(`package:hostinger — ${msg}`);
  process.exit(1);
}

if (!existsSync(prodIndex)) {
  fail(`Missing ${path.relative(root, prodIndex)}`);
}
if (!existsSync(assetsDir) || !statSync(assetsDir).isDirectory()) {
  fail(`Missing ${path.relative(root, assetsDir)}/`);
}

const hashedJs = readdirSync(assetsDir).filter((f) => /^index-.*\.js$/.test(f));
if (hashedJs.length === 0) {
  fail('No hashed assets/index-*.js found — production React bundle is missing.');
}

// Fresh stage directory
if (existsSync(outDir)) {
  rmSync(outDir, { recursive: true, force: true });
}
mkdirSync(outDir, { recursive: true });

/** Copy a file if it exists; warn if optional, fail if required. */
function copyRootFile(name, { required = true } = {}) {
  const src = path.join(frontend, name);
  if (!existsSync(src)) {
    if (required) fail(`Missing required file: frontend/${name}`);
    console.warn(`  skip (missing): ${name}`);
    return;
  }
  copyFileSync(src, path.join(outDir, name));
  console.log(`  + ${name}`);
}

/** Copy a directory tree if present. */
function copyDir(name, { required = true } = {}) {
  const src = path.join(frontend, name);
  if (!existsSync(src) || !statSync(src).isDirectory()) {
    if (required) fail(`Missing required directory: frontend/${name}/`);
    console.warn(`  skip (missing): ${name}/`);
    return;
  }
  cpSync(src, path.join(outDir, name), { recursive: true });
  console.log(`  + ${name}/`);
}

/** Fail if staged index.html looks like the Vite scaffold entry. */
function validateStagedIndex() {
  const staged = path.join(outDir, 'index.html');
  if (!existsSync(staged)) {
    fail('Staged index.html missing after copy.');
  }
  const html = readFileSync(staged, 'utf8');
  if (!html.includes('/assets/index-')) {
    fail('Staged index.html must reference /assets/index-*.js (production bundle).');
  }
  if (html.includes('/src/main.tsx')) {
    fail('Staged index.html still points at /src/main.tsx — that is the Vite scaffold, not production.');
  }
  if (html.includes('index.vite')) {
    fail('Staged index.html must not reference index.vite — use index.prod.html as the source.');
  }
  if (!html.includes('og-api-base.js')) {
    fail('Staged index.html must load /og-api-base.js for live API wiring.');
  }
  console.log('  ✓ index.html validated (production shell)');
}

// Strip hardcoded demo property seed before packaging
console.log('Stripping SPA demo property seed…');
const strip = spawnSync(process.execPath, [path.join(root, 'scripts', 'strip-spa-demo-seed.mjs')], {
  stdio: 'inherit',
  cwd: root,
});
if (strip.status !== 0) {
  fail('strip-spa-demo-seed failed');
}

// Build React /admin and /user portal SPAs
console.log('Building React admin + user portals…');
const portals = spawnSync(
  process.platform === 'win32' ? 'npm.cmd' : 'npm',
  ['run', 'build:portals'],
  { stdio: 'inherit', cwd: frontend, shell: true },
);
if (portals.status !== 0) {
  fail('build:portals failed');
}

const distAdmin = path.join(frontend, 'dist-admin');
const distUser = path.join(frontend, 'dist-user');
if (!existsSync(path.join(distAdmin, 'index.html'))) {
  fail('Missing frontend/dist-admin/index.html after portal build');
}
if (!existsSync(path.join(distUser, 'index.html'))) {
  fail('Missing frontend/dist-user/index.html after portal build');
}

/** Stage portal build into live frontend/<name>/ (local serve) and build/<name>/ (deploy). */
function stagePortal(name, distPath) {
  const liveDir = path.join(frontend, name);
  const packDir = path.join(outDir, name);
  if (existsSync(liveDir)) rmSync(liveDir, { recursive: true, force: true });
  if (existsSync(packDir)) rmSync(packDir, { recursive: true, force: true });
  mkdirSync(liveDir, { recursive: true });
  mkdirSync(packDir, { recursive: true });
  // Copy only the portal dist contents (never merge with other site folders).
  for (const entry of readdirSync(distPath)) {
    cpSync(path.join(distPath, entry), path.join(liveDir, entry), { recursive: true });
    cpSync(path.join(distPath, entry), path.join(packDir, entry), { recursive: true });
  }
  if (!existsSync(path.join(liveDir, 'index.html')) || !existsSync(path.join(packDir, 'index.html'))) {
    fail(`Portal ${name} missing index.html after staging`);
  }
  console.log(`  + ${name}/  (from dist-${name})`);
}

console.log('Staging Hostinger frontend package…');

// Entry: production shell must be named index.html on the server
copyFileSync(prodIndex, path.join(outDir, 'index.html'));
console.log('  + index.html  (from index.prod.html)');

copyRootFile('og-api-base.js');
copyRootFile('og-force-db.js');
copyRootFile('.htaccess');
copyRootFile('robots.txt', { required: false });
copyRootFile('favicon.svg', { required: false });
copyRootFile('og-logo.png', { required: false });

copyDir('assets');
copyDir('portal');
copyDir('pages', { required: false });
copyDir('images', { required: false });

stagePortal('admin', distAdmin);
stagePortal('user', distUser);

validateStagedIndex();

writeFileSync(path.join(outDir, 'UPLOAD-README.txt'), UPLOAD_README);
console.log('  + UPLOAD-README.txt');

// Zip via PowerShell Compress-Archive (Windows) or zip (Unix)
if (existsSync(outZip)) {
  rmSync(outZip, { force: true });
}

const isWin = process.platform === 'win32';
let zipOk = false;

if (isWin) {
  // Compress-Archive needs destination without trailing issues; path with spaces/parens needs care
  const ps = `Compress-Archive -Path '${outDir.replace(/'/g, "''")}\\*' -DestinationPath '${outZip.replace(/'/g, "''")}' -Force`;
  const r = spawnSync('powershell', ['-NoProfile', '-Command', ps], {
    stdio: 'inherit',
    cwd: root,
  });
  zipOk = r.status === 0 && existsSync(outZip);
} else {
  const r = spawnSync('zip', ['-r', outZip, '.'], {
    stdio: 'inherit',
    cwd: outDir,
  });
  zipOk = r.status === 0 && existsSync(outZip);
}

if (!zipOk) {
  console.warn('Could not create zip automatically; use the folder instead.');
} else {
  console.log(`\nCreated ${path.relative(root, outZip)}`);
}

console.log(`Created ${path.relative(root, outDir)}/`);
console.log('\nUpload the folder (or zip contents) into Hostinger public_html.');
console.log('Confirm index.html loads /og-api-base.js and /assets/index-*.js.');
console.log('Do NOT upload frontend/dist/ (scaffold). Use: npm run build → frontend/build/');
