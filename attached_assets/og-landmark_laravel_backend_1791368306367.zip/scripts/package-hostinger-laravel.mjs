/**
 * Package the Laravel API for Hostinger (api.oglandmark.com).
 *
 * Default (fast):
 *   dist-hostinger-api-docroot-fix/ + .zip  — root bootstrap only
 *
 * Full tree (slow; includes vendor/):
 *   npm run package:laravel -- --full
 *   → dist-hostinger-laravel/ + .zip
 *
 * Prefer pointing the subdomain document root at public/.
 * If that is not possible, root index.php + default.php + .htaccess
 * replace Hostinger's placeholder page.
 */
import {
  copyFileSync,
  cpSync,
  existsSync,
  mkdirSync,
  readdirSync,
  rmSync,
  statSync,
  writeFileSync,
} from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const outDir = path.join(root, 'dist-hostinger-laravel');
const outZip = path.join(root, 'dist-hostinger-laravel.zip');
const fixZip = path.join(root, 'dist-hostinger-api-docroot-fix.zip');
const fixDir = path.join(root, 'dist-hostinger-api-docroot-fix');
const wantFull = process.argv.includes('--full');

const INCLUDE_DIRS = [
  'app',
  'bootstrap',
  'config',
  'database',
  'public',
  'resources',
  'routes',
  'storage',
  'vendor',
];

const INCLUDE_FILES = [
  'artisan',
  'composer.json',
  'composer.lock',
  'index.php',
  'default.php',
];

const UPLOAD_TXT = `OG Landmark — Laravel API Hostinger upload
================================================

TARGET: api.oglandmark.com (NOT the main website public_html)

Layout after extract (live path):
  /home/u133241207/domains/oglandmark.com/public_html/api/
    artisan
    vendor/
    public/index.php
    index.php          ← boots Laravel when docroot is project root
    default.php        ← replaces Hostinger "You Are All Set" page
    .htaccess

BEST FIX (hPanel):
  Domains → api.oglandmark.com → Document root =
    /home/u133241207/domains/oglandmark.com/public_html/api/public
  Then delete default.php / placeholder index from the old root.

IF YOU CANNOT CHANGE DOCROOT:
  1) Upload/extract this zip into the current api.oglandmark.com folder
     (the folder that currently shows Hostinger default page).
  2) Confirm these exist next to each other:
       public/index.php
       index.php
       default.php
       .htaccess
  3) Delete any Hostinger placeholder index.html if present.

DO NOT upload .env from your PC. Create .env on the server from .env.example.

After extract (SSH / Hostinger terminal):
  cd /path/to/laravel/root
  chmod -R ug+rwx storage bootstrap/cache
  php artisan migrate --force
  php artisan optimize:clear
  php artisan config:cache

Verify:
  https://api.oglandmark.com/api/healthz
`;

const FIX_UPLOAD_TXT = `OG Landmark — API docroot fix (tiny upload)
==========================================

Laravel is already on the server under /public/.
Hostinger serves default.php at the subdomain root.

Upload these THREE files into the SAME folder as public/
(the folder that currently shows "You Are All Set to Go!"):

  index.php
  default.php
  .htaccess

Or set hPanel document root to .../public instead.

Verify: https://api.oglandmark.com/api/healthz
`;

function fail(msg) {
  console.error(`package:laravel — ${msg}`);
  process.exit(1);
}

function shouldSkipStorageEntry(relPosix) {
  if (relPosix.startsWith('logs/')) return true;
  if (relPosix === 'logs') return true;
  if (relPosix.endsWith('.gitignore')) return false;
  if (relPosix.includes('/.gitignore')) return false;
  // Keep framework scaffolding + imports; skip bulky local caches
  if (relPosix.startsWith('framework/cache/data/')) return true;
  if (relPosix.startsWith('framework/sessions/') && relPosix !== 'framework/sessions/.gitignore') {
    return !relPosix.endsWith('.gitignore');
  }
  if (relPosix.startsWith('framework/views/') && !relPosix.endsWith('.gitignore')) return true;
  return false;
}

function copyStorageFiltered(src, dest) {
  mkdirSync(dest, { recursive: true });
  for (const entry of readdirSync(src, { withFileTypes: true })) {
    const from = path.join(src, entry.name);
    const to = path.join(dest, entry.name);
    const rel = entry.name.replace(/\\/g, '/');
    if (entry.isDirectory()) {
      if (shouldSkipStorageEntry(rel + '/')) {
        // still create empty dirs needed by Laravel
        if (rel === 'logs' || rel === 'framework') {
          mkdirSync(to, { recursive: true });
          if (rel === 'framework') {
            for (const sub of ['cache', 'sessions', 'testing', 'views']) {
              mkdirSync(path.join(to, sub), { recursive: true });
              const gi = path.join(src, 'framework', sub, '.gitignore');
              if (existsSync(gi)) copyFileSync(gi, path.join(to, sub, '.gitignore'));
            }
            const cacheData = path.join(to, 'cache', 'data');
            mkdirSync(cacheData, { recursive: true });
            const cgi = path.join(src, 'framework', 'cache', 'data', '.gitignore');
            if (existsSync(cgi)) copyFileSync(cgi, path.join(cacheData, '.gitignore'));
            const fgi = path.join(src, 'framework', 'cache', '.gitignore');
            if (existsSync(fgi)) copyFileSync(fgi, path.join(to, 'cache', '.gitignore'));
          }
          const lgi = path.join(src, 'logs', '.gitignore');
          if (existsSync(lgi)) copyFileSync(lgi, path.join(to, '.gitignore'));
        }
        continue;
      }
      copyStorageFiltered(from, to);
      continue;
    }
    if (shouldSkipStorageEntry(rel)) continue;
    copyFileSync(from, to);
  }
}

function zipFolder(folder, zipPath) {
  if (existsSync(zipPath)) rmSync(zipPath, { force: true });
  if (process.platform === 'win32') {
    const ps = `Compress-Archive -Path '${folder.replace(/'/g, "''")}\\*' -DestinationPath '${zipPath.replace(/'/g, "''")}' -Force`;
    const r = spawnSync('powershell.exe', ['-NoProfile', '-Command', ps], {
      stdio: 'inherit',
    });
    return r.status === 0 && existsSync(zipPath);
  }
  const r = spawnSync('zip', ['-r', zipPath, '.'], { cwd: folder, stdio: 'inherit' });
  return r.status === 0 && existsSync(zipPath);
}

for (const f of ['index.php', 'default.php', 'shared-hosting.htaccess']) {
  if (!existsSync(path.join(root, f))) fail(`Missing ${f}`);
}

const sharedHt = path.join(root, 'shared-hosting.htaccess');

// Tiny docroot-fix package (always)
if (existsSync(fixDir)) rmSync(fixDir, { recursive: true, force: true });
mkdirSync(fixDir, { recursive: true });
copyFileSync(path.join(root, 'index.php'), path.join(fixDir, 'index.php'));
copyFileSync(path.join(root, 'default.php'), path.join(fixDir, 'default.php'));
copyFileSync(sharedHt, path.join(fixDir, '.htaccess'));
writeFileSync(path.join(fixDir, 'UPLOAD.txt'), FIX_UPLOAD_TXT);
console.log('Staging API docroot-fix package…');
console.log('  + index.php');
console.log('  + default.php');
console.log('  + .htaccess');
console.log('  + UPLOAD.txt');
if (!zipFolder(fixDir, fixZip)) {
  console.warn('Could not create dist-hostinger-api-docroot-fix.zip');
} else {
  console.log(`Created ${path.relative(root, fixZip)}`);
}

if (!wantFull) {
  console.log('\nDone (docroot-fix only). For a full Laravel tree: npm run package:laravel -- --full');
  process.exit(0);
}

for (const f of ['artisan', 'composer.json', 'public/index.php', 'vendor/autoload.php']) {
  if (!existsSync(path.join(root, f))) fail(`Missing ${f}`);
}

if (existsSync(outDir)) rmSync(outDir, { recursive: true, force: true });
mkdirSync(outDir, { recursive: true });

console.log('Staging full Laravel Hostinger package…');
for (const dir of INCLUDE_DIRS) {
  const src = path.join(root, dir);
  if (!existsSync(src) || !statSync(src).isDirectory()) fail(`Missing directory: ${dir}/`);
  const dest = path.join(outDir, dir);
  if (dir === 'storage') {
    copyStorageFiltered(src, dest);
    const importSrc = path.join(src, 'app', 'imports', 'og-landmark-data.json');
    if (existsSync(importSrc)) {
      mkdirSync(path.join(dest, 'app', 'imports'), { recursive: true });
      copyFileSync(importSrc, path.join(dest, 'app', 'imports', 'og-landmark-data.json'));
      console.log('  + storage/app/imports/og-landmark-data.json');
    }
  } else {
    cpSync(src, dest, { recursive: true });
  }
  console.log(`  + ${dir}/`);
}

for (const file of INCLUDE_FILES) {
  copyFileSync(path.join(root, file), path.join(outDir, file));
  console.log(`  + ${file}`);
}

copyFileSync(sharedHt, path.join(outDir, '.htaccess'));
console.log('  + .htaccess (from shared-hosting.htaccess)');
copyFileSync(path.join(root, '.env.example'), path.join(outDir, '.env.example'));
console.log('  + .env.example');
writeFileSync(path.join(outDir, 'UPLOAD.txt'), UPLOAD_TXT);
console.log('  + UPLOAD.txt');

console.log('Zipping full package (this can take several minutes)…');
if (!zipFolder(outDir, outZip)) {
  console.warn('Could not create dist-hostinger-laravel.zip; use the folder instead.');
} else {
  console.log(`Created ${path.relative(root, outZip)}`);
}

console.log(`\nCreated ${path.relative(root, outDir)}/`);
console.log('Upload into the api.oglandmark.com folder (see UPLOAD.txt).');
