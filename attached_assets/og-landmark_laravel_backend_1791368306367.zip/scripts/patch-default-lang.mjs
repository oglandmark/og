/**
 * Patch production SPA bundle so English is the clear default language:
 * - LanguageProvider reads/writes localStorage og_lang (fallback "en")
 * - Navbar switcher shows CURRENT language (EN when English is active)
 *
 * Usage: node scripts/patch-default-lang.mjs
 */
import { readFileSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const bundle = path.join(root, 'frontend', 'assets', 'index-CXxrK7KP.js');

const OLD_PROVIDER =
  'function Xwe({children:t}){const[e,n]=D.useState("en"),r=s=>Kwe[e][s]||s;return $e.useEffect(()=>{document.documentElement.setAttribute("dir",e==="ur"?"rtl":"ltr"),document.documentElement.setAttribute("lang",e==="ur"?"ur":"en")},[e]),i.jsx(Bne.Provider,{value:{lang:e,setLang:n,t:r},children:t})}';

const NEW_PROVIDER =
  'function Xwe({children:t}){const[e,n]=D.useState(()=>{try{return localStorage.getItem("og_lang")==="ur"?"ur":"en"}catch{return"en"}}),r=s=>Kwe[e][s]||s;return $e.useEffect(()=>{document.documentElement.setAttribute("dir",e==="ur"?"rtl":"ltr"),document.documentElement.setAttribute("lang",e==="ur"?"ur":"en");try{localStorage.setItem("og_lang",e)}catch{}},[e]),i.jsx(Bne.Provider,{value:{lang:e,setLang:n,t:r},children:t})}';

/** Match X5e label: children:t==="en"?"…":"EN"  (Urdu glyphs may be mojibake in the bundle) */
const LABEL_RE = /children:t==="en"\?"([^"]+)":"EN"/;
const LABEL_RE_ALREADY = /children:t==="en"\?"EN":"([^"]+)"/;

let src = readFileSync(bundle, 'utf8');
let changes = 0;

const providerDone = src.includes(NEW_PROVIDER) && !src.includes(OLD_PROVIDER);
const labelDone = LABEL_RE_ALREADY.test(src) && !LABEL_RE.test(src);

if (providerDone && labelDone) {
  console.log('Already patched:', bundle);
  process.exit(0);
}

if (src.includes(OLD_PROVIDER)) {
  src = src.replace(OLD_PROVIDER, NEW_PROVIDER);
  changes++;
  console.log('Patched LanguageProvider (og_lang + default en)');
} else if (src.includes(NEW_PROVIDER)) {
  console.log('LanguageProvider already patched');
} else {
  console.error('Could not find LanguageProvider (Xwe) pattern in bundle.');
  process.exit(1);
}

const labelMatch = src.match(LABEL_RE);
if (labelMatch) {
  const urdu = labelMatch[1];
  const oldLabel = `children:t==="en"?"${urdu}":"EN"`;
  const newLabel = `children:t==="en"?"EN":"${urdu}"`;
  src = src.replace(oldLabel, newLabel);
  changes++;
  console.log('Patched switcher label (show current language EN)');
} else if (LABEL_RE_ALREADY.test(src)) {
  console.log('Switcher label already patched');
} else {
  console.error('Could not find switcher label pattern in bundle.');
  process.exit(1);
}

if (changes === 0) {
  console.log('No changes needed.');
  process.exit(0);
}

writeFileSync(bundle, src, 'utf8');

const after = readFileSync(bundle, 'utf8');
const ok =
  after.includes(NEW_PROVIDER) &&
  !after.includes(OLD_PROVIDER) &&
  LABEL_RE_ALREADY.test(after) &&
  !LABEL_RE.test(after) &&
  after.includes('localStorage.getItem("og_lang")') &&
  after.includes('localStorage.setItem("og_lang",e)');

if (!ok) {
  console.error('Verification failed after write.');
  process.exit(1);
}

console.log('OK:', bundle);
console.log('  - default/fallback: en via og_lang');
console.log('  - switcher shows EN when English is active');
