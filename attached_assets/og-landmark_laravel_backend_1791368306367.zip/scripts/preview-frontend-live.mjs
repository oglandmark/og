/**
 * Local static preview for the production frontend shell + React portals.
 * Serves frontend/ on 127.0.0.1:5173 with Apache-like SPA fallbacks:
 *   /admin/* → admin/index.html
 *   /user/*  → user/index.html
 *   else missing paths → index.html
 */
import { createServer } from 'node:http';
import {
  copyFileSync,
  existsSync,
  readFileSync,
  statSync,
  createReadStream,
} from 'node:fs';
import net from 'node:net';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const frontend = path.join(root, 'frontend');
const activeIndex = path.join(frontend, 'index.html');
const prodIndex = path.join(frontend, 'index.prod.html');
const viteIndex = path.join(frontend, 'index.vite.html');

const PREVIEW_HOST = '127.0.0.1';
const PREVIEW_PORT = Number.parseInt(process.env.OG_PREVIEW_PORT ?? '5173', 10);
const API_BASE = 'http://127.0.0.1:8000/api';

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.txt': 'text/plain; charset=utf-8',
  '.map': 'application/json',
};

if (!Number.isInteger(PREVIEW_PORT) || PREVIEW_PORT < 1 || PREVIEW_PORT > 65535) {
  console.error(`Invalid OG_PREVIEW_PORT: ${process.env.OG_PREVIEW_PORT}`);
  process.exit(1);
}

if (!existsSync(prodIndex)) {
  console.error('Missing frontend/index.prod.html (production shell).');
  process.exit(1);
}
if (!existsSync(viteIndex)) {
  console.error('Missing frontend/index.vite.html (Vite scaffold shell).');
  process.exit(1);
}

let restored = false;
function restore() {
  if (restored) return;
  restored = true;
  try {
    copyFileSync(viteIndex, activeIndex);
  } catch (err) {
    console.error('Failed to restore Vite index.html:', err);
  }
}

function isPortInUse(host, port) {
  return new Promise((resolve) => {
    const socket = net.createConnection({ host, port }, () => {
      socket.destroy();
      resolve(true);
    });
    socket.setTimeout(500);
    socket.on('timeout', () => {
      socket.destroy();
      resolve(false);
    });
    socket.on('error', () => {
      resolve(false);
    });
  });
}

function printPortBusyHelp(port) {
  console.error('');
  console.error(`  Port ${port} is already in use on ${PREVIEW_HOST}.`);
  console.error('  Local preview requires this port (Laravel CORS allowlist).');
  console.error('');
  console.error('  Free the port, then re-run npm run preview:frontend / npm run preview:stack:');
  console.error('');
  console.error('    Windows (PowerShell):');
  console.error(`      netstat -ano | findstr :${port}`);
  console.error('      taskkill /PID <pid> /F');
  console.error('');
}

function safeJoin(base, urlPath) {
  const decoded = decodeURIComponent(urlPath.split('?')[0].split('#')[0]);
  const cleaned = decoded.replace(/^\/+/, '');
  const full = path.normalize(path.join(base, cleaned));
  if (!full.startsWith(base)) return null;
  return full;
}

function sendFile(res, filePath) {
  const ext = path.extname(filePath).toLowerCase();
  res.writeHead(200, {
    'Content-Type': MIME[ext] || 'application/octet-stream',
    'Cache-Control': ext === '.html' ? 'no-store' : 'public, max-age=60',
  });
  createReadStream(filePath).pipe(res);
}

function resolvePortalHtml(pathname) {
  if (pathname === '/admin' || pathname.startsWith('/admin/')) {
    return path.join(frontend, 'admin', 'index.html');
  }
  if (pathname === '/user' || pathname.startsWith('/user/')) {
    return path.join(frontend, 'user', 'index.html');
  }
  return null;
}

function resolvePortalRewrite(pathname) {
  const map = {
    '/portal/buyer': 'portal/buyer.html',
    '/portal/seller': 'portal/seller.html',
    '/portal/agent': 'portal/agent.html',
    '/portal/admin': 'portal/admin.html',
    '/portal/buyer-dashboard': 'portal/buyer-dashboard.html',
    '/portal/seller-dashboard': 'portal/seller-dashboard.html',
    '/portal/agent-dashboard': 'portal/agent-dashboard.html',
    '/portal/admin-dashboard': 'portal/admin-dashboard.html',
  };
  const key = pathname.replace(/\/$/, '') || '/';
  return map[key] ? path.join(frontend, map[key]) : null;
}

function handler(req, res) {
  try {
    const url = new URL(req.url || '/', `http://${PREVIEW_HOST}`);
    let pathname = url.pathname || '/';

    // Prefer real files (assets, images, exact html)
    const filePath = safeJoin(frontend, pathname);
    if (filePath && existsSync(filePath) && statSync(filePath).isFile()) {
      return sendFile(res, filePath);
    }

    // Directory with index.html
    if (filePath && existsSync(filePath) && statSync(filePath).isDirectory()) {
      const indexInDir = path.join(filePath, 'index.html');
      if (existsSync(indexInDir)) return sendFile(res, indexInDir);
    }

    // React portal SPA fallbacks (client routes under /admin and /user)
    // Skip when the request looks like a missing asset under those prefixes.
    const looksLikeAsset = /\.[a-z0-9]+$/i.test(pathname);
    if (!looksLikeAsset) {
      const portalHtml = resolvePortalHtml(pathname);
      if (portalHtml && existsSync(portalHtml)) return sendFile(res, portalHtml);

      const portalRewrite = resolvePortalRewrite(pathname);
      if (portalRewrite && existsSync(portalRewrite)) return sendFile(res, portalRewrite);

      // Marketing SPA fallback
      const spa = path.join(frontend, 'index.html');
      if (existsSync(spa)) return sendFile(res, spa);
    }

    res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
    res.end('Not found');
  } catch (err) {
    res.writeHead(500, { 'Content-Type': 'text/plain; charset=utf-8' });
    res.end(String(err?.message || err));
  }
}

async function main() {
  if (await isPortInUse(PREVIEW_HOST, PREVIEW_PORT)) {
    printPortBusyHelp(PREVIEW_PORT);
    process.exit(1);
  }

  copyFileSync(prodIndex, activeIndex);

  // Ensure portal builds exist for local preview
  for (const name of ['admin', 'user']) {
    const index = path.join(frontend, name, 'index.html');
    if (!existsSync(index)) {
      console.warn(`  Warning: missing frontend/${name}/index.html — run: npm --prefix frontend run build:portals`);
    }
  }

  const server = createServer(handler);
  server.listen(PREVIEW_PORT, PREVIEW_HOST, () => {
    const origin = `http://${PREVIEW_HOST}:${PREVIEW_PORT}`;
    console.log('');
    console.log('  OG Landmark — full site (production bundle)');
    console.log(`  Open: ${origin}/?api=${API_BASE}`);
    console.log(`  Admin: ${origin}/admin/login`);
    console.log(`  User:  ${origin}/user/`);
    console.log('  Accepting connections at ' + origin);
    console.log('');
  });

  const shutdown = () => {
    restore();
    server.close(() => process.exit(0));
  };
  for (const signal of ['SIGINT', 'SIGTERM', 'SIGHUP']) {
    process.on(signal, shutdown);
  }
}

main().catch((err) => {
  console.error(err);
  restore();
  process.exit(1);
});
