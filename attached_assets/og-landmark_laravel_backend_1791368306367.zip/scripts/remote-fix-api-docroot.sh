#!/usr/bin/env bash
# Run on Hostinger SSH inside the api.oglandmark.com Laravel root
# (the folder that contains public/index.php and currently shows Hostinger default.php).
set -euo pipefail

echo "=== locating Laravel API root ==="
CANDIDATES=(
  "/home/u133241207/domains/oglandmark.com/public_html/api"
  "$PWD"
  "/home/u133241207/domains/api.oglandmark.com/public_html"
  "/home/u133241207/domains/oglandmark.com/public_html/laravel_api2"
)

APP_DIR=""
for d in "${CANDIDATES[@]}"; do
  if [[ -f "$d/public/index.php" && -f "$d/artisan" ]]; then
    APP_DIR="$d"
    break
  fi
done

if [[ -z "$APP_DIR" ]]; then
  FOUND=$(find /home/u133241207/domains -maxdepth 5 -type f -path '*/public/index.php' 2>/dev/null | head -20 || true)
  echo "Could not auto-detect APP_DIR. Candidates with public/index.php:"
  echo "$FOUND"
  exit 1
fi

cd "$APP_DIR"
echo "APP_DIR=$APP_DIR"
ls -la | head -40

echo "=== writing root bootstrap (index.php, default.php, .htaccess) ==="
cat > index.php <<'PHP'
<?php
require __DIR__.'/public/index.php';
PHP

cat > default.php <<'PHP'
<?php
require __DIR__.'/public/index.php';
PHP

cat > .htaccess <<'HTA'
<IfModule mod_rewrite.c>
    RewriteEngine On
    DirectoryIndex index.php default.php
    RewriteCond %{REQUEST_URI} !^/public/
    RewriteCond %{REQUEST_FILENAME} !-f
    RewriteCond %{REQUEST_FILENAME} !-d
    RewriteRule ^(.*)$ public/$1 [L]
    RewriteRule ^$ public/index.php [L]
</IfModule>
HTA

# Neutralize leftover Hostinger HTML placeholders if present
for f in index.html index.htm Default.html default.html; do
  if [[ -f "$f" ]]; then
    mv -f "$f" "${f}.hostinger-bak.$(date +%Y%m%d%H%M%S)"
    echo "renamed $f"
  fi
done

chmod -R ug+rwx storage bootstrap/cache 2>/dev/null || true

MEDIA_DIR="/home/u133241207/domains/oglandmark.com/public_html/shared/media"
mkdir -p "$MEDIA_DIR"
chmod ug+rwx "$MEDIA_DIR" 2>/dev/null || true

if [[ -f .env ]]; then
  echo "=== .env present; aligning production keys + clearing caches ==="
  # Prefer localhost on Hostinger shared MySQL
  if grep -qE '^DB_HOST=' .env; then
    sed -i 's/^DB_HOST=.*/DB_HOST=localhost/' .env
  else
    echo 'DB_HOST=localhost' >> .env
  fi
  if grep -qE '^APP_URL=' .env; then
    sed -i 's|^APP_URL=.*|APP_URL=https://api.oglandmark.com|' .env
  else
    echo 'APP_URL=https://api.oglandmark.com' >> .env
  fi
  if grep -qE '^FRONTEND_URL=' .env; then
    sed -i 's|^FRONTEND_URL=.*|FRONTEND_URL=https://oglandmark.com|' .env
  else
    echo 'FRONTEND_URL=https://oglandmark.com' >> .env
  fi
  if grep -qE '^MEDIA_STORAGE_DIR=' .env; then
    sed -i "s|^MEDIA_STORAGE_DIR=.*|MEDIA_STORAGE_DIR=${MEDIA_DIR}|" .env
  else
    echo "MEDIA_STORAGE_DIR=${MEDIA_DIR}" >> .env
  fi
  if grep -qE '^MEDIA_STORAGE_PERSISTENT=' .env; then
    sed -i 's/^MEDIA_STORAGE_PERSISTENT=.*/MEDIA_STORAGE_PERSISTENT=true/' .env
  else
    echo 'MEDIA_STORAGE_PERSISTENT=true' >> .env
  fi
  if grep -qE '^CACHE_STORE=' .env; then
    sed -i 's/^CACHE_STORE=.*/CACHE_STORE=file/' .env
  else
    echo 'CACHE_STORE=file' >> .env
  fi
  sed -i -E 's/^(DATABASE_URL=)/#\1/' .env
  sed -i -E 's/^(DB_URL=)/#\1/' .env
  php artisan optimize:clear || true
  php artisan config:cache || true
else
  echo "WARNING: .env missing — create from .env.example before production use"
fi

echo "=== local php smoke ==="
php -r 'echo "php_ok\n";'

echo "=== HTTP verify ==="
curl -sS -o /tmp/og_healthz.json -w "healthz_http=%{http_code}\n" https://api.oglandmark.com/api/healthz || true
head -c 400 /tmp/og_healthz.json 2>/dev/null; echo
curl -sS -o /tmp/og_root.html -w "root_http=%{http_code}\n" https://api.oglandmark.com/ || true
head -c 200 /tmp/og_root.html 2>/dev/null; echo

echo "DONE — expect healthz JSON (not Hostinger default page)"
