#!/usr/bin/env bash
# Fix Laravel at the known live path for api.oglandmark.com
# Path: /home/u133241207/domains/oglandmark.com/public_html/api
set -euo pipefail

APP="/home/u133241207/domains/oglandmark.com/public_html/api"
cd "$APP"

echo "=== APP ==="
pwd
ls -la | head -40

if [[ ! -f artisan || ! -f public/index.php ]]; then
  echo "ERROR: Not a Laravel app at $APP"
  exit 1
fi

echo "=== ensure root bootstrap (docroot = project root) ==="
cat > index.php <<'PHP'
<?php
require __DIR__.'/public/index.php';
PHP

cat > default.php <<'PHP'
<?php
require __DIR__.'/public/index.php';
PHP

cat > .htaccess <<'HTA'
DirectoryIndex index.php default.php

<IfModule mod_rewrite.c>
    RewriteEngine On

    RewriteCond %{REQUEST_URI} !^/public/
    RewriteCond %{REQUEST_FILENAME} !-f
    RewriteCond %{REQUEST_FILENAME} !-d
    RewriteRule ^(.*)$ public/$1 [L]

    RewriteRule ^$ public/index.php [L]
</IfModule>
HTA

# Prefer JSON root instead of Laravel welcome HTML
if [[ -f routes/web.php ]]; then
  cp -a routes/web.php "routes/web.php.bak.$(date +%Y%m%d%H%M%S)"
  cat > routes/web.php <<'PHP'
<?php

use Illuminate\Support\Facades\Route;
use App\Services\MediaStorage;

Route::get('/', function () {
    return response()->json([
        'app' => 'OG Landmark API',
        'ok' => true,
        'healthz' => url('/api/healthz'),
        'docs' => 'Use /api/* endpoints. Frontend: https://oglandmark.com',
    ]);
});

Route::get('/images/uploads/{filename}', function (string $filename) {
    $file = app(MediaStorage::class)->fileForPublicPath('/images/uploads/' . $filename);
    abort_unless($file !== null && is_file($file), 404);

    return response()->file($file);
})->where('filename', '[^/]+');
PHP
fi

echo "=== media dir ==="
MEDIA="/home/u133241207/domains/oglandmark.com/public_html/shared/media"
mkdir -p "$MEDIA" "$APP/public/images/uploads"
chmod -R ug+rwx storage bootstrap/cache "$MEDIA" "$APP/public/images/uploads" || true

if [[ -f .env ]]; then
  cp -a .env ".env.bak.$(date +%Y%m%d%H%M%S)"
  # Core production knobs
  grep -qE '^APP_ENV=' .env && sed -i 's/^APP_ENV=.*/APP_ENV=production/' .env || echo 'APP_ENV=production' >> .env
  grep -qE '^APP_DEBUG=' .env && sed -i 's/^APP_DEBUG=.*/APP_DEBUG=false/' .env || echo 'APP_DEBUG=false' >> .env
  grep -qE '^APP_URL=' .env && sed -i 's|^APP_URL=.*|APP_URL=https://api.oglandmark.com|' .env || echo 'APP_URL=https://api.oglandmark.com' >> .env
  grep -qE '^FRONTEND_URL=' .env && sed -i 's|^FRONTEND_URL=.*|FRONTEND_URL=https://oglandmark.com|' .env || echo 'FRONTEND_URL=https://oglandmark.com' >> .env
  grep -qE '^DB_HOST=' .env && sed -i 's/^DB_HOST=.*/DB_HOST=localhost/' .env || echo 'DB_HOST=localhost' >> .env
  grep -qE '^CACHE_STORE=' .env && sed -i 's/^CACHE_STORE=.*/CACHE_STORE=file/' .env || echo 'CACHE_STORE=file' >> .env
  sed -i -E 's/^(DATABASE_URL=)/#\1/' .env || true
  sed -i -E 's/^(DB_URL=)/#\1/' .env || true
  if grep -qE '^MEDIA_STORAGE_DIR=' .env; then
    sed -i "s|^MEDIA_STORAGE_DIR=.*|MEDIA_STORAGE_DIR=$MEDIA|" .env
  else
    echo "MEDIA_STORAGE_DIR=$MEDIA" >> .env
  fi
  if grep -qE '^MEDIA_STORAGE_PERSISTENT=' .env; then
    sed -i 's/^MEDIA_STORAGE_PERSISTENT=.*/MEDIA_STORAGE_PERSISTENT=true/' .env
  else
    echo 'MEDIA_STORAGE_PERSISTENT=true' >> .env
  fi
  if ! grep -qE '^CORS_ALLOWED_ORIGINS=' .env; then
    echo 'CORS_ALLOWED_ORIGINS=https://oglandmark.com,https://www.oglandmark.com,http://oglandmark.com,http://www.oglandmark.com' >> .env
  fi
fi

php artisan optimize:clear || true
php artisan config:cache || true
php artisan route:cache || true

echo "=== verify ==="
curl -sS https://api.oglandmark.com/ ; echo
curl -sS https://api.oglandmark.com/api/healthz ; echo
php -r '
require "vendor/autoload.php";
$app=require "bootstrap/app.php";
$app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();
try { print_r(DB::select("select 1 as ok")); echo "DB_OK\n"; }
catch (Throwable $e) { echo "DB_FAIL: ".$e->getMessage()."\n"; }
'

echo "DONE"
echo "hPanel tip: Document root can stay at .../public_html/api (with root .htaccess),"
echo "or set to .../public_html/api/public (preferred)."
