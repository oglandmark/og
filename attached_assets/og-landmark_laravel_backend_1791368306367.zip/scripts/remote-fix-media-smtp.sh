#!/usr/bin/env bash
# Optional follow-up after docroot fix: make media storage ready + remind SMTP.
# Run on Hostinger SSH from the Laravel API root (folder with artisan).
set -euo pipefail

APP_DIR="${1:-}"
if [[ -z "$APP_DIR" ]]; then
  for d in "$PWD" \
    "/home/u133241207/domains/oglandmark.com/public_html/api" \
    "/home/u133241207/domains/api.oglandmark.com/public_html"; do
    if [[ -f "$d/artisan" && -f "$d/public/index.php" ]]; then
      APP_DIR="$d"
      break
    fi
  done
fi
cd "$APP_DIR"
echo "APP_DIR=$APP_DIR"

MEDIA_DIR="${MEDIA_STORAGE_DIR:-$APP_DIR/public/images/uploads}"
SHARED_MEDIA="/home/u133241207/domains/oglandmark.com/public_html/shared/media"

# Prefer a persistent shared folder when the account layout allows it
if [[ -d "$(dirname "$SHARED_MEDIA")" ]] || mkdir -p "$(dirname "$SHARED_MEDIA")" 2>/dev/null; then
  mkdir -p "$SHARED_MEDIA"
  MEDIA_DIR="$SHARED_MEDIA"
fi

mkdir -p "$MEDIA_DIR"
chmod -R ug+rwx "$MEDIA_DIR" || true
mkdir -p "$APP_DIR/public/images/uploads"
# Keep public URL path working when media lives outside public/
if [[ "$MEDIA_DIR" != "$APP_DIR/public/images/uploads" ]]; then
  # symlink public path → persistent dir when possible
  if [[ ! -e "$APP_DIR/public/images/uploads/.keep" ]]; then
    rm -rf "$APP_DIR/public/images/uploads"
    ln -sfn "$MEDIA_DIR" "$APP_DIR/public/images/uploads" || mkdir -p "$APP_DIR/public/images/uploads"
  fi
fi

if [[ -f .env ]]; then
  cp -a .env ".env.bak.media.$(date +%Y%m%d%H%M%S)"
  if grep -qE '^MEDIA_STORAGE_DIR=' .env; then
    sed -i "s|^MEDIA_STORAGE_DIR=.*|MEDIA_STORAGE_DIR=$MEDIA_DIR|" .env
  else
    echo "MEDIA_STORAGE_DIR=$MEDIA_DIR" >> .env
  fi
  if grep -qE '^MEDIA_STORAGE_PERSISTENT=' .env; then
    sed -i 's/^MEDIA_STORAGE_PERSISTENT=.*/MEDIA_STORAGE_PERSISTENT=true/' .env
  else
    echo 'MEDIA_STORAGE_PERSISTENT=true' >> .env
  fi
  php artisan optimize:clear || true
  php artisan config:cache || true
fi

echo "MEDIA_DIR=$MEDIA_DIR"
curl -sS https://api.oglandmark.com/api/healthz; echo
echo "If smtp is still not_configured, set SMTP_USER/SMTP_PASS (or MAIL_*) in .env"
