<?php
$nodeEnv = '/home/u133241207/domains/oglandmark.com/public_html/.env';
$laravelEnv = '/home/u133241207/domains/oglandmark.com/public_html/api/.env';

function env_get_lines(array $lines, string $key): ?string {
    foreach ($lines as $line) {
        if (str_starts_with($line, $key . '=')) {
            return trim(substr($line, strlen($key) + 1), " \t\"'");
        }
    }
    return null;
}

function env_set_lines(array $lines, array $updates): array {
    $seen = [];
    $out = [];
    foreach ($lines as $line) {
        if (str_starts_with($line, 'DATABASE_URL=') || str_starts_with($line, 'DB_URL=')) {
            $out[] = str_starts_with($line, '#') ? $line : ('#' . $line);
            continue;
        }
        $key = null;
        if ($line !== '' && $line[0] !== '#' && str_contains($line, '=')) {
            $key = substr($line, 0, strpos($line, '='));
        }
        if ($key !== null && array_key_exists($key, $updates)) {
            $v = $updates[$key];
            $safe = preg_match('/[ #"\'`$\\\\]/', $v) ? ('"' . addcslashes($v, "\\\"") . '"') : $v;
            $out[] = $key . '=' . $safe;
            $seen[$key] = true;
            continue;
        }
        $out[] = $line;
    }
    foreach ($updates as $key => $v) {
        if (!isset($seen[$key])) {
            $safe = preg_match('/[ #"\'`$\\\\]/', $v) ? ('"' . addcslashes($v, "\\\"") . '"') : $v;
            $out[] = $key . '=' . $safe;
        }
    }
    return $out;
}

$nodeLines = file($nodeEnv, FILE_IGNORE_NEW_LINES);
$url = env_get_lines($nodeLines, 'DATABASE_URL');
if (!$url) {
    fwrite(STDERR, "NO_NODE_DATABASE_URL\n");
    exit(1);
}

$p = parse_url($url);
$user = $p['user'] ?? '';
$pass = urldecode($p['pass'] ?? '');
$host = $p['host'] ?? 'localhost';
$port = (string) ($p['port'] ?? 3306);
$db = ltrim($p['path'] ?? '/', '/');
$db = explode('?', $db)[0];

if (in_array($host, ['127.0.0.1', 'localhost'], true) || str_ends_with($host, '.hstgr.io') || str_starts_with($host, 'mysql.')) {
    $host = 'localhost';
}

echo "node_user=$user\n";
echo "node_host=$host\n";
echo "node_port=$port\n";
echo "node_db=$db\n";
echo 'node_pass_len=' . strlen($pass) . "\n";

$larLines = file($laravelEnv, FILE_IGNORE_NEW_LINES);
echo 'lar_user_before=' . var_export(env_get_lines($larLines, 'DB_USERNAME'), true) . "\n";
echo 'same_pass_before=' . (env_get_lines($larLines, 'DB_PASSWORD') === $pass ? 'yes' : 'no') . "\n";

copy($laravelEnv, $laravelEnv . '.bak.nodesync');

$updates = [
    'DB_CONNECTION' => 'mysql',
    'DB_HOST' => $host,
    'DB_PORT' => $port,
    'DB_DATABASE' => $db,
    'DB_USERNAME' => trim($user),
    'DB_PASSWORD' => $pass,
    'CACHE_STORE' => 'file',
];
$new = env_set_lines($larLines, $updates);
file_put_contents($laravelEnv, implode("\n", $new) . "\n");
echo "ENV_UPDATED\n";

try {
    $pdo = new PDO("mysql:host={$host};port={$port};dbname={$db}", trim($user), $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    ]);
    $row = $pdo->query('SELECT 1 AS ok, DATABASE() AS db')->fetch(PDO::FETCH_ASSOC);
    echo 'PDO_OK db=' . ($row['db'] ?? '') . "\n";
} catch (Throwable $e) {
    echo 'PDO_FAIL: ' . $e->getMessage() . "\n";
    exit(2);
}
