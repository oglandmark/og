#!/usr/bin/env python3
"""Sync live API (public_html/api) DB_* from public_html Node DATABASE_URL and test MySQL."""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path
from urllib.parse import unquote, urlparse

NODE_ENV = Path("/home/u133241207/domains/oglandmark.com/public_html/.env")
LARAVEL_ENV = Path(
    "/home/u133241207/domains/oglandmark.com/public_html/api/.env"
)


def env_get(lines: list[str], key: str) -> str | None:
    for line in lines:
        if line.startswith(key + "="):
            return line.split("=", 1)[1].strip().strip('"').strip("'")
    return None


def env_set(lines: list[str], updates: dict[str, str]) -> list[str]:
    seen: set[str] = set()
    out: list[str] = []
    for line in lines:
        if line.startswith("DATABASE_URL=") or line.startswith("DB_URL="):
            out.append(line if line.startswith("#") else "#" + line)
            continue
        key = line.split("=", 1)[0] if "=" in line and not line.startswith("#") else None
        if key in updates:
            val = updates[key]
            if any(c in val for c in [' ', '#', '"', "'", "$", "`", "\\"]):
                safe = '"' + val.replace("\\", "\\\\").replace('"', '\\"') + '"'
            else:
                safe = val
            out.append(f"{key}={safe}")
            seen.add(key)
        else:
            out.append(line)
    for key, val in updates.items():
        if key not in seen:
            if any(c in val for c in [' ', '#', '"', "'", "$", "`", "\\"]):
                safe = '"' + val.replace("\\", "\\\\").replace('"', '\\"') + '"'
            else:
                safe = val
            out.append(f"{key}={safe}")
    return out


def main() -> int:
    node_lines = NODE_ENV.read_text(encoding="utf-8", errors="replace").splitlines()
    url = env_get(node_lines, "DATABASE_URL")
    if not url:
        print("NO_NODE_DATABASE_URL")
        return 1

    u = urlparse(url)
    user = u.username or ""
    password = unquote(u.password or "")
    host = u.hostname or "localhost"
    port = str(u.port or 3306)
    db = (u.path or "/").lstrip("/").split("?")[0]

    # Hostinger PHP apps should use localhost for same-server MySQL
    if host in {"127.0.0.1", "localhost"} or host.endswith(".hstgr.io") or host.startswith("mysql."):
        host = "localhost"

    print(f"node_user={user}")
    print(f"node_host={host}")
    print(f"node_port={port}")
    print(f"node_db={db}")
    print(f"node_pass_len={len(password)}")

    lar_lines = LARAVEL_ENV.read_text(encoding="utf-8", errors="replace").splitlines()
    print(f"lar_user_before={env_get(lar_lines, 'DB_USERNAME')!r}")
    print(f"lar_db_before={env_get(lar_lines, 'DB_DATABASE')!r}")
    print(f"same_pass_before={env_get(lar_lines, 'DB_PASSWORD') == password}")

    bak = LARAVEL_ENV.with_suffix(LARAVEL_ENV.suffix + ".bak.nodesync")
    bak.write_text(LARAVEL_ENV.read_text(encoding="utf-8", errors="replace"), encoding="utf-8")

    updates = {
        "DB_CONNECTION": "mysql",
        "DB_HOST": host,
        "DB_PORT": port,
        "DB_DATABASE": db,
        "DB_USERNAME": user.strip(),
        "DB_PASSWORD": password,
        "CACHE_STORE": "file",
    }
    new_lines = env_set(lar_lines, updates)
    LARAVEL_ENV.write_text("\n".join(new_lines) + "\n", encoding="utf-8")
    print("ENV_UPDATED")

    # mysql CLI test
    try:
        r = subprocess.run(
            [
                "mysql",
                "-h",
                host,
                "-u",
                user.strip(),
                f"-p{password}",
                db,
                "-e",
                "SELECT 1 AS ok; SELECT DATABASE();",
            ],
            capture_output=True,
            text=True,
            timeout=30,
        )
        print("mysql_stdout:", r.stdout.strip())
        print("mysql_stderr:", r.stderr.strip()[:300])
        print("MYSQL_OK" if r.returncode == 0 else "MYSQL_FAIL")
        if r.returncode != 0:
            return 2
    except FileNotFoundError:
        print("mysql_cli_missing")

    return 0


if __name__ == "__main__":
    sys.exit(main())
