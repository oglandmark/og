/**
 * Zero the SPA demo property seed in frontend/assets/index-*.js
 * by replacing properties:y3e() with properties:[].
 */
import { existsSync, readdirSync, readFileSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const assetsDir = path.join(root, 'frontend', 'assets');

if (!existsSync(assetsDir)) {
  console.error('strip-spa-demo-seed: missing frontend/assets');
  process.exit(1);
}

const files = readdirSync(assetsDir).filter((f) => /^index-.*\.js$/.test(f));
if (files.length === 0) {
  console.error('strip-spa-demo-seed: no assets/index-*.js');
  process.exit(1);
}

let patched = 0;
for (const file of files) {
  const full = path.join(assetsDir, file);
  let src = readFileSync(full, 'utf8');
  if (!src.includes('properties:y3e()')) {
    if (src.includes('Luxurious Modern Villa') && src.includes('properties:[]')) {
      console.log(`  already stripped: ${file}`);
      continue;
    }
    if (!src.includes('Luxurious Modern Villa')) {
      console.log(`  skip (no demo titles): ${file}`);
      continue;
    }
    console.error(`strip-spa-demo-seed: pattern properties:y3e() not found in ${file}`);
    process.exit(1);
  }
  src = src.replace(/properties:y3e\(\)/g, 'properties:[]');
  writeFileSync(full, src);
  patched += 1;
  console.log(`  stripped demo seed: ${file}`);
}

if (patched === 0) {
  console.log('strip-spa-demo-seed: nothing to patch (already clean)');
} else {
  console.log(`strip-spa-demo-seed: patched ${patched} file(s)`);
}
