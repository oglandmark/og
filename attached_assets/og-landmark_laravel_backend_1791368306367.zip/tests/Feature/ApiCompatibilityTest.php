<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Tests\TestCase;

class ApiCompatibilityTest extends TestCase
{
    use RefreshDatabase;

    public function test_healthz_exposes_laravel_and_database_status(): void
    {
        $this->getJson('/api/healthz')
            ->assertOk()
            ->assertJsonPath('framework', 'laravel')
            ->assertJsonPath('databaseProvider', 'mysql')
            ->assertJsonPath('status', 'ok');
    }

    public function test_forgot_password_persists_a_bounded_challenge(): void
    {
        DB::table('app_data')->insert([
            'id' => 1,
            'data' => json_encode([
                'users' => [[
                    'id' => 7,
                    'email' => 'seller@example.com',
                    'name' => 'Seller',
                    'password' => 'pbkdf2:unused:unused',
                ]],
            ]),
        ]);

        $this->postJson('/api/auth/forgot-password', ['email' => 'seller@example.com'])
            ->assertOk()
            ->assertJsonPath('success', true);

        $this->assertDatabaseHas('auth_challenges', [
            'email' => 'seller@example.com',
            'purpose' => 'password-reset',
            'attempts' => 0,
        ]);

        $this->postJson('/api/auth/reset-password', [
            'email' => 'seller@example.com',
            'code' => '000000',
            'newPassword' => 'NewPassword123',
        ])->assertStatus(400);

        $this->assertDatabaseHas('auth_challenges', [
            'email' => 'seller@example.com',
            'purpose' => 'password-reset',
            'attempts' => 1,
        ]);
    }

    public function test_admin_can_list_users_and_buyer_requests(): void
    {
        $salt = 'a1b2c3d4e5f60718';
        $password = 'AdminPass123';
        $hash = 'pbkdf2:' . $salt . ':' . hash_pbkdf2('sha512', $password, $salt, 100000, 128, false);

        DB::table('app_data')->insert([
            'id' => 1,
            'data' => json_encode([
                'users' => [
                    [
                        'id' => 1,
                        'email' => 'admin@example.com',
                        'name' => 'Platform Admin',
                        'role' => 'Admin',
                        'status' => 'Active',
                        'password' => $hash,
                    ],
                    [
                        'id' => 2,
                        'email' => 'buyer@example.com',
                        'name' => 'Test Buyer',
                        'role' => 'Buyer',
                        'status' => 'Active',
                        'password' => $hash,
                    ],
                ],
                'buyerRequests' => [],
                'nextId' => 10,
            ]),
        ]);

        $login = $this->postJson('/api/auth/admin-verify', [
            'email' => 'admin@example.com',
            'password' => $password,
        ])->assertOk();

        $token = $login->json('token');
        $this->assertNotEmpty($token);

        $this->withHeader('Authorization', 'Bearer ' . $token)
            ->getJson('/api/users')
            ->assertOk()
            ->assertJsonFragment(['email' => 'buyer@example.com'])
            ->assertJsonFragment(['role' => 'Buyer']);

        $this->withHeader('Authorization', 'Bearer ' . $token)
            ->getJson('/api/admin/buyer-requests')
            ->assertOk()
            ->assertExactJson([]);

        $this->withHeader('Authorization', 'Bearer ' . $token)
            ->getJson('/api/admin/stats')
            ->assertOk()
            ->assertJsonPath('totalUsers', 2);
    }
}