# OG Landmark Mobile App

Source package: latest mobile app changes through 1 October 2026.

## Included

- Expo mobile app source, screens, components, tests, and bundled image/video assets
- The shared API client workspace package required by the app
- pnpm workspace manifests and lockfile

## Not included

- APK/IPA builds
- `node_modules`, Expo caches, and generated mobile build folders
- API keys, environment secrets, or the separate backend server

## Run locally

1. Install Node.js and pnpm.
2. From this folder, run `pnpm install`.
3. Create `artifacts/og-landmark-mobile/.env` and set the values needed for your environment:

   - `EXPO_PUBLIC_API_URL` — reachable API base URL, without a trailing `/api`
   - `EXPO_PUBLIC_GOOGLE_MAPS_API_KEY` — if using native Google Maps
   - `EXPO_PUBLIC_MAPBOX_ACCESS_TOKEN` — if using Mapbox map tiles

   Credentials are intentionally not included in this archive.
4. Run `pnpm --filter @workspace/mobile exec expo start --lan` and scan the QR code with Expo Go.
