OG Landmark Mobile Source — 03-10-26

This ZIP contains the complete OG Landmark Expo mobile source project, app assets, configuration, and tests, plus the local API-client workspace package required by the project.

Setup from this folder:
  pnpm install --filter @workspace/mobile...
  pnpm --filter @workspace/mobile exec expo start

This is a source-code handoff, not an APK/IPA. Installed dependencies, Expo device cache, local environment files, credentials, and signing files are not included. Configure any required API/domain/map settings through your secure environment before building.
