OG Landmark mobile — 25-09-26

This is a mobile-only Expo source/build project ZIP. It is not a precompiled APK or IPA.

Included:
- artifacts/og-landmark-mobile — Expo app source, screens, components, assets, and native build configuration
- lib/api-client-react — the app's required shared API client
- pnpm workspace and lock configuration needed to install the mobile project

The website and API server source are not included. No environment secrets are included.

To prepare the project, extract this archive and run `pnpm install` from its root.
For Android development, run `pnpm --filter @workspace/mobile exec expo start`.
To create an installable Android preview APK, configure the app's required EXPO_PUBLIC_* environment values and run `pnpm dlx eas-cli build --profile preview --platform android`.
