OG Landmark Hostinger update patch (v3)

Upload/extract the ZIP contents into the active public_html folder and allow the listed files to overwrite existing files. This is an overlay patch; it contains only public website files and does not contain or replace the API, database, or .env configuration.

This patch:
- Routes /privacy-policy and /account-deletion to standalone pages.
- Fixes the homepage Privacy Policy footer link, which was pointing to #.
- Provides an account-deletion page at both supported web-root layouts.
- Uses a new logo filename so browsers do not keep showing a cached logo.
- Adds the mobile app's five homepage category banners: Homes, Commercial, Agriculture, Plots, and Projects, with swipe, pagination, and auto-advance.
- Bundles the same five banner images used by the mobile app. The carousel requests GET /api/mobile/banners for active banner content and uses the bundled mobile fallback slides if that endpoint is unavailable.

Note: the website-side carousel is complete, but the API endpoint must be reachable from the public website for admin-edited mobile banners to appear dynamically. The bundled defaults remain visible while that API route is unavailable.

Files included:
- .htaccess, index.html, og-landmark-brand-square-20261002-v2.png
- home-category-banners-20261002-v1.css and .js
- images/mobile-banners/*.jpg
- pages/privacy.html and pages/account-deletion.html
- public/.htaccess, public/index.html, public/og-landmark-brand-square-20261002-v2.png
- public/home-category-banners-20261002-v1.css and .js
- public/images/mobile-banners/*.jpg
- public/pages/privacy-policy.html and public/pages/account-deletion.html

After extraction, check these URLs in a private/incognito window:
https://www.oglandmark.com/
https://www.oglandmark.com/privacy-policy
https://www.oglandmark.com/account-deletion

Google Play review also checks that the Play Console Data safety and data-deletion answers match the app and every SDK actually used. This website policy cannot replace those Console declarations.
