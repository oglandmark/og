OG Web v10 — Laravel Blade website source package

This package contains the current Laravel Blade website, its application/API source, public assets, Composer lockfile, and installed PHP dependencies. It is a Laravel application package, not a static HTML-only upload.

Use PHP 8.2+ with the required Laravel extensions and set the web document root to this package’s public/ directory. Configure deployment values privately using .env.example as a template. The archive intentionally excludes .env, local SQLite data, logs, compiled views, runtime caches, and uploaded media.

The current preview keeps /api/* traffic on its existing upstream. Do not switch production traffic to this package until database/core-storage, SMTP, persistent media, and API-route readiness have been verified. Do not import or normalize production data without a verified backup and explicit migration plan.
