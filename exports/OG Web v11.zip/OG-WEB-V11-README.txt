OG Web v11 — Laravel Blade website package

403 fix / upload layout
1. Back up the current site and uploaded media before replacing any live files.
2. Upload this ZIP and extract every entry directly into the domain document root (usually public_html). Do not extract it into an extra OG Web v11 folder. The ZIP root already contains index.php and .htaccess.
3. The domain must point to that same document root. The package routes PHP pages through the Laravel front controller and serves public assets from the root. Apache/LiteSpeed mod_rewrite must be enabled.
4. Use PHP 8.2+ with the required Laravel extensions. Keep the Laravel application source inside the laravel/ directory; HTTP access to it is blocked.

Private application setup
- The archive intentionally excludes .env secrets, the local SQLite database, logs, compiled views, caches, and uploaded media.
- Copy laravel/.env.example to laravel/.env and configure the hosting database, APP_KEY, mail, and persistent media settings privately. Do not move .env into the public root. Preserve the existing APP_KEY and production database; do not import a repository snapshot into a live database.
- Make laravel/storage and laravel/bootstrap/cache writable by PHP (normally 775 on shared hosting; do not use 777).
- Verify the target database, SMTP delivery, and persistent media before switching live traffic. This ZIP does not configure or migrate the hosting account.

If 403 remains after extraction, verify the domain document-root path, that root index.php and .htaccess were extracted there (not one folder deeper), PHP permissions, and the host’s mod_rewrite/.htaccess settings.
