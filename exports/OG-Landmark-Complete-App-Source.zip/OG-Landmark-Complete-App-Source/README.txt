OG Landmark — Complete App Source

Included
- Expo mobile app and assets
- OG Landmark website source and served public assets
- Laravel API and API-server source
- Shared workspace libraries, scripts, manifests, and lockfile

Not included
- Secrets or active .env files (safe .env.example templates are included)
- Installed Node/PHP dependencies, build caches, and generated output folders
- Local SQLite database, JSON runtime/listing data, logs, and persistent uploads
- Git history, screenshots, and unrelated workspace artifacts

The archive contains source code, not a preconfigured deployment. Install Node dependencies with pnpm and Laravel dependencies with Composer. Copy the relevant .env.example to .env and provide credentials through a secure environment; do not commit secrets. Database schemas and migrations are included, but no live database was exported or modified.
