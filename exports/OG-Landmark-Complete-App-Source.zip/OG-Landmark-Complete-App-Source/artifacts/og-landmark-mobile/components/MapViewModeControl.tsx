import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';

export type MapViewMode = 'map' | 'satellite';

const OPTIONS: { value: MapViewMode; label: string }[] = [
  { value: 'map', label: 'Map' },
  { value: 'satellite', label: 'Satellite' },
];

interface Props {
  mode: MapViewMode;
  onChange: (mode: MapViewMode) => void;
  top?: number;
}

export function MapViewModeControl({ mode, onChange, top = 100 }: Props) {
  return (
    <View style={[styles.container, { top }]}>
      {OPTIONS.map((option) => {
        const selected = mode === option.value;
        return (
          <Pressable
            key={option.value}
            accessibilityRole="button"
            accessibilityLabel={`${option.label} map view`}
            accessibilityState={{ selected }}
            testID={`map-view-mode-${option.value}`}
            onPress={() => onChange(option.value)}
            style={[
              styles.button,
              { borderBottomColor: selected ? '#f2d18a' : 'transparent' },
            ]}
          >
            <Text style={[styles.label, selected && styles.selectedLabel]}>
              {option.label}
            </Text>
          </Pressable>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    top: 100,
    left: 12,
    zIndex: 1000,
    flexDirection: 'column',
    alignItems: 'center',
    gap: 2,
    padding: 3,
    backgroundColor: '#ffffff',
    borderWidth: 1,
    borderColor: '#d6e0e8',
    borderRadius: 10,
    shadowColor: '#102a43',
    shadowOpacity: 0.18,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 2 },
    elevation: 4,
  },
  button: {
    width: 84,
    minHeight: 36,
    paddingHorizontal: 8,
    alignItems: 'center',
    justifyContent: 'center',
    borderBottomWidth: 2,
    backgroundColor: 'transparent',
  },
  label: {
    color: '#102a43',
    fontSize: 12,
    fontWeight: '700',
  },
  selectedLabel: { color: '#c8a45a' },
});