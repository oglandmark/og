OG Landmark Mobile — Source ZIP
Snapshot: 2026-10-03

This archive contains the latest mobile app source and its required shared API client/workspace files. It does not contain an installable APK or AAB.

Requirements
- Node.js 20 or newer
- pnpm 10 or newer

Install from the archive root:
  pnpm install --frozen-lockfile

Useful checks:
  pnpm --filter @workspace/mobile typecheck
  pnpm --filter @workspace/mobile test:location
  pnpm --filter @workspace/mobile check:brand-assets

The mobile app currently calls https://www.oglandmark.com for its API. Map/provider credentials are not included; configure them separately through your environment or secrets manager. Do not commit secret values into this archive.

The app lives at artifacts/og-landmark-mobile. The shared @workspace/api-client-react package is included at lib/api-client-react in this archive's workspace layout.
