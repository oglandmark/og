OG Landmark Website — Frontend Source Snapshot

Included:
- The complete current public/ frontend tree: website entry HTML, portal and legal pages, browser JavaScript/CSS bundles, and image assets.

Not included:
- The API/backend server, database code or data, environment files, secrets, node_modules, or build caches.

Important build note:
- The website currently served by this artifact is the static frontend in public/ (public/index.html loads public/assets/...). The original unbundled React/TypeScript source that produced that production bundle is not present in this workspace; the exact browser bundle and styles currently used by the website are included here.
- API-backed features still require the separate OG Landmark API service.
