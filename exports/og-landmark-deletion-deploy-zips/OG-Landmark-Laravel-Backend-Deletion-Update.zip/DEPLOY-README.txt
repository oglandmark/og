OG Landmark — Laravel account/data deletion update overlay

This is a file overlay for the existing Hostinger Laravel API (the production API currently reports Laravel + MySQL). It is not a complete Laravel app archive.

Deploy safely:
1. Back up the existing Laravel files and the current MySQL database/media before upload.
2. Extract this ZIP into the EXISTING Laravel project root, preserving the relative paths shown in the archive.
3. Preserve the existing .env, APP_KEY, database settings, vendor/, uploaded media and storage. This ZIP does not contain any of them.
4. No database migration, seed, SQL import, or live-data replacement is required for the account-deletion code update.
5. Clear the Laravel route/config cache or run `php artisan optimize:clear`, then restart the Hostinger PHP application.
6. Verify the public site separately with the frontend ZIP; this backend overlay alone does not fix routes served from the static public_html root.

The deletion handler relies on the existing app_data, auth_sessions and auth_challenges tables. Do not use a repository database dump to replace the live Hostinger database.
