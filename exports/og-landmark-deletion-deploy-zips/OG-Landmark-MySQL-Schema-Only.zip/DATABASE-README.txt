OG Landmark — MySQL schema-only reference

This archive contains schema definitions only. It does NOT contain a backup, users, listings, passwords, messages, app_data rows, uploaded media, or environment credentials.

The account/data-deletion feature itself requires no new database migration. Production Hostinger MySQL is the source of truth; do not replace it with this ZIP or import this schema routinely. If the live database is already serving the Laravel API, leave it unchanged for this code update.

If this schema is needed for a reviewed setup, first take a verified database + matching media backup, compare existing table definitions, then have the database administrator apply only what is missing. Every table definition uses CREATE TABLE IF NOT EXISTS, so existing tables/rows are not modified. Do not import this SQL and then also run the Laravel migrations against the same empty schema: choose one setup path and record migration state consistently.
