OG Landmark — full current Laravel API package (updated 2026-10-07)

This is a full package built from the current Laravel source, including normalized MySQL storage and account/data deletion support. It is intended for the existing Hostinger Laravel API (PHP 8.2+), not the Node upload screen. Set the Laravel document root to `public/`.

Before deployment, back up the current application files, live MySQL database, and persistent media. Preserve the existing Hostinger `.env`, APP_KEY, database settings, SMTP configuration, MEDIA_STORAGE_DIR, and uploaded media. This ZIP intentionally excludes .env, local SQLite, logs, sessions, caches, tests, and media.

The account/data-deletion code requires no new database migration. Do not import repository data or run seeders, and do not replace the live database. For this code update, no DB import is required. Clear Laravel caches after upload (`php artisan optimize:clear`) and verify the API before resuming traffic.

The main-domain website is served from a separate static Hostinger root; deploy the frontend ZIP separately. This backend package alone does not update public_html.
