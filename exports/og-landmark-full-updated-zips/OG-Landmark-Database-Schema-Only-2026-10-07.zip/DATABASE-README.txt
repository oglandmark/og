OG Landmark — MySQL schema-only package (updated 2026-10-07)

This is a schema reference, NOT a database backup. It contains only CREATE TABLE IF NOT EXISTS definitions and no live users, listings, app_data rows, password hashes, sessions, messages, or uploaded media.

No database migration is required specifically for account/data deletion. Hostinger MySQL remains the live source of truth. Do not replace it or import this schema into a healthy production database for this code update. If schema recovery is genuinely required, take a verified database + matching media backup first and have a DBA compare the live tables before applying anything. Do not combine this standalone SQL baseline with Laravel migrations on the same fresh schema without reconciling migration history.
