OG Landmark — full frontend source/build bundle (updated 2026-10-07)

This full package is based on the supplied frontend archive. It keeps the source, compiled site build, and supplied public assets, while adding the current privacy-policy, account-deletion, and data-deletion pages and route rules.

For static Hostinger hosting, use the contents of `build/` as the document-root files. If `.htaccess` already exists, merge the legal RewriteRule lines before the SPA fallback; do not replace unrelated rules. Back up the current site before upload. Local `node_modules/` and npm lockfiles are intentionally omitted; `.npmrc` points to the public npm registry. The nested `build.zip` is also updated.

After upload, test these public URLs without signing in:
https://oglandmark.com/privacy-policy
https://oglandmark.com/account-deletion
https://oglandmark.com/data-deletion
