import { type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import {
  Route,
  Switch,
  useLocation,
  Router as WouterRouter,
} from 'wouter';

const queryClient = new QueryClient();

function Home() {
  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-gradient-to-b from-slate-50 to-slate-100">
      <div className="max-w-lg text-center px-6">
        <p className="text-sm font-semibold tracking-wide text-slate-500 uppercase">
          OG Landmark
        </p>
        <h1 className="mt-3 text-3xl font-bold text-slate-900">
          Vite + React toolchain restored
        </h1>
        <p className="mt-3 text-sm text-slate-600 leading-relaxed">
          This is the development scaffold (port 5174). The live Hostinger site still
          uses the production static bundle (
          <code className="text-xs bg-slate-200 px-1 rounded">index.prod.html</code>
          + <code className="text-xs bg-slate-200 px-1 rounded">assets/</code>
          ). Rebuild pages here, then promote{' '}
          <code className="text-xs bg-slate-200 px-1 rounded">dist/</code> when ready.
        </p>
        <div className="mt-6 flex flex-col sm:flex-row gap-3 justify-center">
          <a
            href="http://127.0.0.1:5173/?api=http://127.0.0.1:8000/api"
            className="inline-flex items-center justify-center rounded-md bg-slate-900 px-4 py-2 text-sm font-medium text-white hover:bg-slate-800"
          >
            Open full site locally
          </a>
          <code className="inline-flex items-center justify-center rounded-md border border-slate-300 bg-white px-3 py-2 text-xs text-slate-700">
            npm run preview:stack
          </code>
        </div>
        <p className="mt-4 text-xs text-slate-500 leading-relaxed">
          Full UI: stop this scaffold if needed, run{' '}
          <code className="bg-slate-200 px-1 rounded">npm run preview:stack</code> from
          the repo root, then open the link above (prod preview on 5173 + local API).
        </p>
        <p className="mt-3 text-xs text-slate-500">
          API proxy on this scaffold: <code>/api</code> → Laravel on port 8000
        </p>
      </div>
    </div>
  );
}

function Router() {
  return (
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
