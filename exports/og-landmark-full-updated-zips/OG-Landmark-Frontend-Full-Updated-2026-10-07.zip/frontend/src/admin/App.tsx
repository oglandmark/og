import { type ReactNode } from 'react';
import { Route, Switch, Router as WouterRouter, useLocation } from 'wouter';
import { ErrorBoundary } from '@/components/error-boundary';
import AdminLoginPage from '@/admin/pages/login';
import AdminLayout from '@/admin/layout';
import DashboardPage from '@/admin/pages/dashboard';
import UsersPage from '@/admin/pages/users';
import PropertiesPage from '@/admin/pages/properties';
import InquiriesPage from '@/admin/pages/inquiries';

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function AdminRoutes() {
  return (
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/login" component={AdminLoginPage} />
        <Route path="/">
          <AdminLayout>
            <DashboardPage />
          </AdminLayout>
        </Route>
        <Route path="/users">
          <AdminLayout>
            <UsersPage />
          </AdminLayout>
        </Route>
        <Route path="/properties">
          <AdminLayout>
            <PropertiesPage />
          </AdminLayout>
        </Route>
        <Route path="/inquiries">
          <AdminLayout>
            <InquiriesPage />
          </AdminLayout>
        </Route>
        <Route>
          <AdminLayout>
            <DashboardPage />
          </AdminLayout>
        </Route>
      </Switch>
    </RoutedErrorBoundary>
  );
}

export default function AdminApp() {
  return (
    <WouterRouter base="/admin">
      <AdminRoutes />
    </WouterRouter>
  );
}
