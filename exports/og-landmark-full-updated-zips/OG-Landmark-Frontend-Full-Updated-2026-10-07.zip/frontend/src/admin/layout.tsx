import { type ReactNode } from 'react';
import { Link, useLocation } from 'wouter';
import {
  LayoutDashboard,
  Users,
  Building2,
  MessageSquare,
  LogOut,
  ExternalLink,
} from 'lucide-react';
import { useAuthGuard } from '@/hooks/use-auth-guard';
import { logout } from '@/lib/auth-session';
import { cn } from '@/lib/utils';

const NAV = [
  { href: '/', label: 'Dashboard', icon: LayoutDashboard },
  { href: '/users', label: 'Users', icon: Users },
  { href: '/properties', label: 'Properties', icon: Building2 },
  { href: '/inquiries', label: 'Inquiries', icon: MessageSquare },
];

export default function AdminLayout({ children }: { children: ReactNode }) {
  const { ready, user } = useAuthGuard('admin');
  const [location] = useLocation();

  if (!ready) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#0B1F3A] text-[#C8A45A]">
        Loading admin…
      </div>
    );
  }

  const initials = (user?.name || 'A')
    .split(/\s+/)
    .map((w) => w[0])
    .join('')
    .slice(0, 2)
    .toUpperCase();

  return (
    <div className="min-h-screen flex bg-[#f0f4f8] text-slate-900 font-[DM_Sans,system-ui,sans-serif]">
      <aside className="fixed inset-y-0 left-0 z-40 w-60 bg-[#0B1F3A] text-slate-300 flex flex-col">
        <div className="px-4 py-5 border-b border-white/10 flex items-center gap-3">
          <img src="/og-logo.png" alt="" className="h-9 w-9 object-contain" />
          <div>
            <div className="text-white text-sm font-bold tracking-wide">OG Landmark</div>
            <div className="text-[10px] uppercase tracking-[0.18em] text-[#C8A45A]">Admin</div>
          </div>
        </div>

        <div className="px-4 py-4 border-b border-white/10 flex items-center gap-3">
          <div className="h-9 w-9 rounded-full bg-[#C8A45A] text-[#0B1F3A] font-bold text-sm flex items-center justify-center">
            {initials}
          </div>
          <div className="min-w-0">
            <div className="text-white text-sm font-semibold truncate">{user?.name || 'Admin'}</div>
            <div className="text-xs text-slate-400 truncate">{user?.email}</div>
          </div>
        </div>

        <nav className="flex-1 px-2 py-3 space-y-0.5 overflow-y-auto">
          {NAV.map((item) => {
            const active =
              item.href === '/'
                ? location === '/' || location === ''
                : location.startsWith(item.href);
            const Icon = item.icon;
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  'flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors',
                  active
                    ? 'bg-[#C8A45A]/15 text-[#C8A45A]'
                    : 'text-slate-400 hover:bg-white/5 hover:text-white',
                )}
              >
                <Icon className="h-4 w-4 shrink-0" />
                {item.label}
              </Link>
            );
          })}
        </nav>

        <div className="p-3 border-t border-white/10 space-y-1">
          <a
            href="/"
            className="flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm text-slate-400 hover:bg-white/5 hover:text-white"
          >
            <ExternalLink className="h-4 w-4" />
            View site
          </a>
          <button
            type="button"
            onClick={() => logout('/admin/login')}
            className="w-full flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm text-red-300 hover:bg-red-500/15"
          >
            <LogOut className="h-4 w-4" />
            Logout
          </button>
        </div>
      </aside>

      <div className="flex-1 ml-60 min-h-screen flex flex-col">
        <header className="sticky top-0 z-30 h-14 bg-white border-b border-slate-200 px-6 flex items-center justify-between">
          <h1 className="text-base font-bold text-[#0B1F3A]">
            {NAV.find((n) =>
              n.href === '/'
                ? location === '/' || location === ''
                : location.startsWith(n.href),
            )?.label || 'Admin'}
          </h1>
          <div className="text-xs text-slate-500">
            {new Date().toLocaleString('en-PK', { dateStyle: 'medium', timeStyle: 'short' })}
          </div>
        </header>
        <main className="flex-1 p-6">{children}</main>
      </div>
    </div>
  );
}
