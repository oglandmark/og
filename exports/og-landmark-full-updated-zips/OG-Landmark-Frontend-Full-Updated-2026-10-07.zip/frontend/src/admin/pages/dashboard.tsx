import { useQuery } from '@tanstack/react-query';
import { Link } from 'wouter';
import { Building2, Users, Clock, Eye } from 'lucide-react';
import { api } from '@/lib/api-client';
import type { OgUser } from '@/lib/auth-session';

type Stats = {
  totalProperties?: number;
  totalUsers?: number;
  pendingApprovals?: number;
  activeListings?: number;
  featuredListings?: number;
  totalViews?: number;
  totalInquiries?: number;
};

type Property = {
  id: string | number;
  title?: string;
  city?: string;
  approvalStatus?: string;
  sellerName?: string;
};

export default function DashboardPage() {
  const statsQ = useQuery({
    queryKey: ['admin-stats'],
    queryFn: () => api<Stats>('/admin/stats'),
  });
  const usersQ = useQuery({
    queryKey: ['admin-users-preview'],
    queryFn: () => api<OgUser[]>('/users'),
  });
  const propsQ = useQuery({
    queryKey: ['admin-props-preview'],
    queryFn: () => api<Property[]>('/admin/properties'),
  });

  const stats = statsQ.data || {};
  const users = Array.isArray(usersQ.data) ? usersQ.data.slice(0, 5) : [];
  const props = Array.isArray(propsQ.data) ? propsQ.data.slice(0, 5) : [];

  const cards = [
    { label: 'Total Users', value: stats.totalUsers ?? '—', icon: Users, color: 'bg-emerald-100 text-emerald-700' },
    { label: 'Properties', value: stats.totalProperties ?? '—', icon: Building2, color: 'bg-blue-100 text-blue-700' },
    { label: 'Pending Approvals', value: stats.pendingApprovals ?? '—', icon: Clock, color: 'bg-amber-100 text-amber-700' },
    { label: 'Total Views', value: stats.totalViews ?? '—', icon: Eye, color: 'bg-violet-100 text-violet-700' },
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        {cards.map((c) => {
          const Icon = c.icon;
          return (
            <div key={c.label} className="bg-white rounded-xl border border-slate-200 p-5 flex items-center gap-4">
              <div className={`h-11 w-11 rounded-xl flex items-center justify-center ${c.color}`}>
                <Icon className="h-5 w-5" />
              </div>
              <div>
                <div className="text-xs text-slate-500 font-medium">{c.label}</div>
                <div className="text-2xl font-extrabold text-[#0B1F3A]">{c.value}</div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <section className="bg-white rounded-xl border border-slate-200 overflow-hidden">
          <div className="px-5 py-3.5 border-b border-slate-100 flex items-center justify-between">
            <h3 className="font-bold text-[#0B1F3A]">Recent Users</h3>
            <Link href="/users" className="text-xs font-semibold text-[#C8A45A] hover:underline">
              View all
            </Link>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 text-slate-500 text-xs uppercase">
                <tr>
                  <th className="text-left px-4 py-2.5 font-semibold">Name</th>
                  <th className="text-left px-4 py-2.5 font-semibold">Role</th>
                </tr>
              </thead>
              <tbody>
                {users.length === 0 ? (
                  <tr>
                    <td colSpan={2} className="px-4 py-8 text-center text-slate-400">
                      {usersQ.isLoading ? 'Loading…' : 'No users yet'}
                    </td>
                  </tr>
                ) : (
                  users.map((u) => (
                    <tr key={String(u.id)} className="border-t border-slate-50">
                      <td className="px-4 py-3">
                        <div className="font-medium">{u.name || '—'}</div>
                        <div className="text-xs text-slate-400">{u.email}</div>
                      </td>
                      <td className="px-4 py-3">
                        <span className="inline-flex rounded-full bg-slate-100 px-2.5 py-0.5 text-xs font-semibold">
                          {u.role || '—'}
                        </span>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </section>

        <section className="bg-white rounded-xl border border-slate-200 overflow-hidden">
          <div className="px-5 py-3.5 border-b border-slate-100 flex items-center justify-between">
            <h3 className="font-bold text-[#0B1F3A]">Recent Properties</h3>
            <Link href="/properties" className="text-xs font-semibold text-[#C8A45A] hover:underline">
              View all
            </Link>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 text-slate-500 text-xs uppercase">
                <tr>
                  <th className="text-left px-4 py-2.5 font-semibold">Title</th>
                  <th className="text-left px-4 py-2.5 font-semibold">Status</th>
                </tr>
              </thead>
              <tbody>
                {props.length === 0 ? (
                  <tr>
                    <td colSpan={2} className="px-4 py-8 text-center text-slate-400">
                      {propsQ.isLoading ? 'Loading…' : 'No properties yet'}
                    </td>
                  </tr>
                ) : (
                  props.map((p) => (
                    <tr key={String(p.id)} className="border-t border-slate-50">
                      <td className="px-4 py-3">
                        <div className="font-medium truncate max-w-[220px]">{p.title || 'Untitled'}</div>
                        <div className="text-xs text-slate-400">{p.city || '—'} · {p.sellerName || '—'}</div>
                      </td>
                      <td className="px-4 py-3">
                        <span className="inline-flex rounded-full bg-slate-100 px-2.5 py-0.5 text-xs font-semibold">
                          {p.approvalStatus || '—'}
                        </span>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </section>
      </div>
    </div>
  );
}
