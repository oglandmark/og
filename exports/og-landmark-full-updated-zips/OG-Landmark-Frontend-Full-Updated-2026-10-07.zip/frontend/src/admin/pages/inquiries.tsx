import { useQuery } from '@tanstack/react-query';
import { api } from '@/lib/api-client';

type Inquiry = {
  id: string | number;
  name?: string;
  buyerName?: string;
  email?: string;
  phone?: string;
  message?: string;
  propertyTitle?: string;
  createdAt?: string;
  timestamp?: string;
};

export default function InquiriesPage() {
  const inqQ = useQuery({
    queryKey: ['admin-inquiries'],
    queryFn: () => api<Inquiry[]>('/inquiries'),
  });

  const list = Array.isArray(inqQ.data) ? inqQ.data : [];

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-xl border border-slate-200 p-4">
        <h2 className="font-bold text-[#0B1F3A]">All Inquiries</h2>
        <p className="text-xs text-slate-500 mt-0.5">{list.length} total</p>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm min-w-[720px]">
            <thead className="bg-slate-50 text-slate-500 text-xs uppercase">
              <tr>
                <th className="text-left px-4 py-3 font-semibold">Buyer</th>
                <th className="text-left px-4 py-3 font-semibold">Property</th>
                <th className="text-left px-4 py-3 font-semibold">Message</th>
                <th className="text-left px-4 py-3 font-semibold">Contact</th>
                <th className="text-left px-4 py-3 font-semibold">Date</th>
              </tr>
            </thead>
            <tbody>
              {inqQ.isLoading ? (
                <tr>
                  <td colSpan={5} className="px-4 py-10 text-center text-slate-400">
                    Loading…
                  </td>
                </tr>
              ) : list.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-4 py-10 text-center text-slate-400">
                    No inquiries yet.
                  </td>
                </tr>
              ) : (
                list.map((i) => (
                  <tr key={String(i.id)} className="border-t border-slate-100">
                    <td className="px-4 py-3 font-medium">{i.name || i.buyerName || 'Buyer'}</td>
                    <td className="px-4 py-3">{i.propertyTitle || '—'}</td>
                    <td className="px-4 py-3 max-w-[240px] truncate text-slate-600">{i.message || '—'}</td>
                    <td className="px-4 py-3 text-xs text-slate-500">
                      <div>{i.email || '—'}</div>
                      <div>{i.phone || ''}</div>
                    </td>
                    <td className="px-4 py-3 text-xs text-slate-500">
                      {(i.createdAt || i.timestamp || '').toString().slice(0, 10) || '—'}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
