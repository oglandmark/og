import { FormEvent, useState } from 'react';
import { api, ApiError } from '@/lib/api-client';
import { getToken, getUser, isAdmin, setSession, type OgUser } from '@/lib/auth-session';
import { useEffect } from 'react';

type LoginResponse = {
  token?: string;
  user?: OgUser;
  error?: string;
  message?: string;
};

export default function AdminLoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const token = getToken();
    const user = getUser();
    if (token && user && isAdmin(user)) {
      window.location.replace('/admin/');
    }
  }, []);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setError('');
    if (!email.trim() || !password) {
      setError('Enter email and password.');
      return;
    }
    setLoading(true);
    try {
      const data = await api<LoginResponse>('/auth/admin-verify', {
        method: 'POST',
        body: { email: email.trim(), password },
        auth: false,
      });
      if (!data.token || !data.user) {
        setError(data.error || 'Login failed.');
        return;
      }
      if (!isAdmin(data.user)) {
        setError('This account is not an admin.');
        return;
      }
      setSession(data.token, data.user, { adminAuth: true });
      window.location.href = '/admin/';
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Connection error. Try again.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex font-[DM_Sans,system-ui,sans-serif]">
      <div className="hidden lg:flex flex-1 items-center justify-center bg-gradient-to-br from-[#071428] via-[#0B1F3A] to-[#112244] relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(circle_at_30%_20%,#C8A45A,transparent_50%)]" />
        <div className="relative text-center px-10 max-w-md">
          <img src="/og-logo.png" alt="OG Landmark" className="mx-auto h-20 w-20 object-contain mb-6 drop-shadow-lg" />
          <h1 className="text-3xl font-bold text-[#C8A45A] tracking-wide">OG Landmark</h1>
          <p className="mt-2 text-[11px] uppercase tracking-[0.35em] text-slate-400">Admin Portal</p>
          <p className="mt-8 text-slate-300/80 text-sm leading-relaxed">
            Manage buyers, sellers, agents, listings and platform content from one modern console.
          </p>
        </div>
      </div>

      <div className="w-full lg:w-[480px] bg-white flex flex-col justify-center px-8 sm:px-12 py-12">
        <div className="inline-flex items-center gap-2 self-start rounded-full bg-[#0B1F3A] text-[#C8A45A] px-3.5 py-1.5 text-[11px] font-bold uppercase tracking-wider mb-6">
          <span className="h-1.5 w-1.5 rounded-full bg-[#C8A45A]" />
          Admin Login
        </div>
        <h2 className="text-2xl font-bold text-[#0B1F3A]">Sign in</h2>
        <p className="text-sm text-slate-500 mt-1 mb-8">Use your admin credentials to continue.</p>

        <form onSubmit={onSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-1.5" htmlFor="email">
              Email
            </label>
            <input
              id="email"
              type="email"
              autoComplete="username"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none focus:border-[#C8A45A] focus:bg-white focus:ring-2 focus:ring-[#C8A45A]/20"
              placeholder="admin@example.com"
            />
          </div>
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-1.5" htmlFor="password">
              Password
            </label>
            <input
              id="password"
              type="password"
              autoComplete="current-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none focus:border-[#C8A45A] focus:bg-white focus:ring-2 focus:ring-[#C8A45A]/20"
              placeholder="••••••••"
            />
          </div>

          {error ? (
            <div className="rounded-lg bg-red-50 text-red-600 text-sm px-3 py-2.5">{error}</div>
          ) : null}

          <button
            type="submit"
            disabled={loading}
            className="w-full rounded-xl bg-[#C8A45A] text-[#0B1F3A] font-bold py-3.5 text-sm hover:bg-[#b8943a] disabled:opacity-60 transition-colors"
          >
            {loading ? 'Signing in…' : 'Continue'}
          </button>
        </form>

        <p className="mt-8 text-center text-xs text-slate-400">
          <a href="/" className="text-[#C8A45A] font-semibold hover:underline">
            ← Back to site
          </a>
        </p>
      </div>
    </div>
  );
}
