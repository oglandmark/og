import { useMemo, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { api } from '@/lib/api-client';

type Property = {
  id: string | number;
  title?: string;
  city?: string;
  type?: string;
  price?: number;
  approvalStatus?: string;
  listingStatus?: string;
  sellerName?: string;
  featured?: boolean;
};

export default function PropertiesPage() {
  const [q, setQ] = useState('');
  const propsQ = useQuery({
    queryKey: ['admin-properties'],
    queryFn: () => api<Property[]>('/admin/properties'),
  });

  const list = useMemo(() => {
    let items = Array.isArray(propsQ.data) ? propsQ.data : [];
    const needle = q.trim().toLowerCase();
    if (needle) {
      items = items.filter(
        (p) =>
          String(p.title || '').toLowerCase().includes(needle) ||
          String(p.city || '').toLowerCase().includes(needle) ||
          String(p.sellerName || '').toLowerCase().includes(needle),
      );
    }
    return items;
  }, [propsQ.data, q]);

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-xl border border-slate-200 p-4 flex flex-col sm:flex-row gap-3 justify-between items-start sm:items-center">
        <div>
          <h2 className="font-bold text-[#0B1F3A]">All Properties</h2>
          <p className="text-xs text-slate-500 mt-0.5">{list.length} listings</p>
        </div>
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search title, city, seller…"
          className="w-full sm:w-72 rounded-lg border border-slate-200 px-3 py-2 text-sm outline-none focus:border-[#C8A45A] focus:ring-2 focus:ring-[#C8A45A]/15"
        />
      </div>

      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm min-w-[760px]">
            <thead className="bg-slate-50 text-slate-500 text-xs uppercase">
              <tr>
                <th className="text-left px-4 py-3 font-semibold">Title</th>
                <th className="text-left px-4 py-3 font-semibold">City</th>
                <th className="text-left px-4 py-3 font-semibold">Seller</th>
                <th className="text-left px-4 py-3 font-semibold">Price</th>
                <th className="text-left px-4 py-3 font-semibold">Status</th>
              </tr>
            </thead>
            <tbody>
              {propsQ.isLoading ? (
                <tr>
                  <td colSpan={5} className="px-4 py-10 text-center text-slate-400">
                    Loading…
                  </td>
                </tr>
              ) : list.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-4 py-10 text-center text-slate-400">
                    No properties found.
                  </td>
                </tr>
              ) : (
                list.map((p) => (
                  <tr key={String(p.id)} className="border-t border-slate-100 hover:bg-slate-50/60">
                    <td className="px-4 py-3">
                      <div className="font-medium text-[#0B1F3A]">{p.title || 'Untitled'}</div>
                      <div className="text-xs text-slate-400">{p.type || 'Property'}</div>
                    </td>
                    <td className="px-4 py-3">{p.city || '—'}</td>
                    <td className="px-4 py-3">{p.sellerName || '—'}</td>
                    <td className="px-4 py-3 font-semibold text-[#C8A45A]">
                      {p.price != null ? `PKR ${Number(p.price).toLocaleString()}` : '—'}
                    </td>
                    <td className="px-4 py-3">
                      <span className="inline-flex rounded-full bg-slate-100 px-2.5 py-0.5 text-xs font-semibold">
                        {p.approvalStatus || p.listingStatus || '—'}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
