import { useMemo, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { api, ApiError } from '@/lib/api-client';
import type { OgUser } from '@/lib/auth-session';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';

const TABS = [
  { id: 'all', label: 'All Users' },
  { id: 'Buyer', label: 'Buyers' },
  { id: 'Seller', label: 'Sellers' },
  { id: 'Agent', label: 'Agents' },
  { id: 'Admin', label: 'Admins' },
] as const;

function roleBadgeClass(role?: string) {
  const r = String(role || '').toLowerCase();
  if (r === 'admin') return 'bg-red-100 text-red-700';
  if (r === 'seller') return 'bg-emerald-100 text-emerald-700';
  if (r === 'agent') return 'bg-violet-100 text-violet-700';
  if (r === 'buyer') return 'bg-blue-100 text-blue-700';
  return 'bg-slate-100 text-slate-600';
}

export default function UsersPage() {
  const [tab, setTab] = useState<(typeof TABS)[number]['id']>('all');
  const [q, setQ] = useState('');
  const { toast } = useToast();
  const qc = useQueryClient();

  const usersQ = useQuery({
    queryKey: ['admin-users'],
    queryFn: () => api<OgUser[]>('/users'),
  });

  const deleteMut = useMutation({
    mutationFn: (id: string | number) => api(`/users/${id}`, { method: 'DELETE' }),
    onSuccess: () => {
      toast({ title: 'User deleted' });
      qc.invalidateQueries({ queryKey: ['admin-users'] });
    },
    onError: (err: unknown) => {
      toast({
        title: 'Delete failed',
        description: err instanceof ApiError ? err.message : 'Try again',
        variant: 'destructive',
      });
    },
  });

  const filtered = useMemo(() => {
    let list = Array.isArray(usersQ.data) ? usersQ.data : [];
    if (tab !== 'all') {
      list = list.filter((u) => String(u.role || '').toLowerCase() === tab.toLowerCase());
    }
    const needle = q.trim().toLowerCase();
    if (needle) {
      list = list.filter(
        (u) =>
          String(u.name || '').toLowerCase().includes(needle) ||
          String(u.email || '').toLowerCase().includes(needle) ||
          String(u.phone || '').toLowerCase().includes(needle),
      );
    }
    return list;
  }, [usersQ.data, tab, q]);

  const counts = useMemo(() => {
    const all = Array.isArray(usersQ.data) ? usersQ.data : [];
    return {
      all: all.length,
      Buyer: all.filter((u) => String(u.role).toLowerCase() === 'buyer').length,
      Seller: all.filter((u) => String(u.role).toLowerCase() === 'seller').length,
      Agent: all.filter((u) => String(u.role).toLowerCase() === 'agent').length,
      Admin: all.filter((u) => String(u.role).toLowerCase() === 'admin').length,
    };
  }, [usersQ.data]);

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-xl border border-slate-200 p-4 flex flex-col sm:flex-row sm:items-center gap-3 justify-between">
        <div>
          <h2 className="font-bold text-[#0B1F3A]">Users & Agents</h2>
          <p className="text-xs text-slate-500 mt-0.5">List and filter every buyer, seller, agent and admin.</p>
        </div>
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search name, email, phone…"
          className="w-full sm:w-72 rounded-lg border border-slate-200 px-3 py-2 text-sm outline-none focus:border-[#C8A45A] focus:ring-2 focus:ring-[#C8A45A]/15"
        />
      </div>

      <div className="flex flex-wrap gap-2">
        {TABS.map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setTab(t.id)}
            className={cn(
              'rounded-full px-3.5 py-1.5 text-xs font-bold transition-colors',
              tab === t.id
                ? 'bg-[#0B1F3A] text-[#C8A45A]'
                : 'bg-white border border-slate-200 text-slate-600 hover:border-[#C8A45A]',
            )}
          >
            {t.label}
            <span className="ml-1.5 opacity-70">{counts[t.id]}</span>
          </button>
        ))}
      </div>

      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm min-w-[720px]">
            <thead className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wide">
              <tr>
                <th className="text-left px-4 py-3 font-semibold">Name</th>
                <th className="text-left px-4 py-3 font-semibold">Email</th>
                <th className="text-left px-4 py-3 font-semibold">Phone</th>
                <th className="text-left px-4 py-3 font-semibold">Role</th>
                <th className="text-left px-4 py-3 font-semibold">Status</th>
                <th className="text-left px-4 py-3 font-semibold">Joined</th>
                <th className="text-right px-4 py-3 font-semibold">Actions</th>
              </tr>
            </thead>
            <tbody>
              {usersQ.isLoading ? (
                <tr>
                  <td colSpan={7} className="px-4 py-10 text-center text-slate-400">
                    Loading users…
                  </td>
                </tr>
              ) : filtered.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-4 py-10 text-center text-slate-400">
                    No users match this filter.
                  </td>
                </tr>
              ) : (
                filtered.map((u) => (
                  <tr key={String(u.id)} className="border-t border-slate-100 hover:bg-slate-50/60">
                    <td className="px-4 py-3 font-medium text-[#0B1F3A]">{u.name || '—'}</td>
                    <td className="px-4 py-3 text-slate-600">{u.email || '—'}</td>
                    <td className="px-4 py-3 text-slate-600">{u.phone || '—'}</td>
                    <td className="px-4 py-3">
                      <span className={cn('inline-flex rounded-full px-2.5 py-0.5 text-xs font-bold', roleBadgeClass(u.role))}>
                        {u.role || '—'}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <span className="text-xs font-semibold text-slate-600">{u.status || u.approvalStatus || '—'}</span>
                    </td>
                    <td className="px-4 py-3 text-slate-500 text-xs">
                      {u.joinedDate ? String(u.joinedDate).slice(0, 10) : '—'}
                    </td>
                    <td className="px-4 py-3 text-right">
                      <button
                        type="button"
                        disabled={deleteMut.isPending || String(u.role).toLowerCase() === 'admin'}
                        onClick={() => {
                          if (!confirm(`Delete ${u.name || u.email}?`)) return;
                          deleteMut.mutate(u.id);
                        }}
                        className="text-xs font-semibold text-red-600 hover:underline disabled:opacity-40"
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
