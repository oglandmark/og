import { useEffect, useState } from 'react';
import { getToken, getUser, isAdmin, type OgUser } from '@/lib/auth-session';

type GuardMode = 'admin' | 'user' | 'any';

type GuardResult = {
  ready: boolean;
  user: OgUser | null;
  token: string | null;
};

/**
 * Client-side auth gate for portal apps.
 * - admin: requires Admin role (redirects to /admin/login)
 * - user: requires non-admin logged-in user (Admin → /admin/, anon → /auth)
 * - any: requires any logged-in session
 */
export function useAuthGuard(mode: GuardMode = 'any'): GuardResult {
  const [ready, setReady] = useState(false);
  const [user, setUser] = useState<OgUser | null>(null);
  const [token, setToken] = useState<string | null>(null);

  useEffect(() => {
    const t = getToken();
    const u = getUser();

    if (!t || !u) {
      if (mode === 'admin') {
        window.location.replace('/admin/login');
      } else if (mode === 'user') {
        window.location.replace('/auth');
      } else {
        window.location.replace('/auth');
      }
      return;
    }

    if (mode === 'admin' && !isAdmin(u)) {
      window.location.replace('/admin/login');
      return;
    }

    if (mode === 'user' && isAdmin(u)) {
      window.location.replace('/admin/');
      return;
    }

    setToken(t);
    setUser(u);
    setReady(true);
  }, [mode]);

  return { ready, user, token };
}
