import { getToken } from '@/lib/auth-session';

declare global {
  interface Window {
    __OG_API_BASE__?: string;
  }
}

/** Resolve API origin (…/api) for portal apps. Prefer og-api-base.js when present. */
export function apiBase(): string {
  if (typeof window !== 'undefined' && window.__OG_API_BASE__) {
    return String(window.__OG_API_BASE__).replace(/\/+$/, '');
  }
  try {
    const stored = localStorage.getItem('og_api_base');
    if (stored) return stored.replace(/\/+$/, '');
  } catch {
    /* ignore */
  }
  const params = new URLSearchParams(window.location.search);
  const fromQuery = params.get('api');
  if (fromQuery) return fromQuery.replace(/\/+$/, '');
  // Same-origin /api (Vite proxy or Hostinger rewrite via og-api-base.js)
  return '/api';
}

export class ApiError extends Error {
  status: number;
  body: unknown;

  constructor(message: string, status: number, body?: unknown) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.body = body;
  }
}

type ApiOptions = {
  method?: string;
  body?: unknown;
  auth?: boolean;
  headers?: Record<string, string>;
};

export async function api<T = unknown>(path: string, options: ApiOptions = {}): Promise<T> {
  const method = (options.method || 'GET').toUpperCase();
  const headers: Record<string, string> = {
    Accept: 'application/json',
    ...(options.headers || {}),
  };
  if (options.body !== undefined) {
    headers['Content-Type'] = 'application/json';
  }
  if (options.auth !== false) {
    const token = getToken();
    if (token) headers.Authorization = `Bearer ${token}`;
  }

  const base = apiBase();
  const url = path.startsWith('http')
    ? path
    : `${base}${path.startsWith('/') ? path : `/${path}`}`;

  const res = await fetch(url, {
    method,
    headers,
    body: options.body !== undefined ? JSON.stringify(options.body) : undefined,
  });

  if (res.status === 204) return undefined as T;

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const msg =
      (data && typeof data === 'object' && 'error' in data && String((data as { error: unknown }).error)) ||
      res.statusText ||
      'Request failed';
    throw new ApiError(msg, res.status, data);
  }
  return data as T;
}
