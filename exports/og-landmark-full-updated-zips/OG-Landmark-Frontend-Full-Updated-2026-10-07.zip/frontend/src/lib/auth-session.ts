export type OgRole = 'Admin' | 'Buyer' | 'Seller' | 'Agent' | string;

export type OgUser = {
  id: string | number;
  name?: string;
  email?: string;
  phone?: string;
  city?: string;
  role?: OgRole;
  status?: string;
  approvalStatus?: string;
  [key: string]: unknown;
};

const TOKEN_KEY = 'og_token';
const USER_KEY = 'og_user';
const ADMIN_AUTH_KEY = 'adminAuth';

export function getToken(): string | null {
  try {
    return localStorage.getItem(TOKEN_KEY);
  } catch {
    return null;
  }
}

export function getUser(): OgUser | null {
  try {
    const raw = localStorage.getItem(USER_KEY);
    if (!raw) return null;
    return JSON.parse(raw) as OgUser;
  } catch {
    return null;
  }
}

export function setSession(token: string, user: OgUser, opts?: { adminAuth?: boolean }) {
  localStorage.setItem(TOKEN_KEY, token);
  localStorage.setItem(USER_KEY, JSON.stringify(user));
  if (opts?.adminAuth || String(user.role || '').toLowerCase() === 'admin') {
    localStorage.setItem(ADMIN_AUTH_KEY, 'true');
  }
}

export function clearSession() {
  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem(USER_KEY);
  localStorage.removeItem(ADMIN_AUTH_KEY);
}

export function isAdmin(user?: OgUser | null): boolean {
  const u = user ?? getUser();
  return String(u?.role || '').toLowerCase() === 'admin';
}

export function roleOf(user?: OgUser | null): string {
  return String((user ?? getUser())?.role || '').trim();
}

export function portalHomeForRole(role?: string): string {
  const r = String(role || '').toLowerCase();
  if (r === 'admin') return '/admin/';
  return '/user/';
}

export function logout(redirectTo = '/') {
  clearSession();
  window.location.href = redirectTo;
}
