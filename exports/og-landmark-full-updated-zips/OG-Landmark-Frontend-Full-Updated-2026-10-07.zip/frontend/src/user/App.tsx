import { type ReactNode } from 'react';
import { Route, Switch, Router as WouterRouter, useLocation } from 'wouter';
import { ErrorBoundary } from '@/components/error-boundary';
import UserLayout from '@/user/layout';
import UserDashboard from '@/user/pages/dashboard';
import UserProfile from '@/user/pages/profile';

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function UserRoutes() {
  return (
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/">
          <UserLayout>
            <UserDashboard />
          </UserLayout>
        </Route>
        <Route path="/profile">
          <UserLayout>
            <UserProfile />
          </UserLayout>
        </Route>
        <Route>
          <UserLayout>
            <UserDashboard />
          </UserLayout>
        </Route>
      </Switch>
    </RoutedErrorBoundary>
  );
}

export default function UserApp() {
  return (
    <WouterRouter base="/user">
      <UserRoutes />
    </WouterRouter>
  );
}
