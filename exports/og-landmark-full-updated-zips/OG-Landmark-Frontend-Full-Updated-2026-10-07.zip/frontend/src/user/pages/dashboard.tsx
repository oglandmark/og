import { useQuery } from '@tanstack/react-query';
import { api } from '@/lib/api-client';
import { getUser, roleOf } from '@/lib/auth-session';
import { Building2, Heart, MessageSquare, Clock } from 'lucide-react';

type Property = {
  id: string | number;
  title?: string;
  city?: string;
  price?: number;
  approvalStatus?: string;
  images?: string[];
};

type Inquiry = {
  id: string | number;
  message?: string;
  propertyTitle?: string;
  createdAt?: string;
};

export default function UserDashboard() {
  const user = getUser();
  const role = roleOf(user).toLowerCase();

  const myPropsQ = useQuery({
    queryKey: ['my-properties'],
    queryFn: () => api<Property[]>('/my-properties'),
    enabled: role === 'seller' || role === 'agent',
  });

  const savedQ = useQuery({
    queryKey: ['saved'],
    queryFn: () => api<Property[]>('/saved'),
    enabled: role === 'buyer',
  });

  const inqQ = useQuery({
    queryKey: ['user-inquiries'],
    queryFn: () => api<Inquiry[]>('/inquiries'),
    enabled: role === 'buyer' || role === 'seller',
  });

  if (role === 'agent') {
    const approval = String(user?.approvalStatus || user?.status || '').toLowerCase();
    const pending = ['pending', 'awaiting', 'awaiting_approval'].includes(approval);
    return (
      <div className="space-y-4">
        <Welcome name={user?.name} role="Agent" />
        {pending ? (
          <div className="rounded-xl border border-amber-200 bg-amber-50 p-5 text-amber-900">
            <div className="flex items-start gap-3">
              <Clock className="h-5 w-5 mt-0.5 shrink-0" />
              <div>
                <h3 className="font-bold">Awaiting admin approval</h3>
                <p className="text-sm mt-1 text-amber-800/90">
                  Your agent account is pending review. You will get full access once an admin approves you.
                </p>
              </div>
            </div>
          </div>
        ) : (
          <ListingsCard
            title="Your listings"
            items={Array.isArray(myPropsQ.data) ? myPropsQ.data : []}
            loading={myPropsQ.isLoading}
          />
        )}
      </div>
    );
  }

  if (role === 'seller') {
    const props = Array.isArray(myPropsQ.data) ? myPropsQ.data : [];
    const inqs = Array.isArray(inqQ.data) ? inqQ.data : [];
    return (
      <div className="space-y-6">
        <Welcome name={user?.name} role="Seller" />
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Stat icon={Building2} label="My listings" value={props.length} />
          <Stat icon={MessageSquare} label="Inquiries" value={inqs.length} />
        </div>
        <ListingsCard title="My properties" items={props} loading={myPropsQ.isLoading} />
        <a
          href="/sell"
          className="inline-flex items-center justify-center rounded-xl bg-[#C8A45A] text-[#0B1F3A] font-bold text-sm px-5 py-3 hover:bg-[#b8943a]"
        >
          + Add a listing
        </a>
      </div>
    );
  }

  // Buyer (default)
  const saved = Array.isArray(savedQ.data) ? savedQ.data : [];
  const inqs = Array.isArray(inqQ.data) ? inqQ.data : [];
  return (
    <div className="space-y-6">
      <Welcome name={user?.name} role="Buyer" />
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Stat icon={Heart} label="Saved properties" value={saved.length} />
        <Stat icon={MessageSquare} label="My inquiries" value={inqs.length} />
      </div>
      <ListingsCard title="Saved properties" items={saved} loading={savedQ.isLoading} emptyHint="Browse listings and save favourites." />
      <section className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        <div className="px-5 py-3.5 border-b border-slate-100 font-bold text-[#0B1F3A]">Recent inquiries</div>
        {inqQ.isLoading ? (
          <p className="p-6 text-sm text-slate-400">Loading…</p>
        ) : inqs.length === 0 ? (
          <p className="p-6 text-sm text-slate-400">No inquiries yet.</p>
        ) : (
          <ul className="divide-y divide-slate-100">
            {inqs.slice(0, 8).map((i) => (
              <li key={String(i.id)} className="px-5 py-3.5">
                <div className="font-medium text-sm">{i.propertyTitle || 'Property inquiry'}</div>
                <div className="text-xs text-slate-500 mt-0.5 line-clamp-2">{i.message || '—'}</div>
              </li>
            ))}
          </ul>
        )}
      </section>
      <a
        href="/properties"
        className="inline-flex items-center justify-center rounded-xl bg-[#0B1F3A] text-[#C8A45A] font-bold text-sm px-5 py-3 hover:opacity-90"
      >
        Browse properties
      </a>
    </div>
  );
}

function Welcome({ name, role }: { name?: string; role: string }) {
  return (
    <div className="rounded-2xl bg-gradient-to-br from-[#0B1F3A] to-[#1a3050] text-white p-6 shadow-sm">
      <p className="text-[11px] uppercase tracking-[0.2em] text-[#C8A45A] font-bold">{role} dashboard</p>
      <h2 className="mt-2 text-2xl font-bold tracking-tight">Welcome back{name ? `, ${name}` : ''}</h2>
      <p className="mt-1 text-sm text-slate-300">Manage your OG Landmark activity from this portal.</p>
    </div>
  );
}

function Stat({
  icon: Icon,
  label,
  value,
}: {
  icon: typeof Building2;
  label: string;
  value: number;
}) {
  return (
    <div className="bg-white rounded-xl border border-slate-200 p-5 flex items-center gap-4">
      <div className="h-11 w-11 rounded-xl bg-[#C8A45A]/15 text-[#92400e] flex items-center justify-center">
        <Icon className="h-5 w-5" />
      </div>
      <div>
        <div className="text-xs text-slate-500 font-medium">{label}</div>
        <div className="text-2xl font-extrabold text-[#0B1F3A]">{value}</div>
      </div>
    </div>
  );
}

function ListingsCard({
  title,
  items,
  loading,
  emptyHint = 'No listings yet.',
}: {
  title: string;
  items: Property[];
  loading?: boolean;
  emptyHint?: string;
}) {
  return (
    <section className="bg-white rounded-xl border border-slate-200 overflow-hidden">
      <div className="px-5 py-3.5 border-b border-slate-100 font-bold text-[#0B1F3A]">{title}</div>
      {loading ? (
        <p className="p-6 text-sm text-slate-400">Loading…</p>
      ) : items.length === 0 ? (
        <p className="p-6 text-sm text-slate-400">{emptyHint}</p>
      ) : (
        <div className="grid sm:grid-cols-2 gap-3 p-4">
          {items.slice(0, 6).map((p) => (
            <a
              key={String(p.id)}
              href={`/properties/${p.id}`}
              className="rounded-xl border border-slate-200 p-3 hover:border-[#C8A45A]/50 hover:shadow-sm transition-all"
            >
              <div className="font-semibold text-sm text-[#0B1F3A] line-clamp-1">{p.title || 'Property'}</div>
              <div className="text-xs text-slate-500 mt-1">{p.city || '—'}</div>
              <div className="text-sm font-bold text-[#C8A45A] mt-2">
                {p.price != null ? `PKR ${Number(p.price).toLocaleString()}` : '—'}
              </div>
            </a>
          ))}
        </div>
      )}
    </section>
  );
}
