import { getUser, roleOf } from '@/lib/auth-session';

export default function UserProfile() {
  const user = getUser();
  const role = roleOf(user);

  const fields = [
    { label: 'Name', value: user?.name },
    { label: 'Email', value: user?.email },
    { label: 'Phone', value: user?.phone },
    { label: 'City', value: user?.city },
    { label: 'Role', value: role },
    { label: 'Status', value: user?.status || user?.approvalStatus },
  ];

  return (
    <div className="max-w-xl space-y-4">
      <div className="bg-white rounded-xl border border-slate-200 p-6">
        <h2 className="font-bold text-[#0B1F3A] text-lg">My profile</h2>
        <p className="text-sm text-slate-500 mt-1">Account details from your OG Landmark session.</p>
        <dl className="mt-6 space-y-3">
          {fields.map((f) => (
            <div key={f.label} className="flex justify-between gap-4 border-b border-slate-100 pb-3 last:border-0">
              <dt className="text-sm text-slate-500">{f.label}</dt>
              <dd className="text-sm font-semibold text-[#0B1F3A] text-right">{f.value || '—'}</dd>
            </div>
          ))}
        </dl>
      </div>
      <p className="text-xs text-slate-400">
        Need to change password? Use{' '}
        <a href="/auth" className="text-[#C8A45A] font-semibold hover:underline">
          account recovery
        </a>{' '}
        on the main site.
      </p>
    </div>
  );
}
