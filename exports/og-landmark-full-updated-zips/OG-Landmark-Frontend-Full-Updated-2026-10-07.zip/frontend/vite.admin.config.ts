import path from 'path';
import { defineConfig, type Plugin } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';

/** Emit dist-admin/index.html from admin.html entry; keep site-root asset URLs. */
function emitIndexHtml(): Plugin {
  return {
    name: 'emit-admin-index-html',
    enforce: 'post',
    generateBundle(_options, bundle) {
      const from = 'admin.html';
      const entry = bundle[from];
      if (!entry || entry.type !== 'asset') return;
      let html = String(entry.source);
      // Vite rebases absolute / paths under base=/admin/; restore site-root shared assets.
      html = html
        .replaceAll('src="/admin/og-api-base.js"', 'src="/og-api-base.js"')
        .replaceAll('href="/admin/og-logo.png"', 'href="/og-logo.png"');
      bundle['index.html'] = {
        ...entry,
        fileName: 'index.html',
        name: 'index.html',
        source: html,
      };
      delete bundle[from];
    },
  };
}

export default defineConfig({
  base: '/admin/',
  // Do not copy frontend/public (portal/, images/, …) into the admin SPA bundle.
  publicDir: false,
  plugins: [react(), tailwindcss(), emitIndexHtml()],
  resolve: {
    alias: { '@': path.resolve(__dirname, 'src') },
    dedupe: ['react', 'react-dom'],
  },
  server: {
    port: 5175,
    strictPort: true,
    host: '127.0.0.1',
    proxy: {
      '/api': { target: 'http://127.0.0.1:8000', changeOrigin: true },
    },
  },
  build: {
    outDir: 'dist-admin',
    emptyOutDir: true,
    rollupOptions: {
      input: path.resolve(__dirname, 'admin.html'),
    },
  },
});
