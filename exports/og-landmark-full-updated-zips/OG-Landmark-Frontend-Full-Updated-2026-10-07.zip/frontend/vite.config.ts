import path from 'path';
import { defineConfig, type Plugin } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';

const viteIndex = path.resolve(__dirname, 'index.vite.html');

/** Emit dist/index.html even though the source entry is index.vite.html. */
function emitIndexHtml(): Plugin {
  return {
    name: 'emit-index-html',
    enforce: 'post',
    generateBundle(_options, bundle) {
      const from = 'index.vite.html';
      const entry = bundle[from];
      if (!entry || entry.type !== 'asset') return;
      bundle['index.html'] = {
        ...entry,
        fileName: 'index.html',
        name: 'index.html',
      };
      delete bundle[from];
    },
  };
}

export default defineConfig({
  base: '/',
  plugins: [react(), tailwindcss(), emitIndexHtml()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, 'src'),
    },
    dedupe: ['react', 'react-dom'],
  },
  // Only scan the Vite dev entry (not index.prod.html / assets/).
  optimizeDeps: {
    entries: ['index.html'],
  },
  server: {
    // Keep scaffold off 5173 so `npm run preview:frontend` (prod static) can run alongside
    port: 5174,
    strictPort: true,
    host: '127.0.0.1',
    watch: {
      ignored: [
        '**/assets/**',
        '**/dist/**',
        '**/portal/**',
        '**/pages/**',
        '**/images/**',
        '**/index.prod.html',
        '**/node_modules/**',
      ],
    },
    proxy: {
      '/api': {
        target: 'http://127.0.0.1:8000',
        changeOrigin: true,
      },
    },
  },
  preview: {
    port: 5174,
    host: '127.0.0.1',
  },
  build: {
    outDir: 'dist',
    emptyOutDir: true,
    // Never use index.prod.html / production index.html here — those reference
    // frontend/assets/index-*.js and Vite would re-bundle the ~3MB live artifact.
    // Keyed input emits dist/index.html (not index.vite.html) for Apache fallbacks.
    rollupOptions: {
      input: { index: viteIndex },
    },
  },
});
