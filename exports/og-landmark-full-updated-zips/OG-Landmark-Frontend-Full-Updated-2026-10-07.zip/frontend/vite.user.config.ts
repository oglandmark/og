import path from 'path';
import { defineConfig, type Plugin } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';

/** Emit dist-user/index.html from user.html entry; keep site-root asset URLs. */
function emitIndexHtml(): Plugin {
  return {
    name: 'emit-user-index-html',
    enforce: 'post',
    generateBundle(_options, bundle) {
      const from = 'user.html';
      const entry = bundle[from];
      if (!entry || entry.type !== 'asset') return;
      let html = String(entry.source);
      html = html
        .replaceAll('src="/user/og-api-base.js"', 'src="/og-api-base.js"')
        .replaceAll('href="/user/og-logo.png"', 'href="/og-logo.png"');
      bundle['index.html'] = {
        ...entry,
        fileName: 'index.html',
        name: 'index.html',
        source: html,
      };
      delete bundle[from];
    },
  };
}

export default defineConfig({
  base: '/user/',
  // Do not copy frontend/public (portal/, images/, …) into the user SPA bundle.
  publicDir: false,
  plugins: [react(), tailwindcss(), emitIndexHtml()],
  resolve: {
    alias: { '@': path.resolve(__dirname, 'src') },
    dedupe: ['react', 'react-dom'],
  },
  server: {
    port: 5176,
    strictPort: true,
    host: '127.0.0.1',
    proxy: {
      '/api': { target: 'http://127.0.0.1:8000', changeOrigin: true },
    },
  },
  build: {
    outDir: 'dist-user',
    emptyOutDir: true,
    rollupOptions: {
      input: path.resolve(__dirname, 'user.html'),
    },
  },
});
