OG Landmark — full frontend bundle (updated 2026-10-08)

This archive keeps the supplied full frontend source and compiled build while
updating the public account-deletion page. Full account deletion and specific
data-deletion requests are now explained on the same page. The 14-day verified
request commitment is unchanged. The legacy /data-deletion route remains an
alias to the combined page.

For static Hostinger hosting, use the contents of frontend/build/ as the
website document root. Back up the current site first. If .htaccess already
exists, merge the legal RewriteRule lines from frontend/build/.htaccess before
the SPA fallback; preserve unrelated live rules.

Set both Google Play Console fields to:
  Account deletion URL: https://www.oglandmark.com/account-deletion
  Data deletion URL:    https://www.oglandmark.com/account-deletion

After uploading, test both URLs in a private browser window. The local package
is not proof that Hostinger has been updated; verify the live responses after
the upload. The privacy-policy URL remains a separate field.
