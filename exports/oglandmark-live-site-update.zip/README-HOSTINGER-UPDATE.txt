OG Landmark — Privacy Policy and Logo Update
============================================

Ye update ZIP hai, full website backup nahi. Iske folders aur file paths
attached Hostinger website ke public_html root ke mutabiq hain.

Install:
1. Hostinger par ZIP se pehle public_html ka backup bana lein.
2. ZIP ko maujooda public_html mein extract karke existing files overwrite karein.
   Website ka existing folder empty/delete na karein.
3. Existing api/.env, API/backend files, database aur uploaded media ko preserve
   karein. Ye update ZIP un files ko replace nahi karti.
4. Browser cache clear karke ye URLs check karein:
   - https://www.oglandmark.com/privacy-policy
   - https://www.oglandmark.com/pages/privacy.html
   - https://www.oglandmark.com/account-deletion

Policy page ko project ki current October 2, 2026 version se update kiya gaya
hai. Website, admin/user portals aur favicon ke logo files mobile app ke current
OG Landmark brand icon se replace kiye gaye hain.